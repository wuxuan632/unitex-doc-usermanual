Text automaton
==============

Natural languages contain much lexical ambiguity. The text automaton is
an effective and visual way of representing such ambiguity. Each
sentence of a text is represented by an automaton whose paths represent
all possible interpretations.

This chapter presents the concept of text automaton, the details of
their construction and the operations that can be applied, in particular
ambiguity removal and linearization. Since version 2.1, it is possible
to search the text automaton for patterns (see section
[section-locate-tfst]).

Displaying text automaton
-------------------------

The text automaton explicit all possible lexical interpretations of the
words. These different interpretations are the different entries
presented in the dictionary of the text. Figure [fig-sentence-automaton]
shows the automaton of the fourth sentence of the text *Ivanhoe*.

.. figure:: resources/img/fig7-1.png
   :alt: Sentence automaton example[fig-sentence-automaton]
   :width: 15.50000cm

   Sentence automaton example[fig-sentence-automaton]

You can see in Figure [fig-sentence-automaton] that the word ``Here``
has three interpretations here (adjective, adverb and noun), ``haunted``
two (adjective and verb), etc. All the possible combinations are
expressed because each interpretation of each word is connected to all
the interpretations of the following and preceding words.

In case of an overlap between a compound word and a sequence of simple
words, the automaton contains a path that is labeled by the compound
word, parallel to the paths that express the combinations of simple
words. This is illustrated in Figure [fig-overlap], where the compound
word ``courts of law`` overlaps with a combination of simple words.

.. figure:: resources/img/fig7-2.png
   :alt: Overlap between a compound word and a combination of simple
   words.[fig-overlap]
   :width: 12.50000cm

   Overlap between a compound word and a combination of simple
   words.[fig-overlap]

By construction, the text automaton does not contain any loop. One says
that the text automaton is *acyclic*.

NOTE: The term “text automaton” is an abuse of language. In fact, there
is an automaton for each sentence of the text. Therefore, the
combination of all these automata corresponds to the automaton of the
text. This is why we use the term “text automaton” even if this object
is not manipulated as a global automaton for practical reasons.

Construction
------------

In order to construct the text automaton, open the text, then click on
“Construct FST-Text...” in the menu “Text”. One should first split the
text into sentences and apply dictionaries. If sentence boundary
detection is not applied, the construction program will arbitrarily
split the text in sequences of 2000 lexical units instead of
constructing one automaton per sentence. If no dictionaries are applied,
the text automaton that you obtain will consist of only one path made up
of unknown words per sentence.

Construction rules for text automata
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Sentence automata are constructed from text dictionaries. The resulting
degree of ambiguity is therefore directly linked to the granularity of
the descriptions of dictionaries. From the sentence automaton in
figure [fig-ambiguity-of-which], you can conclude that the word
``which`` has been coded twice as a determiner in two subcategories of
the category ``DET``. This granularity of descriptions will not be of
any use if you are only interested in the grammatical category of this
word. It is therefore necessary to adapt the granularity of the
dictionaries to the intended use.

.. figure:: resources/img/fig7-3.png
   :alt: Double entry for ``which`` as a
   determiner[fig-ambiguity-of-which]
   :width: 10.60000cm

   Double entry for ``which`` as a determiner[fig-ambiguity-of-which]

For each lexical unit of the sentence, Unitex searches the dictionary of
the simple words of the text for all possible interpretations.
Afterwards, all combination of lexical units that have an interpretation
in the dictionary of the compound words of the text are taken into
account. All the combinations of these information constitute the
sentence automaton.

NOTE: If the text contains lexical labels (*e.g.*
``{out of date,.A+z1}``), these labels are reproduced identically in the
automaton without trying to decompose them.

In each box, the first line contains the inflected form found in the
text, and the second line contains the canonical form if it is
different. The other information is coded below the box. (cf.
section [section-displaying-sentence-automata]).

The spaces that separate the lexical units are not copied into the
automaton except for the spaces inside compound words.

The case of lexical units is retained. For example, if the word ``Here``
is encountered, the capital letter is preserved (cf.
figure [fig-sentence-automaton]). This choice allows you to keep this
information during the transition to the text automaton, which could be
useful for applications where case is important as for recognition of
proper names.

Normalization of ambiguous forms
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

During the construction of the automaton, it is possible to normalize
ambiguous forms by applying a normalization grammar. This grammar has to
be called ``Norm.fst2`` and must be placed in your working directory, in
the subdirectory ``/Graphs/Normalization`` of the language.
Normalization grammars for ambiguous forms are described in
section [section-normalizing-text-automataon].

If a sequence of the text is recognized by the normalization grammar,
all the interpretations that are described by the grammar are inserted
into the text automaton. Figure [fig-example-tfst-normalization-graph]
shows the part of the grammar used for the ambiguity of the sequence
``l'`` in French.

.. figure:: resources/img/fig7-4.png
   :alt: Normalization of the sequence
   ``l’``\ [fig-example-tfst-normalization-graph]
   :width: 8.60000cm

   Normalization of the sequence
   ``l’``\ [fig-example-tfst-normalization-graph]

If this grammar is applied to a French sentence containing the sequence
``l'``, a sentence automaton that is similar to the one in
figure [fig-tfst-normalization-results] is obtained.

.. figure:: resources/img/fig7-5.png
   :alt: Automaton that has been normalized with the grammar of
   figure [fig-example-tfst-normalization-graph][fig-tfst-normalization-results]
   :width: 10.20000cm

   Automaton that has been normalized with the grammar of
   figure [fig-example-tfst-normalization-graph][fig-tfst-normalization-results]

You can see that the four rules for rewriting the sequence ``l'`` have
been applied, which has added four labels to the automaton. These labels
are not concurrent with the two preexisting paths for the sequence
``l'``, because of the “keep best paths” heuristic (see section
[section-keeping-best-paths]). The normalization at the time of the
construction of the automaton allows you to add paths to the automaton
but not to remove ones. Removing paths will be partially done by the
“keep best paths” heuristic, if enabled. To go further, you will need to
use the ELAG disambiguation functionality.

Normalization of clitic pronouns in Portuguese
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In Portuguese, verbs in the future tense and in the conditional can be
modified by the insertion of one or two clitic pronouns between the root
and the suffix of the verb. For example, the sequence *dir-me-ão* (*they
will tell me*), corresponds to the complete verbal form *dirão*,
associated with the pronoun *me*. In order to be able to manipulate this
underlying form, it is necessary to introduce it into the text automaton
in parallel to the original form. Thus, the user can search one or the
other form. The figures [fig-1285-not-normalized]
and [fig-1285-normalized] show the automaton of a sentence after
normalization of the clitics.

.. figure:: resources/img/fig7-6.png
   :alt: Text automaton without normalization[fig-1285-not-normalized]
   :width: 11.00000cm

   Text automaton without normalization[fig-1285-not-normalized]

.. figure:: resources/img/fig7-7.png
   :alt: Normalized text automaton[fig-1285-normalized]
   :width: 11.00000cm

   Normalized text automaton[fig-1285-normalized]

The ``Reconstrucao`` program allows you to construct a normalization
grammar for these forms for each text dynamically. The grammar thus
produced can then be used for normalizing the text automaton. The
configuration window of the automaton construction suggests an option
“Build clitic normalization grammar” (cf.
figure [fig-Txt2Tfst-configuration]). This option automatically starts
the construction of the normalization grammar, which is then used to
construct the text automaton, if you have selected the option “Apply the
Normalization grammar”.

Keeping the best paths
~~~~~~~~~~~~~~~~~~~~~~

An unknown word can perturb the text automaton by overlapping with a
completely labeled sequence. Thus, in the automaton of
figure [fig-unknown-word-ambiguity], it can be seen that the adverb

``aujourd'hui`` overlaps with the unknown word ``aujourd``, followed by
an apostrophe and the past participle of the verb ``huir``.

.. figure:: resources/img/fig7-8.png
   :alt: Ambiguity due to a sentence containing an unknown
   word[fig-unknown-word-ambiguity]
   :width: 11.60000cm

   Ambiguity due to a sentence containing an unknown
   word[fig-unknown-word-ambiguity]

.. figure:: resources/img/fig7-9.png
   :alt: Automaton of a Thai sentence[fig-thai-sentence-automaton]
   :width: 14.00000cm

   Automaton of a Thai sentence[fig-thai-sentence-automaton]

This phenomenon can also take place in the treatment of certain Asian
languages like Thai. When words are not delimited, there is no other
solution than to consider all possible combinations, which causes the
creation of numerous paths carrying unknown words that are mixed with
the labeled paths. Figure [fig-thai-sentence-automaton] shows an example
of such an automaton of a Thai sentence.

It is possible to suppress parasite paths. You have to select the option
“Clean Text FST” in the configuration window for the construction of the
text automaton (cf. figure [fig-Txt2Tfst-configuration]). This option
indicates to the automaton construction program that it should clean up
each sentence automaton.

.. figure:: resources/img/fig7-10.png
   :alt: Configuration of the construction of the text automaton
   [fig-Txt2Tfst-configuration]
   :width: 14.00000cm

   Configuration of the construction of the text automaton
   [fig-Txt2Tfst-configuration]

This cleaning is carried out according to the following principle: if
several paths are concurrent in the automaton, the program keeps those
that contain the fewest unlabeled tokens. For instance, the compound
adverb ``aujourd'hui`` is preferred to the sequence made of ``aujourd``
followed by a quote and ``hui``, because ``aujourd`` and the quote are
both unlabeled tokens, while the compound adverb path does not contain
any unknown word. Figure [fig-clean-thai-sentence-automaton] shows the
automaton of figure [fig-thai-sentence-automaton] after cleaning.

.. figure:: resources/img/fig7-11.png
   :alt: Automaton of figure [fig-thai-sentence-automaton] after
   cleaning[fig-clean-thai-sentence-automaton]
   :width: 10.00000cm

   Automaton of figure [fig-thai-sentence-automaton] after
   cleaning[fig-clean-thai-sentence-automaton]

Resolving Lexical Ambiguities with ELAG
---------------------------------------

The ELAG program allows for applying grammars for ambiguity removal to
the text automaton. This powerful mechanism makes it possible to write
rules on independently from already existing rules. This chapter briefly
presents the grammar formalism used by ELAG and describes how the
program works. For more details, the reader may refer to
:raw-latex:`\cite{elag-blanc-dister}` and :raw-latex:`\cite{ELAG}`.

Grammars For Resolving Ambiguities
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The grammars used by ELAG have a special syntax. They consist of two
parts which we call the *if* and *then* parts. The *if* part of an ELAG
grammar is divided in two parts which are divided by a box containing
the ``<!>`` symbol. The *then* part is divided the same way using the
``<=>`` symbol. The meaning of a grammar is the following: In the text
automaton, if a path of the *if* part is recognized, then it must also
be recognized by the *then* part of the grammar, or it will be withdrawn
from the text automaton.

.. figure:: resources/img/fig7-12.png
   :alt: ELAG grammar ``elag-tu.grf``\ [fig-elag-tu]
   :width: 13.10000cm

   ELAG grammar ``elag-tu.grf``\ [fig-elag-tu]

Figure [fig-elag-tu] shows an example of a grammar. The *if* part
recognizes a verb in the 2\ :math:`^{nd}` person singular followed by a
dash and ``tu``, either as a pronoun, or as a past participle of the
verb ``taire``. The *then* part imposes that ``tu`` is then regarded as
a pronoun. Figure [fig-applying-tu-grammar] shows the result of the
application of this grammar on the sentence “*Feras-tu cela
bientôt\ :math:`~`?*”. One can see in the automaton at the bottom that
the path corresponding to ``tu`` past participle was eliminated.

.. figure:: resources/img/fig7-13.png
   :alt: Result of applying the grammar in figure [fig-elag-tu]
   [fig-applying-tu-grammar]
   :width: 14.00000cm

   Result of applying the grammar in figure [fig-elag-tu]
   [fig-applying-tu-grammar]

.. figure:: resources/img/fig7-14.png
   :alt: Use of the synchronization point[fig-synchronization-point]
   :width: 14.00000cm

   Use of the synchronization point[fig-synchronization-point]

Synchronization point
^^^^^^^^^^^^^^^^^^^^^

The *if* and *then* parts of an ELAG grammar are divided into two parts
by ``<!>`` in the *if* part, and ``<=>`` in the *then* part. These
symbols form a *synchronization point*. This makes it possible to write
rules in which the *if* and *then* constraints are not necessarily
aligned, as it is the case for example in
figure [fig-synchronization-point]. This grammar is interpreted in the
following way: if a dash is found followed by ``il``, ``elle`` or
``on``, then this dash must be preceded by a verb, possibly followed by
``-t``. So, if one considers the sentence of the figure [fig-est-il]
beginning with *Est-il*, one can see that all non-verb interpretations
of ``Est`` were removed.

.. figure:: resources/img/fig7-15.png
   :alt: Result of the application of the grammar in
   figure [fig-synchronization-point][fig-est-il]
   :width: 14.00000cm

   Result of the application of the grammar in
   figure [fig-synchronization-point][fig-est-il]

Compiling ELAG Grammars
~~~~~~~~~~~~~~~~~~~~~~~

Before an ELAG grammar can be applied to a text automaton, the grammar
must be compiled in a ``.rul`` file. This operation is carried out via
the “Elag Rules” command in the “Text” menu, which opens the windows
shown in figure [fig-elag-rules].

.. figure:: resources/img/fig7-16.png
   :alt: ELAG grammars compilation frame[fig-elag-rules]
   :width: 15.00000cm

   ELAG grammars compilation frame[fig-elag-rules]

If the frame on the right already contains grammars which you don’t wish
to use, you can withdraw them with the “<<” button. Then select your
grammar(s) in the file explorer located in the left frame, and click on
the “>>” button to add them to the list in the right frame. Then click
on the “Compile” button. This will launch the ``ElagComp`` program which
will compile the selected grammars and create a file named ``elag.rul``
by default.

If you have selected grammars in the right frame, you can search
patterns whith them by clicking on the “Locate” button. This opens the
window “Locate Pattern” and automatically enters a graph name ending
with ``-conc.fst2``. This graphs corresponds to the *if* part of the
grammar. You can thus obtain the occurrences of the text to which the
grammar will apply.

NOTE: The ``-conc.fst2`` file used to locate the *if* part of a grammar
is automatically generated when ELAG grammars are compiled by means of
the “Compile” button. It is thus necessary to have your grammar compiled
before searching using the “Locate” button.

Resolving Ambiguities
~~~~~~~~~~~~~~~~~~~~~

Once you have compiled your grammar into an ``elag.rul`` file, you can
apply it to a text automaton. In the text automaton window, click on the
“Apply Elag Rule” button. A dialog box will appear which asks for the
``.rul`` file to be used (see figure [fig-text-auto1]). The default file
is ``elag.rul``. This will launch the ``Elag`` program which will try to
resolve the ambiguity.

.. figure:: resources/img/fig7-17.png
   :alt: Text automaton frame [fig-text-auto1]
   :width: 12.00000cm

   Text automaton frame [fig-text-auto1]

Once the program has finished you can view the resulting automaton by
clicking on the “Open Elag Frame” button. As you can see in
figure [fig-text-auto2], the windows is separated into two parts: The
original text automaton can be seen on the top, and the result at the
bottom.

.. figure:: resources/img/fig7-18.png
   :alt: Splitted text automaton frame [fig-text-auto2]
   :width: 12.00000cm

   Splitted text automaton frame [fig-text-auto2]

Don’t be surprised if the automaton shown at the bottom seems more
complicated. This results from the fact that factorized lexical
entries [1]_ were exploded in order to treat each inflectional
interpretation separately. To refactorize these entries, click on the
“Implode” button. Clicking on the “Explode” button shows you an exploded
view of the text automaton.

If you click on the “Replace” button, the resulting automaton will
become the new text automaton. Thus, if you use other grammars, they
will apply to the already partially disambiguated automaton, which makes
it possible to accumulate the effects of several grammars.

Grammar collections
~~~~~~~~~~~~~~~~~~~

It is possible to gather several ELAG grammars into a grammar collection
in order to compile and apply them in one step. The sets of ELAG
grammars are described in ``.lst`` files. They are managed through the
window for compiling ELAG grammars (figure [fig-elag-rules]). The label
on the top left indicates the name of the current collection, by default
``elag.lst``. The contents of this collection are displayed in the right
part of the window.

To modify the name of the collection, click on the “Browse” button. In
the dialog box that appears, enter the ``.lst`` file name for the
collection.

To add a grammar to the collection, select it in the file explorer in
the left frame, and click on the “>>” button. Once you have selected all
your grammars, compile them by clicking on the “Compile” button. This
will create a ``.rul`` file bearing the name indicated at the bottom
right (the name of the file is obtained by replacing ``.lst`` by
``.rul``).

You can now apply your grammar collection. As explained above, click on
the “Apply Elag Rule” button in the text automaton window. When the
dialog asks for the ``.rul`` file to use, click on the “Browse” button
and select your collection. The resulting automaton is identical to that
which would have been obtained by applying each grammar successively.

Window For ELAG Processing
~~~~~~~~~~~~~~~~~~~~~~~~~~

At the time of disambiguation, the ``Elag`` program is launched in a
processing window which displays the messages printed by the program
during its execution.

For example, when the text automaton contains symbols which do not
correspond to the set of ELAG labels (see the following section), a
message indicates the nature of the error. In the same way, when a
sentence is rejected (all possible analyses were eliminated by
grammars), a message indicates the number of the sentence. That makes it
possible to locate the source of the problems quickly.

Evaluation of ambiguity removal
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

The assessment of the ambiguity rate is not based solely on the average
number of interpretations per word. In order to get a more
representative measure, the system also takes into account the various
combinations of words. While instances of ambiguities are resolved, the
``Elag`` program calculates the number of possible analyses in the text
automaton before and after the modification (which corresponds to the
number of possible paths through the automaton). On the basis of this
value, the program computes the average ambiguity by sentence and word.
It is this last measure which is used to represent the ambiguity rate of
the text, because it does not vary with the size of the corpus, nor with
the number of sentences within. The formula applied is:

*lexical ambiguity
rate*\ :math:`=exp^{\frac{log(number-of-paths)}{text-length}}`

The relationship between the ambiguity rate before and after applying
the grammars gives a measure of their efficiency. All this information
is displayed in the ELAG processing window.

Description of the tag sets
~~~~~~~~~~~~~~~~~~~~~~~~~~~

The ``Elag`` and ``ElagComp`` programs require a formal description of
the tag set to be used in dictionaries. This description consists
essentially of an enumeration of all the parts of speech present in the
dictionaries, with, for each of them, the list of syntactic and
inflectional codes compatible with it, and a description of their
possible combinations. This description must be contained in a file
called ``tagset.def`` and placed in your working directory, in the
``Elag`` subdirectory of the language.

``tagset.def`` file
^^^^^^^^^^^^^^^^^^^

Here is an extract of the ``tagset.def`` file used for French.

::



    NAME french

    POS ADV
    .

    POS PRO
    flex:
    pers   = 1 2 3
    genre  = m f
    nombre = s p
    discr:
    subcat = Pind Pdem PpvIL PpvLUI PpvLE Ton PpvPR PronQ Dnom Pposs1s...
    complete:
    Pind     <genre> <nombre>
    Pdem     <genre> <nombre>
    Pposs1s  <genre> <nombre>
    Pposs1p  <genre> <nombre>
    Pposs2s  <genre> <nombre>
    Pposs2p  <genre> <nombre>
    Pposs3s  <genre> <nombre>
    Pposs3p  <genre> <nombre>
    PpvIL    <genre> <nombre> <pers>
    PpvLE    <genre> <nombre> <pers>
    PpvLUI   <genre> <nombre> <pers>      #
    Ton      <genre> <nombre> <pers>      # lui, elle, moi
    PpvPR                                 # en y
    PronQ                                 # ou qui que quoi
    Dnom                                  # rien
    .

    POS A ## adjectifs
    flex:
    genre  = m f
    nombre = s p
    cat:
    gauche = g
    droite = d
    complete:
    <genre> <nombre>
    _  # pour {de bonne humeur,.A}, {au bord des larmes,.A} par exemple
    .


    POS V
    flex:
    temps  = C F I J K P S T W Y G X
    pers   = 1 2 3
    genre  = m f
    nombre = s p
    complete:
    W
    G
    C <pers> <nombre>
    F <pers> <nombre>
    I <pers> <nombre>
    J <pers> <nombre>
    P <pers> <nombre>
    S <pers> <nombre>
    T <pers> <nombre>
    X 1 s   # eusse dusse puisse fusse (-je)
    Y 1 p
    Y 2 <nombre>
    K <genre> <nombre>
    .

The ``#`` symbol indicates that the remainder of the line is a comment.
A comment can appear at any place in the file. The file always starts
with the word ``NAME``, followed by an identifier (``french``, for
example). This is followed by the ``POS`` sections for each part of
speech. Each section describes the structure of the lexical tags of the
lexical entries belonging to the part of speech concerned. Each section
is composed of 4 parts which are all optional:

-  ``flex``: this part enumerates the inflectional codes belonging to
   the grammatical category. For example, the codes ``1,2,3`` which
   indicate the person of the entry are relevant for pronouns but not
   for adjectives. Each line describes an inflectional attribute
   (gender, time, etc.) and is made up of the attribute name, followed
   by the ``=`` character and the values which it can take. For example,
   the following line declares an attribute :math:`pers` being able to
   taking the values :math:`1`, :math:`2` or :math:`3`:

   ::

       pers = 1 2 3

-  ``cat``: this part declares the syntactic and semantic attributes
   which can be assigned to the entries belonging to the part of speech
   concerned. Each line describes an attribute and the values which it
   can take. The codes declared for the same attribute must be
   exclusive. In other words, an entry cannot take more than one value
   for the same attribute.

   On the other hand, all the tags in a given part of speech don’t
   necessarily take values for all the attribute of the part of speech.
   For example, to define the attribute ``niveau_de_langue`` which can
   take the values ``z1``, ``z2`` and ``z3``, the following line can be
   written:

   ::

       niveau_de_langue = z1 z2 z3

   but this attribute is not necessarily present in all words.

-  ``discr``: this part consists of a declaration of a unique attribute.
   The syntax is the same as in the ``cat`` part and the attribute
   described here must not be repeated there. This part allows for
   dividing the grammatical category in *discriminating* sub categories
   in which the entries have similar inflectional attributes. For
   pronouns for example, a person feature is assigned to entries that
   are part of the personal pronoun sub category but not to relative
   pronouns. These dependencies are described in the ``complete`` part;

-  ``complete``: this part describes the inflectional part of the tags
   of the words in the current part of speech. Each line describes a
   valid combination of inflectional codes by their discriminating sub
   category (if such a category was declared). If an attribute name is
   specified in angle brackets (``<`` and ``>``), this signifies that
   any value of this attribute may occur. It is possible as well to
   declare that an entry does not take any inflectional feature by means
   of a line containing only the ``_`` character (underscore). So for
   example, if we consider that the following lines extracted from the
   section describing the verbs:

   ::

       W
       K <genre> <nombre>

   They make it possible to declare that verbs in the infinitive
   (indicated by the ``W`` code) do not have other inflectional features
   while the forms in the past participle (``K`` code) are also assigned
   a gender and a number.

Description of the inflectional codes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

The principal function of the ``discr`` part is to divide a part of
speech into subcategories having similar inflectional behavior. These
subcategories are then used to facilitate writing the ``complete`` part.

For the legibility of the ELAG grammars, it is desirable that the
elements of the same subcategory all have the same inflectional
behavior; in this case the ``complete`` part is made up of only one line
per subcategory. Let us consider for example the following lines from
the pronoun description:

::

    Pdem  <genre> <nombre>
    PpvIl <genre> <nombre> <pers>
    PpvPr

These lines mean:

-  all the demonstrative pronouns (``PRO+Pdem>``) have only a gender and
   a number;

-  clitic pronouns in the nominative (``<PRO+PpvIl>``) are labelled
   grammatically in person, gender and number;

-  the prepositional pronouns (*en*, *y*) do not have any inflectional
   feature.

All combinations of inflectional features and discriminant subcategories
which appear in the dictionaries must be described in the ``tagset.def``
file; otherwise, the information in the corresponding entries will be
discarded by ELAG.

If words of the same subcategory differ by their inflectional profile,
it is necessary to write several lines into the ``complete`` part. The
disadvantage of this method of description is that it becomes difficult
to make the distinction between such words in an ELAG grammar.

If one considers the description given by the previous example of a
``tagset.def`` file, certain adjectives of French take a gender and a
number, whereas others to not have any inflectional feature. This allows
for coding fixed sequences like *de bonne humeur* as adjective, on the
basis of their syntactic behavior.

Consider a French dictionary with such sequences as invariable
adjectives without inflectional features. The problem is that if one
wants to refer exclusively to this type of adjectives in a
disambiguation grammar, the ``<A>`` symbol is not appropriate, since it
will recognize all adjectives. To circumvent this difficulty, it is
possible to deny an inflectional attribute by writing the ``@``
character right before one of the possible values for this attribute.
Thus, the ``<A:@m@p>`` symbol recognizes all the adjectives which have
neither a gender nor a number. Using this operator, it is possible to
write grammars like those in figure [fig-NA], which imposes agreement in
gender and number between a name and an adjective which suits [2]_. This
grammar will preserve the correct analysis of sentences like: *Les
personnes de bonne humeur m’insupportent*.

Is is however recommended to limit the use of the ``@`` operator,
because it harms the legibility of the grammars. It is preferable to
distinguish the labels which accept various inflectional combinations by
means of discriminating subcategories defined in the ``discr`` part.

.. figure:: resources/img/fig7-19.png
   :alt: ELAG grammar that verifies gender and number agreement[fig-NA]
   :width: 12.00000cm

   ELAG grammar that verifies gender and number agreement[fig-NA]

Optional Codes
^^^^^^^^^^^^^^

The optional syntactic and semantic codes are declared in the ``cat``
part. They can be used in ELAG grammars like other codes. The difference
is that these codes do not intervene to decide if a label must be
rejected as an invalid one while loading of the text autmaton.

In fact optional codes are independent of other codes, such as for
example the attribute of the language level (``z1``, ``z2`` or ``z3``).
In the same manner as for inflectional codes, it is possible to deny an
inflectional attribute by writing the ``!`` character right before the
name of the attribute. Thus, with our example file, the ``<A!gauche:f>``
symbol recognizes all adjectives in the feminine which do not have the
``gauche`` code [3]_.

All codes which are not declared in the ``tagset.def`` file are
discarded by ELAG. If a dictionary entry contains such a code, ELAG will
produce a warning and will withdraw the code from the entry.

Consequently, if two concurrent entries differ in the original text
automaton only by undeclared codes, these entries will become
indistinguishable by the programs and will thus be unified into only one
entry in the resulting automaton.

Thus, the set of labels described in the file ``tagset.def`` file is
compatible with the dictionaries distributed with Unitex, by factorizing
words which differ only by undeclared codes, and this independently of
the applied grammars.

For example, in the most complete version of the French dictionary, each
individual use of a verb is characterized by a reference to the lexicon
grammar table which contains it. We have considered until now that this
information is more relevant to syntax than to lexical analysis and we
thus don’t have integrated them into the description of the tagset. They
are thus automatically eliminated at the time when the text automaton is
loaded, which reduces the rate of ambiguity.

In order to distinguish the effects bound to the tagset from those of
the ELAG grammars, it is advised to proceed to a preliminary stage of
normalization of the text automaton before applying disambiguation
grammars to it. This normalization is carried out by applying to the
text automaton a grammar not imposing any constraint, like that of
figure [fig-elag-norm]. Note that this grammar is normally present in
the Unitex distribution and precompiled in the file ``norm.rul``.

.. figure:: resources/img/fig7-20.png
   :alt: ELAG grammar without any constraint[fig-elag-norm]
   :width: 9.00000cm

   ELAG grammar without any constraint[fig-elag-norm]

The result of applying such a grammar is that the original is cleaned of
all the codes which either are not described in the ``tagset.def`` file,
or do not conform to this description (because of unknown grammatical
categories or invalid combinations of inflectional features). By then
replacing the text automaton by this normalized automaton, one can be
sure that later modifications of the automaton will only be effects of
ELAG grammars.

Grammar Optimization
~~~~~~~~~~~~~~~~~~~~

Compilation of ELAG grammars by the ``ElagComp`` program consists in
building an automaton whose language is the set of the sequences of
lexical tags (or lexical analyses of a sentence) which are not accepted
by the grammars. This task is complex and can take a lot of time. It is
however possible to appreciably speed it up by observing certain
principles at the time of writing gramars.

Limiting the number of branches in the *then* part
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

It is recommended to limit the number of *then* parts of a grammar to a
minimum. This can reduce considerably the compile time of a grammar.
Generally, a grammar having many *then* parts can be rewritten with one
or two *then* parts, without a loss of legibility. It is for example the
case of the grammar in figure [fig-NA-bad], which imposes a constraint
between a verb and the pronoun which follows it.

.. figure:: resources/img/fig7-21.png
   :alt: ELAG grammar checking verb-pronoun agreement[fig-NA-bad]
   :width: 15.00000cm

   ELAG grammar checking verb-pronoun agreement[fig-NA-bad]

As one can see in figure [fig-NA-good], one can write an equivalent
grammar by factorizing all the *then* parts into only one. The two
grammars will have exactly the same effect on the text automaton, but
the second one will be compiled much more quickly.

.. figure:: resources/img/fig7-22.png
   :alt: Optimized ELAG grammar checking verb-pronoun
   agreement[fig-NA-good]
   :width: 15.00000cm

   Optimized ELAG grammar checking verb-pronoun agreement[fig-NA-good]

Using lexical masks
^^^^^^^^^^^^^^^^^^^

It is better to use lemmas only when it is necessary. That is
particularly true for some grammatical words, when their subcategories
carry almost as much information as the lemmas themselves. In any case,
it is recommended to specify its syntactic, semantic and inflectional
features as much as possible. For example, with the dictionaries
provided for French, it is preferable to replace lexical masks like
``<je.PRO:1s>``, ``<je.PRO+PpvIL:1s>`` and ``<je.PRO>`` with the mask
``<PRO+PpvI1:1s>``. Indeed, all these masks are identical insofar as
they can recognize only the single entry of the dictionary
``{je,PRO+PpvIL:1ms:1fs}``. However, as the program does not deduce this
information automatically, if all these features are not specified, the
program will consider nonexisting labels such as ``<je.PRO:3p>``,

``<je.PRO+PronQ>`` etc. in vain.

Linearizing text automaton with the tagger
------------------------------------------

By default, the text automaton contains many paths of tags because of
lexical ambiguity. The linearization process consists in selecting a
single path, a sequence of tags with one tag per token, and remove the
others. The output of the process is a text automaton with a single path
(see section [section-linear-text] for converting a linear automaton
into linear text). The selection of a path depends on its score. The
path with the best score is chosen and the others are removed. The score
of a path is calculated using a statistical model trained on an
annotated corpus. This model uses tagger data files generated by the
TrainingTagger program (see section [section-TrainingTagger]). For
instance, you can see on Figure [fig7-linearize2], the original text
automaton of the French sentence *Les insectes nuisibles envahissent la
maison*. The corresponding text automaton after linearization is shown
on Figure [fig7-linearize3].

.. figure:: resources/img/fig7-linearize2.png
   :alt: Text automaton of *Les insectes nuisibles envahissent la
   maison.*\ [fig7-linearize2]
   :width: 16.00000cm

   Text automaton of *Les insectes nuisibles envahissent la
   maison.*\ [fig7-linearize2]

.. figure:: resources/img/fig7-linearize3.png
   :alt: Text automaton linearized[fig7-linearize3]
   :width: 16.00000cm

   Text automaton linearized[fig7-linearize3]

Compatibility of the tagset
~~~~~~~~~~~~~~~~~~~~~~~~~~~

The tagset of the tagger is identical to that of the training corpus or
is a variant (see below). However, in order to use the tagger on a text
automaton, one should pay attention to tagset and morphology. The tagset
of the model must be identical to that of the text automaton. For
example, if the statistical model has been computed with the tag ``DET``
for the word ``the``, the corresponding tag in the text automaton must
be ``DET``. Unitex provides functionality to modify word forms in the
text, for example to normalize ``doesn't`` into ``does not``. Applying
replacing or normalization graphs could cause some morphological
modifications on words. If such processing is applied to the text, it
must have been applied to the training corpus as well. If these rules
are not respected, the tagger might not be able to keep the good path
from the text automaton.

The TrainingTagger program produces two variants of the tagger. The
first one prunes transitions on the basis of grammatical, semantic,
syntactic and inflectional codes (for example, ``the.DET+Ddef:s`` versus
``the.DET+Ddef:p``). The second one prunes transitions on the basis of
grammatical, semantic and syntactic codes (``that.DET+Ddem`` versus
``that.PRO+Pdem``). This option makes the training quicker and
inflectional features are not needed for all applications.

Use of the Tagger
~~~~~~~~~~~~~~~~~

In order to linearize the text automaton, you have to select the option
“Linearize with the Tagger” in the configuration window for the
construction of the text automaton (cf. figure [fig7-linearize1]). With
this option, the program will linearize each sentence automaton. You
must also select the tagger data file (with “.bin” extension) by
clicking on the “Set” button. Tagger data file suffixed by “morph” is
the first variant of the tagger (with inflectional codes) and the one
suffixed by “cat” is the second variant (without inflectional codes). If
you want to use the “morph” data, you also need to click on “Normalize
according to Elag tagset.def” (for more details, see section
[section-Tagger] about ``Tagger`` program).

.. figure:: resources/img/fig7-linearize1.png
   :alt: Configuration of the linearization of the text
   automaton[fig7-linearize1]
   :width: 13.00000cm

   Configuration of the linearization of the text
   automaton[fig7-linearize1]

For instance, the text automaton, shown on Figure [fig7-linearize3], is
the output of linearization of the text automaton shown on Figure
[fig7-linearize2] with “cat” tagger data. Linearization of the automaton
with “morph” tagger data is shown on Figure [fig7-linearize4].

.. figure:: resources/img/fig7-linearize4.png
   :alt: Text automaton linearized with “morph” tagger
   data[fig7-linearize4]
   :width: 16.00000cm

   Text automaton linearized with “morph” tagger data[fig7-linearize4]

Creation of a new tagger
~~~~~~~~~~~~~~~~~~~~~~~~

In order to create a new tagger for your language, you need to launch
the TrainingTagger program on your own annotated corpus. The format of
the annotated corpus is described in [section-corpus-file]. As we
discuss in Section [section-linearization-tagset], you need to pay
attention on tagset and morphology. Before computing a statistical
model, you have to decide which dictionaries and normalization graphs
you will use to construct the text automaton. And then, you will have to
do modifications on the annotated corpus if word forms or tagset do not
match completely. For example, if the normalization graph transforms the
word ``jusqu'`` into ``jusque``, the corresponding word into the
annotated corpus must be ``jusque``.

A French tagger is distributed with Unitex. It has been created with an
annotated corpus composed of tags without semantic and syntactic codes.

Manipulation of text automata
-----------------------------

Displaying sentence automata
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

As we have seen above, the text automaton is in fact the collection of
the sentence automata of a text. This structure can be represented using
the format ``.fst2``, also used for representing the compiled grammars.
This format does not allow the system to directly display the sentence
automata. Instead, the system uses the ``Fst2Grf`` program to convert
the sentence automaton into a graph that can be displayed. This program
is called automatically when you select a sentence in order to generate
the corresponding ``.grf`` file.

The generated ``.grf`` files are not interpreted in the same manner as
the ``.grf`` files that represent graphs constructed by the user. In
fact, in a normal graph, the lines of a box are separated by the ``+``
symbol. In the graph of a sentence, each box represents either a lexical
unit without a tag or a dictionary entry enclosed by curly brackets. If
the box only represents an unlabeled lexical unit, this unit appears
alone in the box. If the box represents a dictionary entry, the
inflected form is displayed, followed in another line by the canonical
form if it is different. The grammatical and inflectional information is
displayed below the box as a transducer output.

Figure [fig-first-sentence-Ivanhoe] shows the graph obtained for the
first sentence of *Ivanhoe*. The words ``Ivanhoe``, ``Walter`` and
``Scott`` are considered unknown words. The word ``by`` corresponds to
two entries in the dictionary. The word ``Sir`` corresponds to two
dictionary entries as well, but since the canonical form of these
entries is ``sir``, it is displayed because it differs from the
inflected form by a lower case letter.

.. figure:: resources/img/fig7-23.png
   :alt: Automaton of the first sentence of
   *Ivanhoe*\ [fig-first-sentence-Ivanhoe]
   :width: 11.00000cm

   Automaton of the first sentence of
   *Ivanhoe*\ [fig-first-sentence-Ivanhoe]

Modifying the text automaton
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

It is possible to manually modify sentence automata, except those in the
ELAG frame (lower frame). You can edit or erase boxes or transitions
(cf. figure [fig-modified-sentence-automaton]).

.. figure:: resources/img/fig7-24.png
   :alt: Modified sentence automaton[fig-modified-sentence-automaton]
   :width: 15.00000cm

   Modified sentence automaton[fig-modified-sentence-automaton]

When a graph is modified, it is saved to the text file
``sentenceN.grf``, where :math:`N` represents the number of the
sentence, but this operation does not modify the global text automaton.
Thus, you can discard the manually modified graph and reset the
automaton of that sentence from the global text automaton by clicking on
the “Reset Sentence Graph” button.

When you select a sentence, if a modified graph exists for this
sentence, Unitex displays it.

After you edited sentence automata, you can save your manual
modifications to the global text automaton. In order to do that, click
on the “Rebuild FST-Text” button. All sentences that have been modified
are then replaced by their modified versions. The new text automaton is
then automatically reloaded.

During the construction of the text automaton
([construction-text-automaton]), all the modified sentence graphs in the
text file are erased.

Manually resolving ambiguities
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

The text automaton may contain many paths of tags because of lexical
ambiguity. You can either resolve ambiguities with ELAG Grammars or
manually select the right paths for one or each graph of the sentence
automaton. To do so, you can perform a right click on the box you want
to keep when several boxes with different tags are proposed. The edges
of the selected box will become more bold and the other boxes will
appear grayed (see Figure [fig-manually-resolve-ambiguities]).

.. figure:: resources/img/fig7-24b.png
   :alt: Manually resolve ambiguities in sentence
   automaton[fig-manually-resolve-ambiguities]
   :width: 15.00000cm

   Manually resolve ambiguities in sentence
   automaton[fig-manually-resolve-ambiguities]

You can then click on the “Remove greyed states” button to keep only the
selected boxes as in Figure [fig-removed-ambiguities].

.. figure:: resources/img/fig7-24c.png
   :alt: Ambiguous boxes removed in sentence
   automaton[fig-removed-ambiguities]
   :width: 11.00000cm

   Ambiguous boxes removed in sentence
   automaton[fig-removed-ambiguities]

Display configuration
~~~~~~~~~~~~~~~~~~~~~

Sentence automata are subject to the same presentation options as the
graphs. They use the same colors and fonts as well as the antialiasing
effect. In order to configure the appearance of the sentence automata,
you modify the general configuration by clicking on “Preferences...” in
the “Info” menu. For further details, refer to
section [section-display-fonts-colors].

You can also print a sentence automaton by clicking on “Print...” in the
“FSGraph” menu or by pressing <Ctrl+P>. Make sure that the printer’s
page orientation is set to landscape mode. To configure this parameter,
click on “Page Setup” in the “FSGraph” menu.

Converting the text automaton into linear text
----------------------------------------------

If the text automaton does not contain any lexical ambiguity, it is
possible to build a text file corresponding to the unique path of the
automaton. Go into the “Text” menu and click on “Convert FST-Text to
Text...”. You can set the output text file in the window as shown on
Figure [fig-linearization-configuration].

.. figure:: resources/img/fig7-25.png
   :alt: Setting output file for linearization of the text
   automaton[fig-linearization-configuration]
   :width: 10.00000cm

   Setting output file for linearization of the text
   automaton[fig-linearization-configuration]

If the automaton is not linear, an error message will give you the
number of the first sentence that contain ambiguity. Otherwise, the
``Tfst2Unambig`` program will build the output file according to the
following rules:

-  the output file contains one line per sentence;

-  every line but the last is ended by ``{S}``;

-  for each box, the program writes its content followed by a space.

.. figure:: resources/img/fig7-26.png
   :alt: Example of a linear text automaton[fig-linear-automaton]
   :width: 12.00000cm

   Example of a linear text automaton[fig-linear-automaton]

NOTE: correcting spaces in the output text can only be done manually. If
the original text is the one of the text automaton shown on Figure
[fig-linear-automaton], the output text will be:

::

    2 3 {cats,cat.N+Anl:p} {are,be.V:P2s:P1p:P2p:P3p} {white,white.A} .

Searching patterns in the text automaton
----------------------------------------

With the ``LocateTfst`` program, Unitex can perform search operations on
the text automaton. The main advantages are that you can:

-  benefit from ambiguity removal;

-  benefit from the application of normalization grammar (see below);

-  work at several morphological levels (multi-word units, simple words,
   morphemes). This is particularly interesting since you can now easily
   manipulate agglutinative languages like Korean (for Korean, see
   section [section-korean]).

The rules are very similar to the ones that apply to classical searches
with ``Locate``. Here are the differences:

-  you cannot capture sequences with variables inside right contexts, as
   it is possible with ``Locate`` (see Figure [fig-context6], page )

-  you cannot match things that are not in the text automaton: if the
   text automaton only contains a compound word tag and not its
   concurrent simple word tags, you won’t be able to match simple words.
   For instance, in the sentence automaton shown on Figure
   [fig7-locatetfst1], it is not possible to match ``soixante`` or
   ``huit``, since there are no such paths.

   .. figure:: resources/img/fig7-locatetfst1.png
      :alt: Sentence automaton that cannot match with pattern
      *huit*\ [fig7-locatetfst1]
      :width: 9.00000cm

      Sentence automaton that cannot match with pattern
      *huit*\ [fig7-locatetfst1]

-  matched sequences can differ from sequences that will appear in
   concordances. In fact, the text automaton may contain tags that do
   not correspond to the raw input text, in particular when a
   normalization grammar has been applied. For instance, if you look for
   the pattern ``<le.DET>`` in *80jours*\ ’s text automaton, you will
   obtain 7703 matches, while ``Locate`` only finds 5763 matches. This
   is because some words have been normalized, like ``au``
   :math:`\rightarrow` ``à le`` or ``du`` :math:`\rightarrow` ``de le``.
   So, when you look for ``<le.DET>``, ``LocateTfst`` matches those tags
   that were added to the text automaton by the normalization grammar,
   and ``Concord`` uses the original sequence in the text to produce the
   concordance file, as shown on Figure [fig7-locatetfst2].

   .. figure:: resources/img/fig7-locatetfst2.png
      :alt: A surprising concordance for pattern
      ``<le.DET>``\ [fig7-locatetfst2]
      :width: 14.00000cm

      A surprising concordance for pattern
      ``<le.DET>``\ [fig7-locatetfst2]

-  ``<TOKEN>`` does not match tokens as defined in ``tokens.txt``. It
   matches any tag of the text automaton. Matched tags can be either
   longer than text tokens if they are compound word tags, or even
   shorter, if the text automaton contains morphological analysis like
   ``un`` as shown on Figure [morphoB], page .

-  even if you are not in morphological mode, you can define
   dictionary-entry variables (cf. section [dictionary-variables]).
   Then, you can get from such variables the inflected form, lemma and
   codes of lexical entries, their POS code, semantic codes,
   inflectional codes and the value ``zzz`` of the ``yyy`` attribute if
   there is a code of the form ``yyy=zzz``.

Table display
-------------

Sentence automata can be displayed in a table format. To do that, you
just have to select the “Table” tab in the text automaton frame. You
will then see a table as shown on Figure [fig7-table1].

.. figure:: resources/img/fig7-table1.png
   :alt: Table display[fig7-table1]
   :width: 14.50000cm

   Table display[fig7-table1]

This table is not fully equivalent to the sentence automaton, since it
only displays all possible POS for each simple or multiple word unit. It
should be considered as an approximate compact view of information
contained in the automaton. You can also filter grammatical/semantic
codes to be displayed. Select “All” and you will see all codes. Select
“Only POS category” and only first codes (supposed to represent the POS
category) will be displayed. If you select “Use filter” and set a
regular expression :math:`X`, codes that do not contain something
matched by :math:`X` will be discarded. Any POSIX regular expression is
accepted as filter. Check “Always show POS category”, and as said, the
POS category will be kept even if not matched by the filter, if any. For
instance, Figure [fig7-table2] shows a filtering result, obtained with
the filter ``^[A-Z]`` that matches any code starting with an uppercase
letter, thus discarding codes like ``z1``.

.. figure:: resources/img/fig7-table2.png
   :alt: Filtered table display[fig7-table2]
   :width: 14.50000cm

   Filtered table display[fig7-table2]

The “Export all text as POS list” button can be used to export this
table display of the whole text automaton as a text file following a
special format. Currently, it is only an experimental feature that may
change in the future. Here is an example of output:

::

    (Je/N:ms:mp)|(Je/PRO/PpvIL:1fs:1ms) (suis/V:P1s)|(suis/V:Y2s:P2s:P1s) 
    M/N:mp:ms . Mdiba (de/DET/Dind:fp:mp:fs:ms)|(de/PREP)|(de/PREP/z1
    +de la/DET/Dind/z1:fs)|(de/PREP/z1+des/DET/Dind/z1:mp:fp)|(de/PREP/z1
    +du/DET/Dind/z1:ms)|(de la/DET/Dind/z1:fs)|(des/DET/Dind/z1:mp:fp)|
    (du/DET/Dind/z1:ms) LG - ville/N:fs . {S}

The special case of Korean
--------------------------

Korean is an agglutinative language with a unique writing system: words
are made of Hangul syllabic characters, but one Hangul character
corresponds to several Jamo alphabetic characters. For instance, you can
see on Figure [fig7-korean1] two examples of Hangul characters followed
by their equivalent Jamo letter sequences.

.. figure:: resources/img/fig7-korean1.png
   :alt: Hangul characters and their equivalent Jamo
   sequences[fig7-korean1]
   :width: 4.50000cm

   Hangul characters and their equivalent Jamo sequences[fig7-korean1]

Not all morphemes correspond to Hangul characters. For instance, Figure
[fig7-korean2] shows a given token (shown in green) analyzed as a
combination of two elements: a verb and a modifier. The point is that
the modifier is only made of one Jamo letter that combines with the last
Hangul character of the verb in order to give the last Hangul character
of the whole word (in green).

.. figure:: resources/img/fig7-korean2.png
   :alt: Decomposition of a Hangul character[fig7-korean2]
   :width: 6.00000cm

   Decomposition of a Hangul character[fig7-korean2]

As a consequence, it can be convenient for Korean users to write
grammars with mixes of Hangul and Jamo characters. Thus, a grammar like
the one shown on Figure [fig7-korean3] will match sequences like the one
shown Figure [fig7-korean4].

.. figure:: resources/img/fig7-korean3.png
   :alt: A grammar with two Jamo letters[fig7-korean3]
   :width: 5.50000cm

   A grammar with two Jamo letters[fig7-korean3]

.. figure:: resources/img/fig7-korean4.png
   :alt: Sentence automaton matched by grammar of Figure
   [fig7-korean3][fig7-korean4]
   :width: 13.00000cm

   Sentence automaton matched by grammar of Figure
   [fig7-korean3][fig7-korean4]

In Korean, the text automaton displays untagged tokens on a
lavender-blue background. [4]_

REMARKS:

#. Jamo letters are not in the Korean alphabet file (``Alphabet.txt``).
   DO NOT ADD THEM TO THIS FILE, because it would induce dysfunctions in
   programs.

#. This alphabet file contains equivalences between some Chinese
   characters and some Hangul ones. In practice, if a grammar contains a
   Chinese character that has such an equivalent Hangul, it will match
   this Hangul in the text automaton. For instance, the grammar shown on
   Figure [fig7-korean5] will match the sentence of Figure
   [fig7-korean4], because the Korean alphabet file contains an
   equivalence for that character, as shown on Figure [fig7-korean6].

.. figure:: resources/img/fig7-korean5.png
   :alt: A grammar with a Chinese character[fig7-korean5]
   :width: 5.00000cm

   A grammar with a Chinese character[fig7-korean5]

.. figure:: resources/img/fig7-korean6.png
   :alt: Extract of Korean alphabet file[fig7-korean6]
   :width: 3.50000cm

   Extract of Korean alphabet file[fig7-korean6]

.. [1]
   Entries which gather several different inflectional interpretations,
   such as for example:

   ``{se,.PRO+PpvLE:3ms:3fs:3mp:3fp}``.

.. [2]
   This grammar is not completely correct, because it eliminates for
   example the correct analysis of the sentence: *J’ai reçu des coups de
   fil de ma mère hallucinants.*

.. [3]
   This code indicates that the adjective must appear on the left of the
   nound to which it refers to, as is the case for *bel*.

.. [4]
   In Korean, versions before 3.1beta rev. 4272 display untagged tokens
   on a green background, as in Fig. [fig7-korean2] and [fig7-korean4].
