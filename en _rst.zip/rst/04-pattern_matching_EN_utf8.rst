Searching with regular expressions
==================================

This chapter describes how to search a text for simple patterns by using
regular expressions.

Definition
----------

The goal of this chapter is not to give an introduction on formal
languages but to show how to use regular expressions in Unitex in order
to search for simple patterns. Readers who are interested in a more
formal presentation can consult the many works that discuss regular
expression patterns.

A regular expression can be:

-  a token (``book``) or a lexical mask (``<smoke.V>``);

-  a particular position in the text : the beginning ``{^}`` or the end
   ``{$}``

-  the concatenation of two regular expressions (``he smokes``);

-  the union of two regular expressions (``Pierre+Paul``);

-  the Kleene star of a regular expression (``bye*``).

Tokens
------

In a regular expression, a token is defined as in [tokenization] (page
). Note that the symbols dot, plus, star, less than, opening and closing
parentheses and double quotes have a special meaning. It is therefore
necessary to precede them with an escape character ``\`` if you want to
search for them. Here are some examples of valid tokens:

::

    cat
    \.
    <N:ms>
    {S}

By default, Unitex is set up to let lower case patterns also find
upper-case matches. It is possibe to enforce case-sensitive matching
using quotation marks. Thus, ``"peter"`` recognizes only the form
``peter`` and not ``Peter`` or ``PETER``.

NOTE: in order to make a space obligatory, it needs to be enclosed in
quotation marks.

Lexical masks
-------------

A lexical mask is a search query that matches tokens or sequences of
tokens.

Special symbols
~~~~~~~~~~~~~~~

There are two kinds of lexical masks. The first category contains the
special symbols or meta-symbols introduced in
section [section-sentence-splitting] except for ``<PNC>`` and ``<^>``.
(The symbol ``<PNC>``, which matches punctuation signs, is valid only
during preprocessing; ``<^>`` matches a line feed, but since all line
feeds have been replaced by spaces, this symbol cannot be useful anymore
when searching for lexical masks.) The meta-symbols that can be used to
search a text for patterns are the following:

-  ``<E>``: the empty word or epsilon. Matches the empty string;

-  ``<TOKEN>``: matches any token, except the space; used by default for
   morphological filters

-  ``<WORD>``: matches any token that consists of letters;

-  ``<LOWER>``: matches any lower-case token;

-  ``<UPPER>``: matches any upper-case token;

-  ``<FIRST>``: matches any token that consists of letters and starts
   with a capital lette;

-  ``<DIC>``: matches any word that is present in the dictionaries of
   the text;

-  ``<SDIC>``: matches any simple word in the text dictionaries;

-  ``<CDIC>``: matches any composed word in the dictionaries of the
   text;

-  ``<TDIC>``: matches any tagged token like ``{XXX,XXX.XXX}``;

-  ``<NB>``: matches any contiguous sequence of digit (1234 is matched
   but not 1 234);

-  ``#``: prohibits the presence of space.

Earlier codes for ``<WORD>``, ``<LOWER>``, ``<UPPER>`` and ``<FIRST>``
were respectively ``<MOT>``, ``<MIN>``, ``<MAJ>`` and ``<PRE>``. They
can still be used for backward compatibility of the system with existing
graphs. Though there are no current plans to remove this codes, it is
recommended to avoid them in graphs designed to be used with more recent
versions, [1]_ so that the number of lexical masks in use does not
increase uselessly.

NOTE: as described in section [tokenization], NO meta can be used to
match the ``{STOP}`` marker, not even ``<TOKEN>``.

References to information in the dictionaries
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The second kind of lexical masks refers to the information in the text
dictionaries. The four possible forms are:

-  ``<be>``: matches all the entries that have ``be`` as canonical form.
   Note that this pattern is ambiguous if ``be`` is also a grammatical
   or semantic code;

-  ``<be.>``: matches all the entries that have ``be`` as canonical
   form. This pattern is not ambiguous as the previous one;

-  ``<be.V>``: matches all entries having ``be`` as canonical form and
   the grammatical code ``V``;

-  ``<V>``: matches all entries having the grammatical code ``V``. This
   pattern is as ambiguous as the first one. To remove the ambiguity,
   you can use either ``<.V>`` or ``<+V>``;

-  ``{am,be.V} or <am,be.V>``: matches all the entries having ``am`` as
   inflected form, ``be`` as canonical form and the grammatical code
   ``V``. This kind of lexical mask is only of interest if applied to
   the text automaton where all the ambiguity of the words is explicit.
   While executing a search on the text, that lexical mask matches the
   same as the simple token ``am``.

Grammatical and semantic constraints
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The references to dictionary information (``be``, ``V``) in these
examples are basic. It is possible to express more complex lexical masks
by using several grammatical or semantic codes separated by the
character ``+``. If several codes are present, the character ``+`` means
‘’and’’: an entry of the dictionary is only found if it has all the
codes that are present in the mask. The mask ``<N+z1>`` thus recognizes
the entries:

``broderies,broderie.N+z1:fp``

``capitales européennes,capitale européenne.N+NA+Conc+HumColl+z1:fp``

but not:

``Descartes,René Descartes.N+Hum+NPropre:ms``

``habitué,.A+z1:ms``

It is possible to exclude codes by preceding them with the character
``~`` instead of ``+``. In order to be recognized, an entry has to
contain all the codes required by the lexical mask and none of the
prohibited ones. For instance, ``<A~z3>`` matches the entries that have
the code ``A`` without the code ``z3`` (cf.
table [tab-semantic-codes]). [2]_ If you want to refer to a code
containing the character ``~`` you have to escape this character by
preceding it with a ``\``.

CHANGE NOTE: before version 2.1, the negation operator was the minus. If
you want to preserve backward compatibility without modifying your
graphs, you have to call ``Locate`` by hand with the ``-g minus``
option.

The syntax of lexical masks does not make any difference between
grammatical codes (table [tab-grammatical-codes]) and semantic codes
(table [tab-semantic-codes]). In the DELAF dictionary format,
grammatical codes are those that appear first and encode the part of
speech, but in Unitex lexical masks, the order in which grammatical and
semantic codes appear does not matter. The three following patterns are
equivalent:

::

    <N~Hum+z1>
    <z1+N~Hum>
    <~Hum+z1+N>

A lexical mask can contain a semantic code without a part-of-speech
code.

NOTE: it is not possible to use a lexical mask that only has prohibited
codes. ``<~N>`` and ``<~A~z1>`` are thus incorrect masks. However, you
can express such constraints using contexts (see
section [section-contexts]).

Inflectional constraints
~~~~~~~~~~~~~~~~~~~~~~~~

It is also possible to specify constraints about inflectional codes.
These constraints have to be preceded by at least one grammatical or
semantic code. They are represented in the same format as the
inflectional codes in the dictionaries. Here are some French examples of
lexical masks using inflectional constraints:

-  ``<A:m>`` recognizes a adjective in the masculine;

-  ``<A:mp>`` recognizes an adjective in the masculine plural.

An inflectional code is introduced by the ``:`` character and is made up
of one or more characters, each of which represents one piece of
information. Let us consider first the simple case of dictionary entries
and masks which have exactly one inflectional code. In order to let a
dictionary entry :math:`E` be recognized by a mask :math:`M`, it is
necessary that the inflectional code of :math:`E` contains all the
characters of the inflectional code of :math:`M`:

:math:`E`\ =\ ``pretext,.V:P3p``

:math:`M`\ =\ ``<V:P3>``

The inflectional code ``P3p`` of :math:`E` contains both characters
``P`` and ``3``. The code ``P3`` is included in the code of :math:`E`.
Therefore, mask :math:`M` recognizes entry :math:`E`.

The order of the characters inside an inflectional code is without
importance. All the grammatical and semantic codes must precede the
inflectional codes.

If several inflectional codes are present in a lexical mask, the ``:``
character means ‘’or’’:

-  ``<A:mp:f>`` matches both ``<A:mp>`` and ``<A:f>``; it recognizes
   adjectives in the masculine plural or in the feminine;

-  ``<V:2:3>`` recognizes a verb in the 2nd or 3rd person; that excludes
   all tenses that have neither a 2nd or 3rd person (infinitive, past
   participle and present participle) as well as the tenses that are
   conjugated in the first person.

In order to let a dictionary entry :math:`E` be recognized by a mask
:math:`M`, it is necessary that at least one inflectional code of
:math:`E` contains all the characters of at least one inflectional code
of :math:`M`. Consider the following example:

:math:`E`\ =\ ``pretext,.V:W:P1s:P2s:P1p:P2p:P3p``

:math:`M`\ =\ ``<V:P3s:P3>``

No inflectional code of :math:`E` contains the characters ``P``, ``3``
and ``s`` at the same time. However, the code ``P3p`` of :math:`E` does
contain both characters ``P`` and ``3``. The code ``P3`` is included in
at least one code of :math:`E`. Therefore, mask :math:`M` recognizes
entry :math:`E`.

Negation of a lexical mask
~~~~~~~~~~~~~~~~~~~~~~~~~~

It is possible to negate a lexical mask by placing the character \ ``!``
immediately after the character \ ``<``. Negation is possible with the
masks ``<WORD>``, ``<LOWER>``, ``<UPPER>``, ``<FIRST>``, [3]_ ``<DIC>``
as well as with the masks that carry grammatical, semantic of
inflectional codes (*i.e.* ``<!V~z3:P3>``). The masks ``#`` and ``" "``
are the negation of each other. The mask ``<!WORD>`` recognizes all
tokens that do not consist of letters except for the sentence delimiter
``{S}`` and the ``{STOP}`` marker. Negation has no effect on ``<NB>``,
``<SDIC>``, ``<CDIC>``, ``<TDIC>`` and ``<TOKEN>``.

The negation is interpreted in a special way in the masks ``<!DIC>``,
``<!LOWER>``, ``<!UPPER>`` and ``<!FIRST>``. [4]_ Instead of recognizing
all forms that are not recognized by the mask without negation, these
masks find only forms that are sequences of letters. Thus, the mask
``<!DIC>`` allows you to find all unknown words in a text. These unknown
forms are mostly proper names, neologisms and spelling errors (cf.
Figure [fig-search-<!DIC>]).

.. figure:: resources/img/fig4-1.png
   :alt: Result of the search for ``<!DIC>``\ [fig-search-<!DIC>]
   :width: 15.00000cm

   Result of the search for ``<!DIC>``\ [fig-search-<!DIC>]

The negation of a dictionary mask like ``<V:G>`` will match any word,
except for those that are matched by this mask. For instance, ``<!V:G>``
will not match the word ``being``, even if there are homonymic
non-verbal entries in the dictionaries:

::

    being,.A
    being,.N+Abst:s
    being,.N+Hum:s

Here are some examples of lexical masks with the different types of
constraints:

-  ``<A~Hum:fs>``: a non-human adjective in the feminine singular;

-  ``<lire.V:P:F>``: the verb *lire* in the present or future tense;

-  ``<suis,suivre.V>``: the word *suis* as inflected form of the verb
   *suivre* (as opposed to the form of the verb *être*);

-  ``<facteur.N~Hum>``: all nominal entries that have *facteur* as
   canonical form and that do not have the semantic code ``Hum``;

-  ``<!ADV>``: all words that are not adverbs;

-  ``<!WORD>``: all tokens that are not made of letters (cf.
   figure [fig-search-<!WORD>]). This mask does not recognize the
   sentence delimiter ``{S}`` and the special tag ``{STOP}``.

.. figure:: resources/img/fig4-2.png
   :alt: Result of a search for the pattern
   ``<!WORD>``\ [fig-search-<!WORD>]
   :width: 15.00000cm

   Result of a search for the pattern ``<!WORD>``\ [fig-search-<!WORD>]

Concatenation
-------------

There are three ways to concatenate regular expressions. The first
consists in using the concatenation operator which is represented by the
dot. Thus, the expression:

::

    <DET>.<N>

recognizes a determiner followed by a noun. The space can also be used
for concatenation, as well as the empty string. The following
expressions:

::

    the <A> cat
    the<A>cat

recognizes the token *the*, followed by an adjective and the token
*cat*. The parenthesis are used as delimiters of a regular expression.
All of the following expressions are equivalent:

::

    the <A> cat
    (the <A>)cat
    the.<A>cat
    (the).<A> cat
    (the.(<A>)) (cat)

Union
-----

The union of regular expressions is expressed by typing the character
``+`` between them. The expression

::

    (I+you+he+she+it+we+they)<V>

recognizes a pronoun followed by a verb. If an element in an expression
is optional, it is sufficient to use the union of this element and the
empty word epsilon. Examples:

``the (little+<E>) cat`` recognizes the sequences *the cat* and *the
little cat*

``(<E>+Anglo-).(French+Indian)`` recognizes *French*, *Indian*,
*Anglo-French* and *Anglo-Indian*

Kleene star
-----------

The Kleene star, represented by the character ``*``, allows you to
recognize zero, one or several occurrences of an expression. The star
must be placed on the right hand side of the element in question. The
expression:

::

    this is very* cold

recognizes *this is cold*, *this is very cold*, *this is very very
cold*, etc. The star has a higher priority than the other operators. You
have to use brackets in order to apply the star to a complex expression.
The expression:

::

    0,(0+1+2+3+4+5+6+7+8+9)*

recognizes a zero followed by a comma and by a possibly empty sequence
of digits.

WARNING: It is prohibited to search for the empty word with a regular
expression. If you try to search for ``(0+1+2+3+4+5+6+7+8+9)*``, the
program will raise an error as shown in figure [fig-epsilon-error].

.. figure:: resources/img/fig4-3.png
   :alt: Error message when searching for the empty
   string[fig-epsilon-error]
   :width: 14.00000cm

   Error message when searching for the empty string[fig-epsilon-error]

Morphological filters
---------------------

It is possible to apply morphological filters to the lexemes found. For
that, it is necessary to immediately follow the lexeme found by a filter
in double angle brackets:

| *lexical mask*\ ``<<``\ *morphological pattern*\ ``>>``
| The morphological filters are expressed as regular expressions in
  POSIX format (see :raw-latex:`\cite{TRE}` for the detailed syntax).
  Here are some examples of elementary filters:

-  ``<<ss>>``: contains ``ss``

-  ``<<^a>>``: begins with ``a``

-  ``<<ez$>>``: ends with ``ez``

-  ``<<a.s>>``: contains ``a`` followed by any character, followed by
   ``s``

-  ``<<a.*s>>``: contains ``a`` followed by a sequence of any character,
   followed by ``s``

-  ``<<ss|tt>>``: contains ``ss`` or ``tt``

-  ``<<[aeiouy]>>``: contains a non accentuated vowel

-  ``<<[aeiouy]{3,5}>>``: contains a sequence of non-accentuated vowels
   whose length is between 3 and 5

-  ``<<es?>>``: contains ``e`` followed by an optional ``s``

-  ``<<ss[^e]?>>``: contains ``ss`` followed by an optional character
   which is not ``e``

It is possible to combine these elementary filters to form more complex
filters:

-  ``<<[ai]ble$>>``: ends with ``able`` or ``ible``

-  ``<<^(anti|pro)-?>>``: begins with ``anti`` or ``pro``, followed by
   an optional dash

-  ``<<^([rst][aeiouy]){2,}$>>``: a word formed by 2 or more sequences
   beginning with ``r``, ``s`` or ``t`` followed by a non-accentuated
   vowel

-  ``<<^([^l]|l[^e])>>``: does not begin with ``l`` unless the second
   letter is an ``e``, in other words, any word except the ones starting
   with ``le``. Such constraints are better described using contexts
   (see section [section-contexts]).

By default, a morphological filter alone is regarded as applying it to
the lexical mask ``<TOKEN>``, that means any token except space and
``{STOP}``. On the other hand, when a filter follows a lexical mask
immediately, it applies to what was recognized by the lexical mask. Here
are some examples of such combinations:

-  ``<V:K><<i$>>``: Past participle ending with ``i``

-  ``<CDIC><<->>``: A compound word containing a dash

-  ``<CDIC><< .* >>``: a compound word containing at least two spaces

-  ``<A:fs><<^pro>>``: a feminine singular adjective beginning with
   ``pro``

-  ``<DET><<^([^u]|(u[^n])|(un.+))>>``: a (French) determiner different
   from ``un``

-  ``<!DIC><<es$>>``: a word which is not in the dictionary and which
   ends with ``es``

-  ``<V:S:T><<uiss>>``: a verb in the past or present subjunctive, and
   containing ``uiss``

NOTE: By default, morphological filters are subject to the same
variations of case as lexical masks. Thus, the filter ``<<^b>>`` will
recognize all the words starting with ``b``, but also those which start
with ``B``. To force the matcher to respect case, add ``_f_``
immediately after the filter, *e.g.*: ``<<^b>>_f_``.

Search
------

Search configuration
~~~~~~~~~~~~~~~~~~~~

In order to search for an expression, first open a text (cf.
chapter [chap-text]). Then click on “Locate Pattern...” in the “Text”
menu. The window of figure [fig-regexp-search-configuration] appears.

.. figure:: resources/img/fig4-4.png
   :alt: “Locate pattern” window[fig-regexp-search-configuration]
   :width: 8.80000cm

   “Locate pattern” window[fig-regexp-search-configuration]

The “Locate pattern in the form of” box allows you to select regular
expression or grammar. Click on “Regular expression”.

The “Index” box allows you to select the recognition mode:

-  “Shortest matches” : prefers shortest matches in case of nested
   sequences. For instance, if your grammar can recognize the sequences
   *a very hot chili* and *very hot*, the first one will be discarded;

-  “Longest matches” : prefers longest matches (*a very hot chili* in
   our example). This is the default;

-  “All matches” : outputs all recognized sequences.

The “Search limitation” box is used to limit the number of results to a
certain number of occurrences. By default, the search is limited to the
first 200 occurrences.

The options of the “Grammar outputs” box do not concern regular
expressions. They are described in
section [section-applying-graphs-to-text]. The same for options of tab
“Advanced options” (see section [section-advanced-search-options]).

In the “Search algorithm” frame, you can specify wether you want to
perform the locate operation on the text using the ``Locate`` program or
on the text automaton with ``LocateTfst``. By default, search is done
with the ``Locate`` program, as Unitex always did until now. If you want
to use ``LocateTfst``, please read dedicated section
[section-locate-tfst].

Enter an expression and click on “Search” in order to start the search.
Unitex will transform the expression into a grammar in the ``.grf``
format. This grammar will then be compiled into a grammar of the
``.fst2`` format that will be used for the search.

Presentation of the results
~~~~~~~~~~~~~~~~~~~~~~~~~~~

When the search is finished, the window of figure [fig-search-results]
appears showing the number of matched occurrences, the number of
recognized tokens and the ratio between this number and the total number
of tokens in the text.

.. figure:: resources/img/fig4-5.png
   :alt: Search results [fig-search-results]
   :width: 6.50000cm

   Search results [fig-search-results]

After clicking on “OK” you will see
window [fig-configuration-concordance] appear, which allows you to
configure the presentation of the matched occurrences. You can also open
this window by clicking on “Located Sequences...” in the “Text” menu.
The list of occurrences is called a *concordance*.

.. figure:: resources/img/fig4-6.png
   :alt: Result display configuration[fig-configuration-concordance]
   :width: 11.00000cm

   Result display configuration[fig-configuration-concordance]

The “Modify text” box offers the possibility to replace the matched
occurrences with the generated outputs. This possibility will be
examined in chapter [chap-advanced-grammars].

The “Extract units” box allows you to create a text file with all the
sentences that do or do not contain matched units. With the button “Set
File”, you can select the output file. Then click on “Extract matching
units” or “Extract unmatching units” depending on whether you are
interested in sentences with or without matching units.

In the “Show matching sequences in context” box, you can select the
length in characters of the left and right contexts of the occurrences
that will be presented in the concordance. If an occurrence has less
characters than its right context, the line will be completed with the
necessary number of characters. If an occurrence has a length greater
than that of the right context, it will be displayed completely.

NOTE: in Thai, the size of the contexts is measured in displayable
characters and not in real characters. This makes it possible to keep
the line alignment in the concordance despite the presence of diacritics
that combine with other letters instead of being displayed as normal
characters.

You can choose the sort order in the list “Sort According to”. The mode
“Text Order” displays the occurrences in the order of their appearance
in the text. The other six modes allow you to sort in columns. The three
zones of a line are the left context, the occurrence and the right
context. The occurrences and the right contexts are sorted from left to
right. The left contexts are sorted from right to left. The default mode
is “Center, Left Col.”. The concordance is generated in the form of an
HTML file.

If a concordance reaches several thousands of occurrences, it is
advisable to display it in a web browser (Firefox
:raw-latex:`\cite{Firefox}`, Netscape :raw-latex:`\cite{Netscape}`,
Internet Explorer, etc.) instead. Check “Use a web browser to view the
concordance” (cf. figure [fig-configuration-concordance]). This option
is activated by default if the number of occurrences is greater than
2000. You can configure which web browser to use by clicking on
“Preferences...” in the menu “Info”. Click on the tab “Language &
Presentation” and select the program to use in the field “Html Viewer”
(cf. figure [fig-browser-selection]).

If you choose to open the concordance in Unitex, you will see a window
as shown on Figure [fig-example-concordance]. Occurrences react as
hyperlinks. If you click on an occurrence, the text frame is opened and
the corresponding sequence is highlighted. Moreover, if the text
automaton is available and if this window is not iconified, the sentence
automaton that contains the occurrence will be shown.

.. figure:: resources/img/fig4-7.png
   :alt: Selection of a web browser for displaying
   concordances[fig-browser-selection]
   :width: 8.00000cm

   Selection of a web browser for displaying
   concordances[fig-browser-selection]

.. figure:: resources/img/fig4-8.png
   :alt: Example concordance[fig-example-concordance]
   :height: 18.00000cm

   Example concordance[fig-example-concordance]

Statistics
~~~~~~~~~~

If you select the “Statistics” tab in the “Located sequences..” frame,
you will see the panel shown on figure [fig-statistics]. This panel
allows you to get some statistics from the previously indexed sequences.

.. figure:: resources/img/fig4-9.png
   :alt: Statistics panel[fig-statistics]
   :width: 11.00000cm

   Statistics panel[fig-statistics]

In the “Mode” panel, you can select the kind of statistics you want:

-  collocates by z-score: the previous one, plus some additionnal
   information (number of occurrences of the collocate in the match
   context and in the whole corpus, z-score of the collocate)

-  collocates by frequency: shows the tokens that cooccur in the match
   context

-  contexts by frequency: shows matches with left and right contexts
   (see below). “count” is the number of occurrences of a given
   match+context

In the second panel, you can set the lenght of left and right contexts
to be used, in non space tokens. NOTE: this notion of context has
nothing to do with contexts in grammars.

In the last panel, you can allow or not case variations. If you allow
case variations, ``the`` and ``THE`` will be considered as a same token,
and the count will be the sum of the counts of ``the`` and ``THE``.

The following figures show the statistics computed in each mode for the
query ``<have>`` on ``ivanhoe.snt``.

.. figure:: resources/img/fig4-10.png
   :alt: left+match+right count[fig-statistics-mode0]
   :width: 11.00000cm

   left+match+right count[fig-statistics-mode0]

.. figure:: resources/img/fig4-11.png
   :alt: collocate count[fig-statistics-mode1]
   :width: 11.00000cm

   collocate count[fig-statistics-mode1]

.. figure:: resources/img/fig4-12.png
   :alt: collocate, count and other information[fig-statistics-mode2]
   :width: 12.00000cm

   collocate, count and other information[fig-statistics-mode2]

.. [1]
   From version 3.1beta, revision 4072, October 2, 2015.

.. [2]
   If a word is described in the dictionaries by an entry with ``A+z3``
   and another with only ``A``, the word is matched by ``<A+z3>``
   because of the former entry and by ``<A~z3>`` because of the latter.

.. [3]
   And with their legacy counterparts <MOT>,<MIN>, <MAJ>, <PRE>. See
   Section [section-special-symbols].

.. [4]
   And with their legacy counterparts <!MIN>, <!MAJ>, <!PRE>. See
   Section [section-special-symbols].
