Lexicon-grammar
===============

The tables of lexicon-grammar are a compact way for representing
syntactical properties of the elements of a language. It is possible to
automatically construct local grammars from such tables, due to a
mechanism of parameterized graphs.

In the first part of the chapter the formalism of tables is presented.
The second part describes parameterized graphs and a mechanism of
automatically lexicalizing them with lexicon-grammar tables.

Lexicon-grammar tables
----------------------

Lexicon-grammar is a methodology developed by Maurice Gross and the LADL
team (:raw-latex:`\cite{L}`, :raw-latex:`\cite{BGL}`,
:raw-latex:`\cite{methodes-en-syntaxe}`, :raw-latex:`\cite{GL}`,
:raw-latex:`\cite{gross1994}`, :raw-latex:`\cite{gross1994b}`,
:raw-latex:`\cite{gross1991}`, :raw-latex:`\cite{gross1986}`,
:raw-latex:`\cite{gross1984}`, :raw-latex:`\cite{gross1984b}`,
:raw-latex:`\cite{gross1983}`, :raw-latex:`\cite{gross1982}`,
:raw-latex:`\cite{gross1978}`, :raw-latex:`\cite{leclere2005}`,
:raw-latex:`\cite{salkoff2004}`) based on the following principle: every
verb has an almost unique set of syntactical properties. Due to this
fact, these properties need to be systematically described, since it is
impossible to predict the exact behavior of a verb. These descriptions
are represented by matrices where rows correspond to verbs and columns
to syntactical properties. The considered properties are formal
properties such as the number and nature of allowed complements of the
verb and the different transformations the verb can undergo
(passivization, nominalisation, extraposition, etc.). The matrices, or
tables, are mostly binary: a ``+`` sign occurs at the intersection of a
row and a column of a property if the verb has that property, a ``-``
sign if not. More information in http://infolingu.univ-mlv.fr, including
some lexicon-grammar tables that you can freely download.

This type of description has also been applied to adjectives
(:raw-latex:`\cite{these-annie}`), predicative nouns
(:raw-latex:`\cite{les-nominalisations}`,
:raw-latex:`\cite{les-predicats-nominaux}`,
:raw-latex:`\cite{giry1978}`, :raw-latex:`\cite{gross1976}`,
:raw-latex:`\cite{ranchhod2001}`), adverbs
(:raw-latex:`\cite{syntaxe-de-ladverbe}`,
:raw-latex:`\cite{grammaire-des-adverbes}`), as well as frozen
expressions, in many languages
(:raw-latex:`\cite{lexique-grammaire-allemand2}`,
:raw-latex:`\cite{lexique-grammaire-italien2}`,
:raw-latex:`\cite{lexique-grammaire-italien}`,
:raw-latex:`\cite{lexique-grammaire-coreen2}`,
:raw-latex:`\cite{lexique-grammaire-coreen}`,
:raw-latex:`\cite{lexique-grammaire-malgache}`,
:raw-latex:`\cite{lexique-grammaire-espagnol}`,
:raw-latex:`\cite{lexique-grammaire-allemand}`,
:raw-latex:`\cite{lexique-grammaire-hongrois}`,
:raw-latex:`\cite{ranchhod1996}`, :raw-latex:`\cite{ranchhod1991}`,
:raw-latex:`\cite{gross1986b}`).

Figure [fig-table-32NM] shows an example of a lexicon-grammar table. The
table contains verbs that, among other definitional properties, do not
admit passivization.

.. figure:: resources/img/fig8-1.png
   :alt: Lexicon-grammar Table 32NM[fig-table-32NM]
   :width: 15.00000cm

   Lexicon-grammar Table 32NM[fig-table-32NM]

Conversion of a table into graphs
---------------------------------

Principle of parameterized graphs
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The conversion of a table into graphs is carried out by a mechanism
involving parameterized graphs. The principle is the following: a graph
that describes the possible constructions is constructed manually. That
graphs refers to the columns of the table in the form of parameters or
variables. Afterwards, for each line of the table a copy of this graph
is constructed where the variables are replaced with the contents of the
cell at the intersection of line and the column that corresponds to the
variable. If a cell of the table contains the ``+`` sign, the
corresponding variable is replaced by ``<E>``. If the cell contains the
``-`` sign, the box containing the corresponding variable is removed,
interrupting the paths through that box. In all other cases the variable
is replaced by the contents of the cell.

Format of the table
~~~~~~~~~~~~~~~~~~~

The lexicon-grammar tables are usually encoded with the aid of a
spreadsheet like OpenOffice.org Calc (:raw-latex:`\cite{OpenOffice}`).
To be usable with Unitex, the tables have to be encoded in Unicode text
format in accordance with the following convention: the columns need to
be separated by a tab and the lines by a newline.

In order to convert a table with OpenOffice.org Calc, save it in text
format (``.csv`` extension). You can then parameterize the output format
with a window as shown on Figure [fig-csv-export]. Choose “Unicode”,
select tabulation as column separator and do not set any text delimiter.

.. figure:: resources/img/fig8-2.png
   :alt: Saving a table with OpenOffice.org Calc[fig-csv-export]
   :width: 12.00000cm

   Saving a table with OpenOffice.org Calc[fig-csv-export]

During the generation of the graphs, Unitex skips the first line,
considering that it contains the headings of the columns. It is
therefore necessary to ensure that the headings of the columns occupy
exactly one line. If there is no line for the heading, the first line of
a table will be ignored anyway, and if there are multiple heading lines,
from the second line on they will be interpreted as lines of the table.

Parameterized graphs
~~~~~~~~~~~~~~~~~~~~

Parameterized graphs are graphs with variables referring to the columns
of a lexicon-grammar table. This mechanism is usually used with
syntactic graphs, but nothing prevents the construction of parameterized
graphs for inflection, preprocessing, or for normalization.

Variables that refer to columns are formed with the ``@`` symbol
followed by the name of the column in capital letters (the columns are
named starting with ``A``).

Example: ``@C`` refers to the third column of the table.

Whenever a variable takes the value of a ``+`` or ``-`` sign, the ``-``
sign corresponds to the removal of a path through that variable. It is
possible to swap the meaning of these signs by typing an exclamation
mark in front of the ``@`` symbol. In that case, the path is removed
when there is a ``+`` sign and kept where there is a ``-`` one. In all
other cases, the variable is replaced by the content of the table cell.

The special variable ``@%`` is replaced by the number of the line in the
table. The fact that its value is different for each line allows for its
use as a simple characterization of a line. That variable is not
affected by an exclamation point to the left of it.

Figure [fig-reference-graph] shows an example of a parameterized graph
designed to be applied to the lexicon-grammar table 31H presented in
figure [fig-table-31H].

.. figure:: resources/img/fig8-3.png
   :alt: Example of parameterized graph[fig-reference-graph]
   :width: 15.00000cm

   Example of parameterized graph[fig-reference-graph]

.. figure:: resources/img/fig8-4.png
   :alt: Lexicon-grammar table 31H[fig-table-31H]
   :width: 15.00000cm

   Lexicon-grammar table 31H[fig-table-31H]

Automatic generation of graphs
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In order to be able to generate graphs from a parameterized graph and a
table, first of all the table must be opened by clicking on “Open...” in
the “Lexicon-Grammar” menu (see figure [fig-lexicon-grammar-menu]). The
table must be in Unicode text format.

.. figure:: resources/img/fig8-5.png
   :alt: Menu “Lexicon-Grammar”[fig-lexicon-grammar-menu]
   :width: 12.00000cm

   Menu “Lexicon-Grammar”[fig-lexicon-grammar-menu]

The selected table is then displayed in a window (see figure figure
[fig-table-display]). If it does not appear on your screen, it may be
hidden by other Unitex windows.

.. figure:: resources/img/fig8-6.png
   :alt: Displaying a table[fig-table-display]
   :width: 15.00000cm

   Displaying a table[fig-table-display]

To automatically generate graphs from a parameterized graph, click on
“Compile to GRF...” in the “Lexicon-Grammar” menu. The window in figure
[fig-configuration-graph-generation] shows this.

.. figure:: resources/img/fig8-7.png
   :alt: Configuration of the automatic generation of
   graphs[fig-configuration-graph-generation]
   :width: 9.00000cm

   Configuration of the automatic generation of
   graphs[fig-configuration-graph-generation]

In the “Reference Graph (in GRF format)” frame, indicate the name of the
parameterized graph to be used. In the “Resulting GRF grammar” frame,
indicate the name of the main graph that will be generated. This main
graph is a graph that invokes all the graphs that are going to be
generated. When launching a search in a text with that graph, all the
generated graphs are simultaneously applied.

The “Name of produced subgraphs” frame is used to set the name of each
graph that will be generated. Enter a name containing ``@%``, because
for each line of the table, ``@%`` will be replaced the line number,
which guarantees that each graph name will be unique. For example, if
the main graph is called “``TestGraph.grf``” and if subgraphs are called
“``TestGraph_@%.grf``”, the graph generated from the 16th line of the
line will be named “``TestGraph_0016.grf``”.

Figures [fig-archaiser] and [fig-badauder] show two graphs generated by
applying the parameterized graph of figure [fig-reference-graph] at
table 31H.

Figure [fig-main-graph] shows the resulting main graph.

.. figure:: resources/img/fig8-8.png
   :alt: Graph generated for the verb ``archaïser``\ [fig-archaiser]
   :width: 15.00000cm

   Graph generated for the verb ``archaïser``\ [fig-archaiser]

.. figure:: resources/img/fig8-9.png
   :alt: Graph generated for the verb ``badauder``\ [fig-badauder]
   :width: 15.00000cm

   Graph generated for the verb ``badauder``\ [fig-badauder]

.. figure:: resources/img/fig8-10.png
   :alt: Main graph referring to all the generated
   graphs[fig-main-graph]
   :width: 10.00000cm

   Main graph referring to all the generated graphs[fig-main-graph]
