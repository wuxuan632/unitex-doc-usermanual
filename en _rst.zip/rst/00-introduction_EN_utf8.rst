Introduction ============

Unitex is a collection of programs developed for the analysis of texts
in natural language by using linguistic resources and tools. These
resources consist of electronic dictionaries, grammars and
lexicon-grammar tables, initially developed for French by Maurice Gross
and his students at the Laboratoire d’Automatique Documentaire et
Linguistique (LADL). Similar resources have been developed for other
languages in the context of the RELEX laboratory network.

The electronic dictionaries specify the simple and compound words of a
language together with their lemmas and a set of grammatical (semantic
and inflectional) codes. The availability of these dictionaries is a
major advantage compared to the usual utilities for pattern searching as
the information they contain can be used for searching and matching,
thus describing large classes of words using very simple patterns. The
dictionaries are presented in the DELA formalism and were constructed by
teams of linguists for several languages (French, English, Greek,
Italian, Spanish, German, Thai, Korean, Polish, Norwegian, Portuguese,
etc.)

The grammars used here are representations of linguistic phenomena on
the basis of recursive transition networks (RTN), a formalism closely
related to finite state automata. Numerous studies have shown the
adequacy of automata for linguistic problems at all descriptive levels
from morphology and syntax to phonetic issues. Grammars created with
Unitex carry this approach further by using a formalism even more
powerful than automata. These grammars are represented as graphs that
the user can easily create and update.

Lexicon-grammar tables are matrices describing properties of some words.
Many such tables have been constructed for all simple verbs in French as
a way of describing their relevant syntactic properties. Experience has
shown that every word has a quasi-unique behavior, and these tables are
a way to present the grammar of every element in the lexicon, hence the
name lexicon-grammar for this linguistic theory. Unitex offers a way to
automatically build grammars from lexicon-grammar tables.

Unitex can be viewed as a tool in which one can put linguistic resources
and use them. Its technical characteristics are its portability,
modularity, the possibility of dealing with languages that use special
writing systems (e.g. many Asian languages), and its openness, thanks to
its open source distribution. Its linguistic characteristics are the
ones that have motivated the elaboration of these resources: precision,
completeness, and the taking into account of frozen expressions, most
notably those which concern the enumeration of compound words.

What’s new from version 3.0 ? —————————–

Here are the main new features:

- Faster engine that uses less stack.

- Enhanced version of “CasSys“: new “csc“ files, suppression of the
“Share“ directory, open cascade also by the “FSGraph“ menu, apply graph
until fixed point, generic graphs, last file may be denormalized
(Chapter [chap-cassys]).

- Introduction of Malagasy.

- Publication of “main\_UnitexTool\_C“ as public API.

- Enhanced version of the graph editor: box selection, box editing,
open, save, export as image ([section-editing-graphs],
[exporting-graphs]).

- Non-applicable menu items are now grayed out.

- Introduction of the “<n.LEMMA>“ operator for inflection in Semitic
mode (yet undocumented).

- Introduction of list of recently opened graphs and corpora.

- Introduction of list of open windows.

- Enhanced compatibility with Ruby.

- Introduction of “InstallLingResourcePackage“, a tool that installs a
package of resources and scripts into a target environment (yet
undocumented).

- Introduction of “RunScript“, a tool that runs in the target
environment scripts installed there by “InstallLingResourcePackage“ (yet
undocumented). With these two tools, users can implement Unitex
operations in an environment and deploy them in another.

- Introduction of the “match word boundaries” option in the
automaton-intersection search algorithm ([section-locate-tfst]), so that
e.g. \*nowhere\* and \*now here\* don’t match (or match, if user wants).
Yet undocumented.

- Enhanced tracking of the offset between the addresses of a given
position in a corpus in different versions of the corpus
([section-DumpOffsets]).

- Daily compilation of binaries for Windows (32-bit, 64-bit), GNU/Linux
(Intel, Intel 64-bit) and 0S X (10.7+).

- Setup installers are provided for all target platforms.

IMPORTANT: as some file formats changed and some new files were
introduced, we recommend that you repreprocess your existing text files,
especially if you work with text automata.

Content ——-

Chapter [chap-install] describes how to install and run Unitex.

Chapter [chap-text] presents the different steps in the analysis of a
text.

Chapter [chap-dictionaries] describes the formalism of the DELA
electronic dictionaries and the different operations that can be applied
to them.

Chapters [chap-regexp] and [chap-grammars] present different means for
making text searches more effective. Chapter [chap-grammars] describes
in detail how to use the graph editor.

Chapter [chap-advanced-grammars] is concerned with the different
possible applications of grammars. The particularities of each type of
grammar are presented.

Chapter [chap-text-automaton] introduces the concept of text automaton
and describes the properties of this notion. This chapter also describes
operations on this object, in particular, how to disambiguate lexical
items with the ELAG program.

Chapter [chap-sequence-automaton] describes the sequence automaton
module, the file formats that are accepted as input, the user interface
and introduces the search by approximation.

Chapter [chap-lexicon-grammar] contains an introduction to
lexicon-grammar tables, followed by a description of the method of
constructing grammars based on these tables.

Chapter [chap-alignment] describes the text alignment module, based on
the XAlign tool.

Chapter [chap-multiflex] describes the compound word inflection module,
as a complement of the simple word inflection mechanism presented in
chapter [chap-dictionaries].

Chapter [chap-cassys] describes the CasSys cascade of transducer system.

Chapter [chap-external-programs] contains a detailed description of the
external programs that make up the Unitex system.

Chapter [chap-file-formats] contains descriptions of all file formats
used in the system.

The reader will find in appendix the LGPL license under which the Unitex
source code is released, as well as the LGPLLR license which applies for
the linguistic data distributed with Unitex. There is also the 2-clause
BSD licence that applies to the TRE library, used by Unitex for
morphological filters.

Unitex contributors ——————-

Unitex was born as a bet on the power of Open Source philosophy in the
academic world (see http://igm.univ-mlv.fr/ unitex/why\_unitex.html),
relying on the assumption that people would be interested in sharing
their knowledge and skill into such an open project. The following list
sounds like Open Source is good for science:

- Olivier Blanc: has integrated the ELAG system into Unitex, originally
designed by Eric Laporte, Anne Monceaux and some of their students, has
also written “RebuildTfst“ (previously known as “MergeTextAutomaton“)

- Matthieu Constant: author of “Grf2Fst2“

- Julien Decreton: author of the text editor integrated in Unitex, has
also designed the undo functionality in the graph editor

- Claude Devis: introduction of morphological filters, based on the TRE
library

- Nathalie Friburger: author of “CasSys“

- Hyun-Gue Huh: author of the tools used to generate Korean dictionaries

- Claude Martineau: had worked on the simple word inflection part of
“MultiFlex“

- Sebastian Nagel: has optimized many parts of the code, has also
adapted “PolyLex“ for German and Russian

- Alexis Neme: has optimized “Dico“ and “Tokenize“, has also merged
“Locate“ into “Dico“ in order to allow dictionary graphs

- Aljosa Obuljen: author of “Stats“

- Sébastien Paumier: main developer

- Agata Savary: author of “MultiFlex“

- Anthony Sigogne: author of “Tagger“ and “TrainingTagger“

- Gilles Vollant: author of “UnitexTool“, has optimized many aspects of
Unitex code (memory, speed, multi-compiler compliance, etc)

- Patrick Watrin: author of “XMLizer“, has worked on the integration of
“XAlign“

Moreover, Unitex would be useless without all the precious linguistic
resources it contains. All those resources are the result of hard work
done by people that shall not be forgotten. Some are mentionned in
disclaimers that come with dictionaries, and complete information is
available on:

http://igm.univ-mlv.fr/ unitex/linguistic\_data\_bib.html

If you use Unitex in research projects... —————————————–

Unitex has been used in several research projects. Some are listed in
the “Related works” section of Unitex home page. If you did some work
with Unitex (resources, project, paper, thesis, ...) and if you want it
to be referenced in the web site, just send a mail to
‘unitex-devel@univ-mlv.fr <unitex-devel@univ-mlv.fr>‘\_\_. The more
visible, the more cited!
