Cascade of Transducers
======================

This chapter presents the tool *CasSys* that provides users the
possibility to create Unitex cascade of transducers and new
opportunities to work on natural language whith Finite State Graphs. A
*cascade of transducers* applies several FSGraphs (also called automata
or transducers), one after the other, onto a text: each graph modifies
the text, and changes can be useful for further processings with the
next graphs. Such a system is typically used for syntactic analysis,
chunking, information extraction, recognizing named entities etc. To do
that, CasSys uses a succession of “locate patterns” to which was added
special options and behaviors.

The first prototype of the *CasSys* system was created in 2002 at the LI
(Computer science Laboratory of Université François Rabelais Tours,
France) :raw-latex:`\cite{these-nathalie}`. This prototype was totally
dedicated to named entity recognition. Later, CasSys was generalized to
allow any sort of work needing a cascade: throughout the years, it was
improved but never really integrated in Unitex, until a recent project
which resulted in the complete integration of CasSys in Unitex [1]_.

Unitex grammars are known as Context free grammars and contain the
notion of transduction derived from the field of finite state automata.
A grammar with transduction (a transducer) is enabled to produce some
ouput. CasSys is dedicated to the application of transducers in the form
of a cascade.

A cascade can be used for syntactic analysis, chunking, information
extraction, etc. Transducers are interesting because they allow the
association of a recognized sequence to informations found in the
outputs of the graphs. These outputs can:

-  Be merged with the recognized sequence and appear in the resulting
   concordance or modified text.

-  Replace the recognized sequence to modify the text.

These two operations transform the text or add information inside the
text.

In this chapter, we will explain how to create/modify cascades of
transducers and how to apply them. Then, we deals with options and
behaviors offered by CasSys.

Applying a cascade of transducers with CasSys
---------------------------------------------

Applying a cascade of transducers consists in the modelling of
linguistic phenomena in several transducers listed in a specific order
to apply on a text: CasSys and its interface into Unitex permits to do
this. This section explains how to use the interface to create, manage
(order, add, delete) graphs and apply the cascade.

Creating the list of transducers
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In order to manage the list of transducers, the menu FSGraph proposes
two submenus: “*New cascade*” and “*Edit cascade...*” (Figure
[fig13-08]). You can choose “*new cascade*” to create a new list of
transducers. If you want to modify an existing cascade, you can choose
“*Edit cascade*” that open a file explorer to choose the cascade to
open.

.. figure:: resources/img/fig13-08.png
   :alt: “FSGraph” menu of Unitex and submenus “*New cascade*” and
   “*Edit cascade...*”
   :width: 4.00000cm

   “FSGraph” menu of Unitex and submenus “*New cascade*” and “*Edit
   cascade...*”

In the language directory, there is a directory named CasSys where the
cascade configuration files are stored. Those files are text files with
the extension *.csc* (ex: mycascade.csc).

Editing the list of transducers
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The CasSys configuration window (Figure [fig13-03]) is divided into
three parts :

.. figure:: resources/img/fig13-03.png
   :alt: CasSys configuration window with a list of transducers on the
   right hand side
   :width: 16.00000cm

   CasSys configuration window with a list of transducers on the right
   hand side

#. a *file explorer* at the left of the frame permits to select the
   transducers to place in the cascade. The file explorer only displays
   fst2 files (all the graphs you want to place in the list of
   transducers must be compiled in fst2 format).

   To edit the cascade, select the graphs in the file explorer at the
   left and drag and drop them into the right frame of the window.

#. A *table* at the right displays the cascade: the ordered list of
   transducers and the selected options for each graph. This table is
   obviously empty for a new cascade.

   The different columns of this table (Figure [fig13-09]) show the
   numbering of each graph and permit to choose its behavior:

   -  **#**: Rank of the graph/transducer in the cascade. The resulting
      file of a graph is numbered with this rank.

   -  **Disabled**: checkbox to disable the current graph. *Disabled*
      meaning “*not applied in the cascade*”. The disabled graphs appear
      not numbered, in light grey and striked out.

   -  **Name**: The name of the graph (with extension *fst2*). If you
      let the mouse over the name of the graph, a tooltip appears with
      the whole path ot the graph. Graphs which source file are not
      found appear in italic red font style.

   -  **Merge**: Whether the transducer should be applied in merge mode
      at the sense of unitex locate pattern.

   -  **Replace**: Whether the transducer should be applied in replace
      mode at the sense of unitex locate pattern.

   -  **Until fix point**: Whether the transducer should be applied once
      or re-applied several times until no change occur in the text i.e.
      until a fix point is reached (See [sub:AppWhiCon]).

#. *Several buttons* in the middle for different needs:

   -  *“Up/Down/Top/Bottom”* buttons are used to modify the order of the
      transducers on the list (it moves the selected transducer in the
      list); *“Up”* and *“Down”* to move the selected transducer one
      line up or down, and “*Top*” and “*Bottom*” to move the selection
      to the top or to the end of the list.

   -  *“Delete”* permits to remove a selected transducer from the list
      of transducers.

   -  *“Add”* adds a transducer (previously selected in the explorer)
      onto the list. It replaces the drag and drop actions described
      above.

   -  *“View”* opens the selected graph either in the file explorer or
      in the list of transducers of the window. It is very useful to get
      a quick access to any transducer either to take a quick look at
      its content or to modify it.

   -  *“Save”* and *“Save as”* permit to save the list of transducers.
      By default, the lists of transducers are stored in the CasSys
      directory of the current language (e.g. English/CasSys).

   -  *“Compile”* recompile all the graphs of the cascade. Very useful
      to avoid to recompile a graph after changes.

   -  *“Disable all”* to disable all the graphs of the cascade.

   -  *“Enable all”* to enable all the graphs of the cascade.

   -  *“Close”* to close the current window.

.. figure:: resources/img/fig13-09.png
   :alt: The table/list of transducers
   :width: 7.00000cm

   The table/list of transducers

Applying a cascade
~~~~~~~~~~~~~~~~~~

To apply a cascade on a text, you can select the menu “*Text / Apply
CasSys cascade...*” (Figure [fig13-01]) which will open the CasSys
window. This submenu “*Apply CasSys cascade...*” is active only if a
text has previously been opened.

.. figure:: resources/img/fig13-01.png
   :alt: “*Text*” menu of Unitex and submenu “*Apply CasSys Cascade...*”
   :width: 5.00000cm

   “*Text*” menu of Unitex and submenu “*Apply CasSys Cascade...*”

The CasSys window (Figure [fig13-02]) displays the content of the CasSys
directory of the current language. It allows you to choose the cascade
file to be applied on the text. When this list is chosen, you can click
on the “Launch” button to apply the cascade.

.. figure:: resources/img/fig13-02.png
   :alt: CasSys Window to launch a cascade of transducers
   :width: 10.00000cm

   CasSys Window to launch a cascade of transducers

All morphological-mode dictionaries added in your preferences are
applied to your graphs. Preferences may be edited from the main Unitex
frame (*info / Preferences / morphological-mode dictionaries*).

Sharing a cascade transducer list file
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In order to ease collaborating work within CasSys, a simple
export/import system for the cascades is provided. This possibility is
offered in the “*Text / Apply CasSys cascade...*” menu (Figure
[fig13-02]).

To share a cascade list file, the following steps has to be fullfilled :

#. **Export :** Select a cascade file and click the export button. (A
   ready to share file is created in the ``/CasSys/Share`` repository)

#. Send the file to share to your colleague

#. **Import :** Select the imported file and click the import button. (A
   ready to use file is created in the ``/CasSys`` repository)

Details on the behavior of CasSys
---------------------------------

In this section , we present details concerning the functioning of
CasSys.

Type of graphs used
~~~~~~~~~~~~~~~~~~~

CasSys uses the compiled version of the graphs (the ``fst2`` files).
CasSys can handle the local grammars (section [syntactic-graphs])
presented in Chapter [chap-advanced-grammars]. The grammars used in the
cascade must follow the constraints of the grammars used in Unitex. They
may use subgraphs, morphological filters, the morphological mode, and
references to information in dictionaries.

CasSys does not support debug-mode ``fst2`` files
([section-debug-mode]). When you apply a graph in debug mode through the
``Text > Locate Pattern`` menu, the system compiles the graph into a
special debug-mode format. To obtain a regular ``fst2`` file, compile
the graph again, either with the ``FSGraph`` menu, or with a command
line, or by unchecking the debug mode before applying the graph with
``Text > Locate Pattern`` menu.

*Repeat until fix point* behaviour
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

CasSys may apply a transducer on a text while concordances are found.
This behavior is selected if the checkbox **Until fix point** is checked
or not for each graph of a cascade. This section presents the behaviour
of this option. For instance, consider the very simple graph [fig:AB->A]
which recognizes *AB* and replaces it with *A*.

.. figure:: resources/img/AB_to_A.png
   :alt: Transducer which modifies BA in A
   :width: 7.00000cm

   Transducer which modifies BA in A

| Consider the text *B B B A A A*. Applying the graph [fig:AB->A] onto
  this text with the option *Until fix point* will have the following
  result :

+----------------+-----+-----+-----+-----+-----+-----+-----------+
| initial text   | B   | B   | B   | A   | A   | A   |           |
+================+=====+=====+=====+=====+=====+=====+===========+
| iteration 1    |     | B   | B   | A   | A   | A   | 1 match   |
+----------------+-----+-----+-----+-----+-----+-----+-----------+
| iteration 2    |     |     | B   | A   | A   | A   | 1 match   |
+----------------+-----+-----+-----+-----+-----+-----+-----------+
| iteration 3    |     |     |     | A   | A   | A   | 1 match   |
+----------------+-----+-----+-----+-----+-----+-----+-----------+
| iteration 4    |     |     |     | A   | A   | A   | 0 match   |
+----------------+-----+-----+-----+-----+-----+-----+-----------+

| 
| During the three first iterations, a match is found, so the graph
  re-applied on the resulting text. At the fourth iteration, no match is
  found, the graph is not re-applied.

Be aware of the risk of livelock when applying this option. For example,
a transducer which recognizes *A* and replaces it with *A* would be
caught in a livelock if applied on the example text.

The Unitex rules used for the cascade
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In the cascade, each successive graph is applied following the unitex
rules:

-  *Insertion to the left of the matched patterns*: in the merge mode,
   the ouput is inserted to the left of the recognized sequence.

-  *Priority of the leftmost match*: during the application of a local
   grammar, overlapping occurrences are all indexed. During the
   construction of a concordance, all these overlapping occurrences are
   presented but CasSys modifies the text with each graph of the cascade
   : so it is necessary to choose among these occurrences the one that
   will be taken into account. To do that, the priority is given to the
   leftmost sequence.

-  *Priority of the longest match*: in CasSys, during the application of
   a graph, it is the longest sequence that will be kept.

-  *Search limitation to a certain number of occurrences*: in CasSys,
   this search is not limited. Such a limitation has no sense in the use
   of CasSys, we always index all occurrences in the text.

A special way to mark up patterns with CasSys
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

| The output of the transducers can be used to insert special
  information into texts, particularly to mark up the recognized
  patterns: it is possible to use all the marks you want such as ( ),
  [], “”, etc. or xml tags such as <xxx> </xxx>.
| CasSys also offers *a special way to mark up patterns*, that offers
  some advantages and that we present here.

Unitex splits texts into different sorts of tokens like the sentence
delimiter S; the stop marker STOP, contiguous sequences of letters,
lexical tags aujourd’hui,.ADV, etc. The lexical tag is used by CasSys in
a special way. The lexical tag (between curly brackets) is normally used
to avoid ambiguities (see section [tokenization] and
section[section-displaying-sentence-automata]). For example, if the
token *{curly brackets,.N}* is in a text, neither “curly” nor “brackets”
will be recognized but the whole sequence “curly brackets” or the tag
<N>. A lexical tag can contain complex lexical information. For example,
the codes *N+Pers+Hum:fs* tags a token which is a noun, a person, a
human and feminine singular. In a graph, you can look for a lexical
token using the lexical codes it contains: for example, you can write
lexical masks such as *<N>* to search a noun, *<Pers+Hum>* for a human
person or simply *<Pers>* (lexical masks are explained in section
[section-special-symbols]).

In CasSys, we use the lexical tag in a special way. A cascade of
transducers is interesting to locate the island of certainty first. It
is necessary for such a system to avoid that previously recognized
patterns be ambiguous with patterns recognized by the following graphs.
To do that, you can tag the patterns of your graphs surrounding them by
*{* and *,.tag1+tag2+tagn}* in the outputs of the graph (where *tag1,
tag2, etc.* are your own tags).

To explain this behavior, here is a very simple example. The text on
which we work is :

*bac a b c cc a b b ba ab a b bca a b c abaabc*.

The graph grfAB ([fig13-05]) recognizes the sequence *a b* in the text
and tags this sequence with the lexical tag *{a b,.AB}*. The results are
merged with the text adding the outputs *{* and *,.AB}* around *“a b”*
sequences.

.. figure:: resources/img/fig13-05.png
   :alt: The graph grfAB
   :width: 6.00000cm

   The graph grfAB

The resulting text is : *bac {a b,.AB} c cc {a b,.AB} b ba ab {a b,.AB}
bca {a b,.AB} c abaabc*.

Now the pattern *a b* is tagged *AB*. A part (a or b alone) of this
pattern cannot be recognized because of the tagging of *a b*.

After that graph, the cascade applies another graph named tagAB
([fig13-06]). iI has two paths:

-  the first one to recognize the lexical mask *<AB>* followed by *c*
   and tags this sequence as *ABC*.

-  the second one to recognize and tag *bca* preceeded by *<AB>*. Only
   *bca* is tagged as *BCA*.

.. figure:: resources/img/fig13-06.png
   :alt: The graph tagAB
   :width: 9.00000cm

   The graph tagAB

The resulting text is : *bac {{a b,.AB} c,.ABC} cc {a b,.AB} b ba ab {a
b,.AB} {bca,.BCA} {{a b,.AB} c,.ABC} abaabc*.

The concordance displayed by Unitex should be like in ([fig13-07]). //

Note that for programming reasons (ambiguities between characters in the
curly brackets of the lexical tags), we have no option but to place
backslashes :math:`\backslash` before all ambiguous characters for
Unitex ; that is why these symbols are protected with :math:`\backslash`
in the concordance to avoid problems in Unitex.

.. figure:: resources/img/fig13-07.png
   :alt: The concordance resulting from this cascade
   :width: 15.00000cm

   The concordance resulting from this cascade

Generic Graphs
--------------

Sometimes, we are able to locate elements because of their context, but
if these elements appear without context, then they cannot be
identified. In order to locate such occurences, CasSys proposes to
utilise generic graphs. These graphs contain empty boxes that are filled
automatically by the program before being applied to the text. These
generic graphs work only with the usage of curly brackets, because the
program consults the token list of the text to be analysed by the future
graph.

Identifying a Generic Graph
~~~~~~~~~~~~~~~~~~~~~~~~~~~

CasSys recognises a graph as generic graph if the column *Generic* is
checked (figure [fig12-3]).

.. figure:: resources/img/fig12-3.png
   :alt: Generic Graph
   :width: 15.00000cm

   Generic Graph

Structure of a Generic Graph
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

A path in a generic graph must begin with a box containing $G and an
opening curly bracket as output. It is this box which is updated by
CasSys. The second box has as output the element to be searched. In the
figure [fig12-3-01], CasSys places in the box all the entries of
category *x* extracted from the token list (tok\_by\_alph.txt) of the
text. For example, CasSys extracts *A* from the line *{A,.x}* of the
token list of the text as shown in the figure [fig12-3-01a].
Additionally, a negative right context (section [section-contexts] is
added to prevent the element from being annotated twice.

.. figure:: resources/img/fig12-3-01.png
   :alt: Generic Graph
   :width: 5.00000cm

   Generic Graph

.. figure:: resources/img/fig12-3-01a.png
   :alt: Modified Generic Graph
   :width: 9.00000cm

   Modified Generic Graph

In the case of a token list entry *{{A,.y} {B,.z},.x}* the graph of the
figure [fig12-3-01] places in the box *A B* as displayed in the figure
[fig12-3-02].

.. figure:: resources/img/fig12-3-02.png
   :alt: Modified Generic Graph
   :width: 8.00000cm

   Modified Generic Graph

Some restrictions are possible by putting in the second box a category,
such as *y* in the figure [fig12-3-03]; as a result only *A* is placed
in the box as in the figure [fig12-3-04].

.. figure:: resources/img/fig12-3-03.png
   :alt: Generic Graph with a restriction
   :width: 5.00000cm

   Generic Graph with a restriction

.. figure:: resources/img/fig12-3-04.png
   :alt: Modified Generic Graph
   :width: 8.00000cm

   Modified Generic Graph

On the other hand, the negation of a category, for example *~y* in the
figure [fig12-3-05] will put *B* in this box (figure [fig12-3-06]).

.. figure:: resources/img/fig12-3-05.png
   :alt: Generic Graph with a negation
   :width: 5.00000cm

   Generic Graph with a negation

.. figure:: resources/img/fig12-3-06.png
   :alt: Modified Generic Graph
   :width: 7.00000cm

   Modified Generic Graph

If the output of the graph needs to be complemented with certain
information that need not be searched, a third box can be added as in
the figure [fig12-3-07].

.. figure:: resources/img/fig12-3-07.png
   :alt: Generic Graph with Additional Information
   :width: 6.00000cm

   Generic Graph with Additional Information

The results of a cascade
------------------------

Displaying the concordance of a cascade
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The results of a cascade are stored in an index file (*concord.ind*),
just as for the *“Locate pattern”* operation. This index file contains
all the sequences recognized using the restrictions imposed by the rules
of unitex.

In order to display a concordance, you have to access the frame “*Text /
Located sequences...*” and click on the “*Build concordance*” button (as
described in Chapter [chap-advanced-grammars]). The figure [fig13-04]
presents a sample of concordance resulting of a cascade recognizing
named entities.

.. figure:: resources/img/fig13-04.png
   :alt: Concordance of CasSys under Unitex
   :width: 14.00000cm

   Concordance of CasSys under Unitex

The different resulting files of a cascade
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

CasSys keeps all the text created by each graph of the cascade. This can
be useful to test, debug or check the different results of the cascade.
It is possible to correct the errors on the order of the graphs or to
find the errors in the writing of the graphs. A good idea is to write
the name of the graph recognizing a pattern in the output of this graph:
thanks to that, you can see in the final results the name of the graph
by which a pattern is recognized.

If you apply a cascade on the text named ``example.txt``, two
directories are created: ``example_snt`` and ``example_csc``. The files
produced in ``example_csc`` are the results obtained by each graphs.
These files are named according to the number of the graph which
produced them. For example, if the third graph of a cascade finds at
least a pattern, the results of this graph will be stored in the
directory ``example_3_0_snt`` and the file named ``example_3_0.snt``
will contain the modified text.

An xml-like output text for lexical tags
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

| The output is provided in two forms: the direct output of the
  transducers, and an XML-like output with the lexical tags transformed
  into XML. This change is done in order to provide the end user with
  more easily manageable text. From this format, it is possible to use
  one of the numerous tools to process xml and it is easier to apply
  further transducers to get the desired output.
| The direct output of the transducers is in the ``example_csc.raw``
  file. The xml-ized ouput text is copied in the ``example_csc.txt``
  file.

| More precisely, lexical tags have the following format :

+----------------------------------------------+
| `` {forme.lemme,code1+code2:flex1:flex2}``   |
+----------------------------------------------+

| 
| The corresponding xml-like output of CasSys has the following format :

+--------------+--------------------------------+
| ``<csc>``    |                                |
+--------------+--------------------------------+
|              | ``<form>forme</form>``         |
+--------------+--------------------------------+
|              | ``<lem>lemme</lem>``           |
+--------------+--------------------------------+
|              | ``<code>code1</code>``         |
+--------------+--------------------------------+
|              | ``<code>code2</code>``         |
+--------------+--------------------------------+
|              | ``<inflect>flex1</inflect>``   |
+--------------+--------------------------------+
|              | ``<inflect>flex2</inflect>``   |
+--------------+--------------------------------+
| ``</csc>``   |                                |
+--------------+--------------------------------+

The DTD of our xml format is:

+--------------------------------------------------+
| ``<?xml version=1.0 encoding=ISO-8859-1?>``      |
+--------------------------------------------------+
| ``<!ELEMENT text (#PCDATA|csc)*>``               |
+--------------------------------------------------+
| ``<!ELEMENT csc (form,lem?,code*,inflect*) >``   |
+--------------------------------------------------+
| ``<!ELEMENT form (#PCDATA|csc)*>``               |
+--------------------------------------------------+
| ``<!ELEMENT lem (#PCDATA)>``                     |
+--------------------------------------------------+
| ``<!ELEMENT code (#PCDATA)>``                    |
+--------------------------------------------------+
| ``<!ELEMENT inflect (#PCDATA)>``                 |
+--------------------------------------------------+

.. [1]
   “Feder-Région Centre Entités nommées et nommables” managed by Denis
   Maurel, LI, Tours, France, integration carried out by Nathalie
   Friburger and David Nott
