Dictionaries
============

The DELA dictionaries
---------------------

The electronic dictionaries distributed with Unitex use the DELA syntax
(Dictionnaires Electroniques du LADL, LADL electronic dictionaries).
This syntax describes the simple and compound lexical entries of a
language with their grammatical, semantic and inflectional information.
We distinguish two kinds of electronic dictionaries. The one that is
used most often is the dictionary of inflected forms DELAF (DELA de
formes Fléchies, DELA of inflected forms) or DELACF (DELA de formes
Composées Fléchies, DELA of compound inflected forms) in the case of
compound forms. The second type is a dictionary of non-inflected forms
called DELAS (DELA de formes simples, simple forms DELA) or DELAC (DELA
de formes composées, compound forms DELA).

Unitex programs make no distinction between simple and compound form
dictionaries. We will use the terms DELAF and DELAS to distinguish the
inflected and non-inflected dictionaries, no matter they contain simple
word, compound words or both.

The DELAF format
~~~~~~~~~~~~~~~~

Entry syntax
^^^^^^^^^^^^

An entry of a DELAF is a line of text terminated by a newline that
conforms to the following syntax:

::

    apples,apple.N+conc:p/this is an example

The different elements of this line are:

-  ``apples`` is the inflected form of the entry; it is mandatory;

-  ``apple`` is the canonical form (lemma) of the entry. For nouns and
   adjectives (in French), it is usually the masculine singular form;
   for verbs, it is the infinitive. This information may be left out as
   in the following example:

   ``apple,.N+Conc:s``

   This means that the canonical form is the same as the inflected form.
   The canonical form is separated from the inflected form by a comma.

-  ``N+Conc`` is the sequence of grammatical and semantic information.
   In our example, ``N`` designates a noun, and ``Conc`` indicates that
   this noun designates a concrete object (see
   table [tab-semantic-codes]).

   Each entry must have at least one grammatical or semantic code,
   separated from the canonical form by a period. If there are more
   codes, these are separated by the ``+`` character.

-  ``:p`` is an inflectional code which indicates that the noun is
   plural. Inflectional codes are used to describe gender, number,
   declension, and conjugation. This information is optional. An
   inflectional code is made up of one or more characters that represent
   one information each. Inflectional codes have to be separated by the
   "``:``\ ” character, for instance in an entry like the following:

   ``hang,.V:W:P1s:P2s:P1p:P2p:P3p``

   The ``:`` character is interpreted in OR semantics. Thus,
   ``:W:P1s:P2s:P1p:P2p:P3p`` means “infinitive”, or “1st person
   singular present”, or “2nd person singular present”, etc. (see
   table [tab-inflectional-codes]) Since each character represents one
   information, you must not use the same character more than once. In
   this way, encoding the past participle using the code ``:PP`` would
   be exactly equivalent to using ``:P`` alone;

-  ``/this is an example`` is a comment. Comments are optional and are
   introduced by the ``/`` character. These comments are left out when
   the dictionaries are compressed.

IMPORTANT REMARK: It is possible to use the full stop and the comma
within a dictionary entry. In order to do this they have to be escaped
using the ``\`` character:

::

    1\,000,one thousand.NUMBER
    United Nations,U\.N\..ACRONYM

WARNING: Each character is taken into account within a dictionary line.
For example, if you insert spaces, they are considered to be a part of
the information. In the following line:

::

    hath,have.V:P3s /old form of 'has'

The space that precedes the ``/`` character will be considered to be
part of a 4-character inflectional code.

It is possible to insert comments into a DELAF or DELAS dictionary by
starting the line with a :math:`/` character. Example:

::

    / 'English' designates a pool spin
    English,.N+z3:s

Compound words with spaces or dashes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Certain compound words like *acorn-shell* can be written using spaces or
dashes. In order to avoid duplicating the entries, it is possible to use
the ``=`` character. At the time when the dictionary is compressed, the
``Compress`` program checks for each line if the inflected or canonical
form contains a non-escaped ``=`` character. If this is the case, the
program replaces this by two entries: one where the ``=`` character is
replaced by a space, and one where it is replaced by a dash. Thus, the
following entry:

``acorn=shells,acorn=shell.N:p``

is replaced by the following entries:

``acorn shells,acorn shell.N:p``

``acorn-shells,acorn-shell.N:p``

NOTE: If you want to keep an entry that includes the ``=`` character,
escape it using ``\`` as in the following example:

``E\=mc2,.FORMULA``

This replacement is done when the dictionary is compressed. In the
compressed dictionary, the escaped ``=`` characters are replaced by
simple ``=``. As such, if a dictionary containing the following lines is
compressed:

``E\=mc2,.FORMULA``

``acorn=shell,.N:s``

and if the dictionary is applied to the following text:

*Formulas like E=mc2 have nothing to do with acorn-shells.*

you will get the following lines in the dictionary of compound words of
the text:

::

    E=mc2,.FORMULA

    acorn-shells,.N:p

Entry Factorization
^^^^^^^^^^^^^^^^^^^

Several entries containing the same inflected and canonical forms can be
combined into a single one if they also share the same grammatical and
semantic codes. Among other things this allows us to combine identical
conjugations for a verb:

::

    bottle,.V:W:P1s:P2s:P1p:P2p:P3p

If the grammatical and semantic information differ, one has to create
distinct entries:

::

    bottle,.N+Conc:s
    bottle,.V:W:P1s:P2s:P1p:P2p:P3p

Some entries that have the same grammatical and semantic entries can
have different meanings, as it is the case for the French word *poêle*
that describes a stove or a type of sheet in the masculine sense and a
kitchen instrument in the feminine sense. You can thus distinguish the
entries in this case:

``poêle,.N+z1:fs/ poêle à frire``

``poêle,.N+z1:ms/ voile, linceul; appareil de chauffage``

NOTE: In practice, this distinction has the only consequence that the
number of entries in the dictionary increases.

For the different programs that make up Unitex these entries are
equivalent to:

``poêle,.N+z1:fs:ms``

Whether this distinction is made is thus left to the maintainers of the
dictionaries.

The DELAS Format
~~~~~~~~~~~~~~~~

The DELAS format is very similar to the one used in the DELAF. The only
difference is that there is only a canonical form followed by
grammatical and/or semantic codes. The canonical form is separated from
the different codes by a comma. There is an example:

::

    horse,N4+Anl

The first grammatical or semantic code will be interpreted by the
inflection program as the name of the grammar used to inflect the entry.
The entry of the example above indicates that the word *horse* has to be
inflected using the grammar named ``N4``. It is possible to add
inflectional codes to the entries, but the nature of the inflection
operation limits the usefulness of this possibility. For more details
see below in section [section-automatic-inflection].

Dictionary Contents
~~~~~~~~~~~~~~~~~~~

The dictionaries provided with Unitex contain descriptions of simple and
compound words. These descriptions indicate the grammatical category of
each entry, optionally their inflectional codes, and various semantic
information. The following tables give an overview of some of the
different codes used in the Unitex dictionaries. These codes are the
same for almost all languages, though some of them are special for
certain languages (*i.e.* code for neuter nouns, etc.).

+-------------+-----------------------------+--------------------------+
| **Code**    | **Description**             | **Examples**             |
+=============+=============================+==========================+
| ``A``       | adjective                   | fabulous, broken-down    |
+-------------+-----------------------------+--------------------------+
| ``ADV``     | adverb                      | actually, years ago      |
+-------------+-----------------------------+--------------------------+
| ``CONJC``   | coordinating conjunction    | but                      |
+-------------+-----------------------------+--------------------------+
| ``CONJS``   | subordinating conjunction   | because                  |
+-------------+-----------------------------+--------------------------+
| ``DET``     | determiner                  | each                     |
+-------------+-----------------------------+--------------------------+
| ``INTJ``    | interjection                | eureka                   |
+-------------+-----------------------------+--------------------------+
| ``N``       | noun                        | evidence, group theory   |
+-------------+-----------------------------+--------------------------+
| ``PREP``    | preposition                 | without                  |
+-------------+-----------------------------+--------------------------+
| ``PRO``     | pronoun                     | you                      |
+-------------+-----------------------------+--------------------------+
| ``V``       | verb                        | overeat, plug-and-play   |
+-------------+-----------------------------+--------------------------+

Table: Frequent grammatical codes[tab-grammatical-codes]

+----------------+-----------------------------+-----------------+
| **Code**       | **Description**             | **Example**     |
+================+=============================+=================+
| ``z1``         | general language            | joke            |
+----------------+-----------------------------+-----------------+
| ``z2``         | specialized language        | floppy disk     |
+----------------+-----------------------------+-----------------+
| ``z3``         | very specialized language   | serialization   |
+----------------+-----------------------------+-----------------+
| ``Abst``       | abstract                    | patricide       |
+----------------+-----------------------------+-----------------+
| ``Anl``        | animal                      | horse           |
+----------------+-----------------------------+-----------------+
| ``AnlColl``    | collective animal           | flock           |
+----------------+-----------------------------+-----------------+
| ``Conc``       | concrete                    | chair           |
+----------------+-----------------------------+-----------------+
| ``ConcColl``   | collective concrete         | rubble          |
+----------------+-----------------------------+-----------------+
| ``Hum``        | human                       | teacher         |
+----------------+-----------------------------+-----------------+
| ``HumColl``    | collective human            | parliament      |
+----------------+-----------------------------+-----------------+
| ``t``          | transitive verb             | kill            |
+----------------+-----------------------------+-----------------+
| ``i``          | intransitive verb           | agree           |
+----------------+-----------------------------+-----------------+

Table: Some semantic codes[tab-semantic-codes]

NOTE: The descriptions of tense in table [tab-inflectional-codes]
correspond to French. Nontheless, the majority of these definitions can
be found in other languages (infinitive, present, past participle,
etc.).

In spite of a common base in the majority of languages, the dictionaries
contain encoding particularities that are specific for each language.
Thus, as inflectional codes vary a lot between different languages, they
are not described here. For a complete description of all codes used
within a dictionary, we recommend that you contact the author of the
dictionary directly.

+-----------------------+--------------------------+
| **Code**              | **Description**          |
+=======================+==========================+
| ``m``                 | masculine                |
+-----------------------+--------------------------+
| ``f``                 | feminin                  |
+-----------------------+--------------------------+
| ``n``                 | neuter                   |
+-----------------------+--------------------------+
| ``s``                 | singular                 |
+-----------------------+--------------------------+
| ``p``                 | plural                   |
+-----------------------+--------------------------+
| ``1``, ``2``, ``3``   | 1st, 2nd, 3rd person     |
+-----------------------+--------------------------+
| ``P``                 | present indicative       |
+-----------------------+--------------------------+
| ``I``                 | imperfect indicative     |
+-----------------------+--------------------------+
| ``S``                 | present subjunctive      |
+-----------------------+--------------------------+
| ``T``                 | imperfect subjunctive    |
+-----------------------+--------------------------+
| ``Y``                 | present imperative       |
+-----------------------+--------------------------+
| ``C``                 | present conditional      |
+-----------------------+--------------------------+
| ``J``                 | simple past indicative   |
+-----------------------+--------------------------+
| ``W``                 | infinitive               |
+-----------------------+--------------------------+
| ``G``                 | present participle       |
+-----------------------+--------------------------+
| ``K``                 | past participle          |
+-----------------------+--------------------------+
| ``F``                 | future indicative        |
+-----------------------+--------------------------+

Table: Common inflectional codes[tab-inflectional-codes]

However, these codes are not exclusive. A user can introduce his own
codes and create his own dictionaries. For example, for educational
purposes one could use a marker “faux-ami” (*false friend*) in a French
dictionary:

``blesser,.V+faux-ami/injure``

``casque,.N+faux-ami/helmet``

``journée,.N+faux-ami/day``

It is equally possible to use dictionaries to add extra information.
Thus, you can use the inflected form of an entry to describe an
abbreviation and the canonical form to provide the complete form:

::

    DNA,DeoxyriboNucleic Acid.ACRONYM
    LADL,Laboratoire d'Automatique Documentaire et Linguistique.ACRONYM
    UN,United Nations.ACRONYM

Looking up a word in a dictionary
---------------------------------

[section-dictionary-lookup] You can look up a word in one or several
dictionaries by two means :

.. figure:: resources/img/fig3-1.png
   :alt: “DELA” Menu
   :width: 13.00000cm

   “DELA” Menu

If you have opend a dictionary, the displayed window contains a field
where you can enter a word to search. If the word appears in the
dictionary, the Find Button will highlight the first entry that matches
it. If there is several entries for this word, you can browse all
matches by clicking on the two arrow buttons.

.. figure:: resources/img/fig3-2.png
   :alt: Looking up for a word in a dictionnary
   :width: 7.00000cm

   Looking up for a word in a dictionnary

You can also look up a word in several dictionnaries by clicking on the
Lookup button of the DELA menu. You can then select the dictionaries in
which you want to look up the word you have entered.

.. figure:: resources/img/fig3-3.png
   :alt: Looking up for a word in several dictionnaries
   :width: 7.00000cm

   Looking up for a word in several dictionnaries

Checking dictionary format
--------------------------

When dictionaries become large, it becomes tiresome to check them by
hand. Unitex contains the program ``CheckDic`` that automatically checks
the format of DELAF and DELAS dictionaries.

This program verifies the syntax of the entries. For each malformed
entry the program outputs the line number, the content of the line and
an error message. Results are saved in the file ``CHECK_DIC.TXT`` which
is displayed when the verification is finished. In addition to eventual
error messages, the file also contains the list of all characters used
in the inflectional and canonical forms, the list of grammatical and
semantic codes, and the list of inflectional codes that appear in the
dictionary. The character list makes it possible to verify that the
characters used in the dictionary are consistent with those in the
alphabet file of the language. Each character is followed by its value
in hexadecimal notation.

The code lists can be used to check that there are no typing errors in
the codes of the dictionary.

The ``CheckDic`` program works with non-compressed dictionaries, *i.e.*
the files in text format. The general convention is to use the ``.dic``
extension for these dictionaries. In order to check the format of a
dictionary, you first open it by choosing “Open...” in the “DELA” menu.

.. figure:: resources/img/fig3-4.png
   :alt: Dictionary example[fig-dictionary-example]
   :width: 10.00000cm

   Dictionary example[fig-dictionary-example]

Let’s load the dictionary as in figure [fig-dictionary-example]. Then,
click on “Check Format...” in the “DELA” menu. A window like in
figure [fig-dictionary-checking] is opened. You must select the type of
dictionary you want to check. After checking the dictionary in
Figure [fig-dictionary-example], results are presented as shown in
Figure [fig-dictionary-checking-results].

.. figure:: resources/img/fig3-5.png
   :alt: Checking a dictionary[fig-dictionary-checking]
   :width: 7.00000cm

   Checking a dictionary[fig-dictionary-checking]

.. figure:: resources/img/fig3-6.png
   :alt: Results of checking[fig-dictionary-checking-results]
   :height: 19.40000cm

   Results of checking[fig-dictionary-checking-results]

The first error is caused by a missing period. The second, by the fact
that no comma was found after the end of an inflected form. The third
error indicates that the program didn’t find any grammatical or semantic
codes.

Sorting
-------

Unitex uses the dictionaries without having to worry about the order of
the entries. When displaying them it is sometimes preferable to sort the
dictionaries. The sorting depends on a number of criteria, first of all
on the language of the text. Therefore the sorting of a Thai dictionary
is done according to an order different from the alphabetical order. So
different in fact that Unitex uses a sorting procedure developed
specifically for Thai (see chapter [chap-external-programs]).

For European languages the sorting is usually done according to the
lexicographical order, although there are some variants. Certain
languages like French treat some characters as equivalent. For example,
the difference between the characters ``e`` and ``é`` is ignored if one
wants to compare the words ``manger`` et ``mangés`` because the contexts
``r`` and ``s`` allow to decide the order. The difference is only taken
into account when the contexts are identical, as they are when comparing
``pêche`` and ``pèche``.

To allow for such effect, the ``SortTxt`` program uses a file which
defines the equivalence of characters. This file is named
``Alphabet_sort.txt`` and can be found in the user directory for the
current language. By default the first lines of this file for French
look like this:

``AÀÂÄaàâä``

``Bb``

``CÇcç``

``Dd``

``EÉÈÊËeéèêë``

Characters in the same line are considered equivalent if the context
permits. If two equivalent characters must be compared, they are sorted
in the order they appear in from left to right. As can be seen from the
extract above, there is no difference between lower and upper case.
Accents and the cédille character are ignored as well.

To sort a dictionary, open it and then click on “Sort Dictionary” in the
“DELA” menu. By default, the program always looks for the file
``Alphabet_sort.txt``. If that file doesn’t exist, the sorting is done
according to the character indices in the Unicode encoding. By modifying
that file, you can define your own sorting order.

NOTE: After applying the dictionaries to a text, the files ``dlf``,
``dlc`` and ``err`` are automatically sorted using this program.

Automatic inflection
--------------------

Inflection of simple words
~~~~~~~~~~~~~~~~~~~~~~~~~~

As described in section [section-DELAS-format], a line in a DELAS
consists of a canonical form and a sequence of grammatical or semantic
codes:

::

    aviatrix,N4+Hum
    matrix,N4+Math
    radix,N4

The first code is used to determine the grammatical code of the entry as
well as the name of the grammar used to inflect the canonical form.
There are two possible forms:

-  ``N4``: grammar name=\ ``N4.fst2``, grammatical code=\ ``N`` (longest
   letter prefix)

-  ``N(NC_XXX)``: grammar name=\ ``NC_XXX.fst2``, grammatical
   code=\ ``N``

These inflectional grammars will automatically be compiled if needed. In
the example above, all entries will be inflected by a grammar named
``N4``.

In order to inflect a dictionary, click on “Inflect...” in the “DELA”
menu. The window in figure [fig-inflection-configuration] allows you to
specify the directory in which inflectional grammars are found. By
default, the subdirectory ``Inflection`` of the directory for the
current language is used. You can also specify the kind of words your
DELAS is supposed to contain. If an entry is found that does not
correspond to your choice, an error message will be displayed.

.. figure:: resources/img/fig3-7.png
   :alt: Configuration of automatic
   inflection[fig-inflection-configuration]
   :width: 8.00000cm

   Configuration of automatic inflection[fig-inflection-configuration]

.. figure:: resources/img/fig3-8.png
   :alt: Inflectional grammar ``N4``\ [fig-example-inflectional-grammar]
   :width: 4.50000cm

   Inflectional grammar ``N4``\ [fig-example-inflectional-grammar]

Figure [fig-example-inflectional-grammar] shows an example of an
inflectional grammar. The paths describe the suffixes to add or to
remove to get to an inflected form from a canonical form, and the
outputs (text in bold under the boxes) are the inflectional codes to add
to a dictionary entry.

In our example, two paths are possible. The first does not modify the
canonical form and adds the inflectional code ``:s``. The second deletes
a letter with the ``L`` operator, then adds the ``ces`` suffix and adds
the inflectional code ``:mp``. Here are the operators that can be used:

-  ``L`` (left) removes a letter from the entry.

-  ``R`` (right) restores a letter to the entry. In French, many verbs
   of the first group are conjugated in the present singular of the
   third person form by removing the ``r`` of the infinitive and
   changing the 4\ :math:`^{th}` letter from the end to ``è``: ``peler``
   :math:`\rightarrow` ``pèle``, ``acheter`` :math:`\rightarrow`
   ``achète``, ``gérer`` :math:`\rightarrow` ``gère``, etc. Instead of
   describing an inflectional suffix for each verb (``LLLLèle``,
   ``LLLLète`` and ``LLLLère``), the ``R`` operator can be used to
   describe it in one way: ``LLLLèRR``.

-  ``C`` (copy) duplicates a letter in the entry and moves everything on
   its right by one position. In cases like ``permitted`` or ``hopped``,
   we see a duplication of the final consonant of the verb. To avoid
   writing an inflectional graph for every possible final consonant, one
   can use the ``C`` operator to duplicate any final consonant.

-  ``D`` (delete) deletes a letter, shifting anything located on the
   right of this letter. For instance, if you want to inflect the
   Romanian word ``european`` into ``europeni``, you must use the
   sequence ``LDRi``. ``L`` will move the cursor on the ``a``, ``D``
   will delete the ``a``, shifting the ``n`` on the left, and then
   ``Ri`` will restore the ``n`` and add an ``i``.

-  ``U`` (unaccent) removes the accent of the current character, if any.
   For instance the sequence ``LLUx`` applied to the word ``mangés``
   produces the inflected form ``mangex``, since ``U`` has turn the
   ``é`` into a ``e``.

-  ``P`` (uppercase) uppercases the initial letter of the stack. For
   instance, the sequence ``Px`` will turn ``foo`` into ``Foox``.

-  ``W`` (lowercase) lowercases the initial letter of the stack.

-  ``<R=?>`` replaces the initial letter of the stack by the letter
   ``?``.

-  ``<I=?>`` inserts the letter ``?`` before the initial letter of the
   stack.

-  ``<X=n>`` removes the first :math:`n` letters of the stack.

There are also two operators dedicated to Korean:

-  ``J`` removes a Jamo letter. If the current character is a Hangul
   syllab character, this character is first replaced by the equivalent
   Jamo sequence, and then, the last Jamo letter is removed. If the
   current character is neither a Jamo nor a Hangul, and error is
   raised.

-  ``.`` (latin dot) inserts a syllab bound. As a side effect, if the
   top of the stack contains Jamo letters, they are first recombined
   into a Hangul character.

In the example below, the inflection of ``choose`` is shown. The
sequence ``LLDRRn`` describes the form ``chosen``:

-  Step 0: the canonical form is copied on the stack, and the cursor is
   set behind the last letter:

   +---------+---------+---------+---------+---------+---------+---------+----+
   | ``c``   | ``h``   | ``o``   | ``o``   | ``s``   | ``e``   | `` ``   |    |
   +---------+---------+---------+---------+---------+---------+---------+----+

-  Step 1: the cursor is moved one position to the left:

   ``LLDRRn``

   +---------+---------+---------+---------+---------+---------+---------+----+
   | ``c``   | ``h``   | ``o``   | ``o``   | ``s``   | ``e``   | `` ``   |    |
   +---------+---------+---------+---------+---------+---------+---------+----+

-  Step 2: the cursor is moved one position to the left again:

   ``LLDRRn``

   +---------+---------+---------+---------+---------+---------+---------+----+
   | ``c``   | ``h``   | ``o``   | ``o``   | ``s``   | ``e``   | `` ``   |    |
   +---------+---------+---------+---------+---------+---------+---------+----+

-  Step 3: one character is deleted; everything to the right of the
   cursor is shifted one position to the left:

   ``LLDRRn``

   +---------+---------+---------+---------+---------+---------+---------+----+
   | ``c``   | ``h``   | ``o``   | ``s``   | ``e``   | `` ``   | `` ``   |    |
   +---------+---------+---------+---------+---------+---------+---------+----+

-  Step 4: the cursor is moved to the right:

   ``LLDRRn``

   +---------+---------+---------+---------+---------+---------+---------+----+
   | ``c``   | ``h``   | ``o``   | ``s``   | ``e``   | `` ``   | `` ``   |    |
   +---------+---------+---------+---------+---------+---------+---------+----+

-  Step 5: and to the right again:

   ``LLDRRn``

   +---------+---------+---------+---------+---------+---------+---------+----+
   | ``c``   | ``h``   | ``o``   | ``s``   | ``e``   | `` ``   | `` ``   |    |
   +---------+---------+---------+---------+---------+---------+---------+----+

-  Step 6: the character ``n`` is pushed on the stack:

   ``LLDRRn``

   +---------+---------+---------+---------+---------+---------+---------+----+
   | ``c``   | ``h``   | ``o``   | ``s``   | ``e``   | ``n``   | `` ``   |    |
   +---------+---------+---------+---------+---------+---------+---------+----+

When all operations have been fulfilled, the inflected form consists of
all letters before the cursor (here ``chosen``).

The inflection program explores all paths of the inflectional grammar
and tries all possible forms. In order to avoid having to replace the
names of inflectional grammars by the actual grammatical codes to be
used in the dictionary, the program replaces these names by the longest
prefixes made of letters. Thus, ``N4`` is replaced by ``N``. By choosing
the inflectional grammar names carefully, one can construct a
ready-to-use dictionary.

Figure [fig-inflection-result] shows the dictionary we get after the
inflection of our DELAS example.

.. figure:: resources/img/fig3-9.png
   :alt: Result of automatic inflection[fig-inflection-result]
   :width: 9.50000cm

   Result of automatic inflection[fig-inflection-result]

Advanced inflection operators
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In some languages the inflection process can modify the root of the
word. Several operators have been developped in order to facilitate this
type of treatment. They allow to find and remove a suffix of the word
``W`` to be inflected. It is also possible to store a factor of this
suffix by using a special variable ($ or :math:`{\pounds}`). These
operators can take the following forms:

-  ``<X$Y>``: Starting from the end of the word ``W`` we are looking for
   the suffix ``Y``. Then, we search for the **rightmost** occurrence of
   ``X`` which strictly precedes that of ``Y`` . The $ variable then
   contains the **shortest factor** (**$**\ hortest) of ``W`` strictly
   between ``X`` and ``Y`` (``W = U.X.$.Y``) [1]_. The ``<X$Y>``
   operator strips ``X.$.Y`` from ``W`` and sets $. After it has been
   applied, the string left in the stack is ``U``, and the $ variable
   can be used in the rest of the path.

-  ``<X``\ :math:`{\pounds}`\ ``Y>``: Starting from the end of the word
   ``W`` we are looking for the suffix ``Y``. Then, we search for the
   **leftmost** occurrence of ``X`` which strictly precedes that of
   ``Y``. The £ variable then contains the **longest factor**
   (**:math:`{\pounds}`**\ ongest) of ``W`` strictly between ``X`` and
   ``Y`` (``W = U.X.``\ :math:`{\pounds}`\ ``.Y``).

-  ``<X>``: If there is no variable, we search for ``X`` as a suffix of
   ``W`` (``W = U.X``).

-  ``<$Y>``: If the ``X`` factor is absent, the **shortest factor
   ``$``** is the first letter which strictly precedes ``Y`` .

-  ``<``\ :math:`{\pounds}`\ ``Y>``: If the ``X`` factor is absent, the
   **longest factor :math:`{\pounds}`** is the prefix of ``W`` so that
   ``W = ``\ :math:`{\pounds}` ``.Y``.

To illustrate the use of these operators, let us consider the French
verb *reprendre*:

+-------------+------------+---------------------------+-----------------------+
| Word        | Operator   | Variable                  | Result                |
+=============+============+===========================+=======================+
| reprendre   | <re>       |                           | reprend               |
+-------------+------------+---------------------------+-----------------------+
| reprendre   | <$>        | $ = e                     | reprendr              |
+-------------+------------+---------------------------+-----------------------+
| reprendre   | <£>        | £= reprendre              | :math:`\varepsilon`   |
+-------------+------------+---------------------------+-----------------------+
| reprendre   | <re$re>    | $ = nd                    | rep                   |
+-------------+------------+---------------------------+-----------------------+
| reprendre   | <re£re>    | £ = prend                 |                       |
+-------------+------------+---------------------------+-----------------------+
| reprendre   | <$re>      | $ = d                     | repren                |
+-------------+------------+---------------------------+-----------------------+
| reprendre   | <re$>      | $ = :math:`\varepsilon`   | reprendre             |
+-------------+------------+---------------------------+-----------------------+
| reprendre   | <£re>      | £ = reprend               | :math:`\varepsilon`   |
+-------------+------------+---------------------------+-----------------------+
| reprendre   | <re£>      | £ = prendre               | re                    |
+-------------+------------+---------------------------+-----------------------+

The MultiFlex program allows you to use ten variables of type $ whose
names are $,$1,...,$9 and ten variables of type £ whose names are
£,£1,...,£9. Morever, both types of variables can be mixed in a same
operator. Thus the operator <£3re$7re> applied to the french verb
*reprendre* gives back : £3 = rep et $7 = ``nd``.

In the verbs ``accélérer``, ``sécher``, the second person of the present
tense can be generated by the operation <é$er>è$es :

+-----------------+----------+-----------------------+---------+----------+-----+--------+-----------------------+-----------------+
| ``accélérer``   | <é$er>   | :math:`\rightarrow`   | accél   | $ = r    | +   | è$es   | :math:`\rightarrow`   | ``accélères``   |
+-----------------+----------+-----------------------+---------+----------+-----+--------+-----------------------+-----------------+
| ``sécher``      | <é$er>   | :math:`\rightarrow`   | s       | $ = ch   | +   | è$es   | :math:`\rightarrow`   | ``sèches``      |
+-----------------+----------+-----------------------+---------+----------+-----+--------+-----------------------+-----------------+

Note that the factor ``$`` which remains in the inflected form is of
variable length (``r``, ``ch``). The inflection of the verbs
``accélérer`` and ``sécher`` cannot be done with classical stack
operators within the same operation. Two different operations
(``-4RèCes``, ``-5RèCes``) are needed. The graph shown in
figure [fig-inflection-secher] inflects verbs like ``accélérer`` and
``sécher`` in the present tense.

.. figure:: resources/img/fig3-Advanced_operators_with_Variables-V_secher.png
   :alt: Inflection graph for verbs like *accélérer*, *sécher*
   [fig-inflection-secher]
   :width: 7.00000cm

   Inflection graph for verbs like *accélérer*, *sécher*
   [fig-inflection-secher]

The inflected forms of the verbs ``accélérer`` and ``sécher`` are :

|image|

The doubling of some letters during the inflection process can be done
with the operator $. For example the adjective *tranquil* has two forms
in the comparative and two in the superlative. The graph in figure
 [fig-inflection-tranquil] can produce these forms.

.. figure:: resources/img/fig3-Advanced_operators_with_Variables-A_tranquil.png
   :alt: Inflection graph for adjectives like *tranquil*
   [fig-inflection-tranquil]
   :width: 5.50000cm

   Inflection graph for adjectives like *tranquil*
   [fig-inflection-tranquil]

Below are the inflected forms for the adjective ``tranquil`` :

|image|

In some languages, some inflected forms have a prefix added before the
root like the formation of the past participle in German. The joint use
of operators :math:`{\pounds}` et ``$`` allows to inflect the german
verb ``sprechen`` (to speak) in the present tense and the past
participle as shown in the graph in figure [fig-inflection-sprechen].

.. figure:: resources/img/fig3-Advanced_operators_with_Variables-V_sprechen.png
   :alt: Inflection graph for verbs like *sprechen*
   [fig-inflection-sprechen]
   :width: 5.00000cm

   Inflection graph for verbs like *sprechen* [fig-inflection-sprechen]

The inflection forms of the verb ``sprechen`` :

|image|

In order to inflect the phrasal verb ``aussprechen`` two variables of
type $ should be used. Figure  [fig-inflection-aussprechen] shows a
graph with two variables ``$1`` and ``$2``.

.. figure:: resources/img/fig3-Advanced_operators_with_Variables-V_aussprechen.png
   :alt: Inflection graph for verbs like *aussprechen*
   [fig-inflection-aussprechen]
   :width: 10.50000cm

   Inflection graph for verbs like *aussprechen*
   [fig-inflection-aussprechen]

Here are the inflection forms of the verb ``aussprechen`` :

|image|

**Semantic codes**

In some languages, there are inflectional features that actually
correspond to semantic ones, like for instance markers for the passive
form. Such codes may not appear as inflectional ones, but rather as
semantic ones. To do that and produce semantic codes, you have to insert
a plus sign at the beginning of the output of a box. The box must only
contain the semantic code preceeded by a plus, as shown on Figure
[fig-inflection-sem].

.. figure:: resources/img/fig3-9sem.png
   :alt: An inflection grammar with a semantic code[fig-inflection-sem]
   :width: 6.00000cm

   An inflection grammar with a semantic code[fig-inflection-sem]

Inflection of compound words
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

See chapter [chap-multiflex].

Inflection of Semitic languages
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Semitic languages like Arabic or Hebrew are inflected in a way not
easily representable with the inflection operators described above.
Their morphology obeys a different logic: words are inflected according
to *consonant skeletons*. The inflection process combines this skeleton
with vowels. Specific operators have been implemented for Semitic
languages, and some of them may be useful also for languages outside the
Semitic family, such as Tagalog.

First, let us see a case where we encode only the consonants in the
lemma field of the DELAS entry:

``ktb,$V31-123``

The ``$`` sign before the grammatical code indicates that the inflection
grammar is in the Semitic mode, and the form ``ktb`` in the lemma field
is the consonant skeleton. Figure [semitic-grammar] shows the toy
grammar ``V31-123.grf`` that illustrates how the Semitic mode works. The
inflection grammars use the Buckwalter++ transliteration of the Arabic
script (cf. Section [transliteration-Arabic]).

.. figure:: resources/img/fig3-15.png
   :alt: A toy inflection grammar[semitic-grammar] in the Semitic mode
   :width: 10.00000cm

   A toy inflection grammar[semitic-grammar] in the Semitic mode

The Semitic mode obeys the following rules:

#. All standard inflection operators can be used (``L``, ``R``, etc.).

#. A digit stands for a letter in the lemma field (``1`` for the first,
   ``2`` for the second, etc.). In our example, ``1``, ``2`` and ``3``
   will respectively stand for ``k``, ``t`` and ``b``. If you want to
   access to a letter after the ninth one, you must protect its index
   with angles like ``<10>``.

The DELAF output for this grammar is:

``yakotubu,ktb.V:aI3ms``

If we encode only the consonants in the lemma field and two entries have
the same consonants but differ in the vowels, we must encode the vowels
in the inflection grammars:

``Hsb,$V3au // to count, Hasaba, yaHosubu``

``Hsb,$V3ii // to think, Hasiba, yaHosibu``

.. figure:: resources/img/fig3-LEMMA-operator.png
   :alt: An inflection grammar in the Semitic mode with the <LEMMA>
   operator[LEMMA-operator]
   :width: 10.00000cm

   An inflection grammar in the Semitic mode with the <LEMMA>
   operator[LEMMA-operator]

In order to copy the complete lemma field, use the <LEMMA> operator. A
box with this operator retrieves the complete lemma field but does not
depend on the number of letters in the field. This operator is useful
for Arabic nouns and adjectives where masculine forms are generated by
inserting vowels in the consonantal skeleton, whereas feminine forms are
obtained by appending suffixes (Figure [LEMMA-operator]). In this
example, both consonants and vowels are encoded in the lemma field.

The <n.LEMMA> operator copies the lemma from the :math:`n`\ th position
to the end. For example, in some Arabic nouns, the short vowel of the
first syllable alternates: ``a/u``, ``a/i`` or ``u/i``, as in
``nufaAyap``/``nifaAyap`` ”rubbish”. The inflection grammar of
Fig. [n.LEMMA-operator] produces both variants with ``u`` and with ``i``
as inflected forms of ``nufaAyap``.

.. figure:: resources/img/N0_i_0ap-f-At.png
   :alt: An inflection grammar in the Semitic mode with the <n.LEMMA>
   operator[n.LEMMA-operator]
   :width: 14.00000cm

   An inflection grammar in the Semitic mode with the <n.LEMMA>
   operator[n.LEMMA-operator]

In Tagalog, an Austronesian language spoken in the Philippines and that
uses commonly infixes and reduplication for inflection, <LEMMA> and
<n.LEMMA> may be used to produce verb tenses. The toy inflection grammar
of Fig. [tagalog] produces the perfect ``kumain``, future ``kakain`` and
imperfect ``kumakain`` of the verb ``kain`` ”eat”.

.. figure:: resources/img/V1um.png
   :alt: A toy inflection grammar for Tagalog in the Semitic
   mode[tagalog]
   :width: 12.00000cm

   A toy inflection grammar for Tagalog in the Semitic mode[tagalog]

Transliterating Arabic dictionaries
-----------------------------------

When Arabic linguists analyse dictionaries in order to spot errors,
reading in the Arabic script is simple and efficient. However, when they
create inflectional grammars (Section [section-automatic-inflection]),
parts of Arabic words occur in the same box as morphosyntactic
information encoded in the Latin alphabet, and in this context,
switching from right-to-left Arabic script to left-to-right Latin
alphabet is a real hassle. With Unitex, you can encode your inflectional
grammars entirely in the Latin alphabet, by using the Buckwalter++
transliteration, a one-to-one mapping between a Unicode encoding of
Arabic script and Latin letters (cf. :raw-latex:`\cite{neme2011}`,
Section 3.2, pages 4–6). The Buckwalter++ transliteration is defined by
the table of Fig. [buckwalter1] and [buckwalter2]. Unitex provides a
tool to internally transliterate DELAS and DELAF Arabic dictionaries to
and from Buckwalter++ encoding (Fig. [Arabic-transliteration]). This
tool is accessible through the DELA menu.

.. figure:: resources/img/buckwalter1.pdf
   :alt: Buckwalter++ transliteration table, first half[buckwalter1]
   :height: 23.50000cm

   Buckwalter++ transliteration table, first half[buckwalter1]

.. figure:: resources/img/buckwalter2.pdf
   :alt: Buckwalter++ transliteration table, second half[buckwalter2]
   :height: 23.50000cm

   Buckwalter++ transliteration table, second half[buckwalter2]

.. figure:: resources/img/Arabic-transliteration.pdf
   :alt: Transliteration of a DELAF dictionary from Buckwalter++ (left)
   to the Arabic script (right)[Arabic-transliteration]
   :width: 15.00000cm

   Transliteration of a DELAF dictionary from Buckwalter++ (left) to the
   Arabic script (right)[Arabic-transliteration]

Compression
-----------

Unitex applies compressed dictionaries to the text. The compression
reduces the size of the dictionaries and speeds up the lookup. This
operation is done by the ``Compress`` program. This program takes a
dictionary in text form as input (for example ``my_dico.dic``) and
produces two files:

-  ``my_dico.bin`` contains the minimal automaton of the inflected forms
   of the dictionaries;

-  ``my_dico.inf`` contains the codes extracted from the original
   dictionary.

The minimal automaton in the ``my_dico.bin`` file is a representation of
inflected forms in which all common prefixes and suffixes are
factorized. For example, the minimal automaton of the words ``me``,
``te``, ``se``, ``ma``, ``ta`` et ``sa`` can be represented by the graph
shown in Figure [fig-example-minimal-automaton].

.. figure:: resources/img/fig3-10.png
   :alt: Representation of a minimal
   automaton[fig-example-minimal-automaton]
   :width: 5.00000cm

   Representation of a minimal automaton[fig-example-minimal-automaton]

To compress a dictionary, open it and click on “Compress into FST” in
the “DELA” menu. The compression is independent from the language and
from the content of the dictionary. The messages produced by the program
are displayed in a window that is not closed automatically. You can see
the size of the resulting ``.bin`` file, the number of lines read and
the number of inflectional codes created.
Figure [fig-compression-result] shows the result of the compression of a
dictionary of simple words.

.. figure:: resources/img/fig3-11.png
   :alt: Results of a compression[fig-compression-result]
   :width: 14.00000cm

   Results of a compression[fig-compression-result]

The resulting files are compressed to about 95% for dictionaries
containing simple words and 50% for those with compound words.

When the Semitic mode ([subsection-semitic-inflection]) has been heavily
used to inflect a dictionary, a specific variant of the compression
algorithm may reduce the size of the resulting ``.bin`` and ``.inf``
files. In order to use it, either declare the language as being a
Semitic one in the global preferences by checking the ”Semitic language”
option in ”Preferences > Language and Presentation”, or use the Compress
program in command line with the ``--semitic`` option.

Applying dictionaries
---------------------

Dictionaries can be applied (1) after pre-processing or (2) by
explicitly clicking on “Apply Lexical Resources” in the “Text” menu (see
section [text-applying-dictionaries]).

Unitex can manipulate compressed dictionaries (``.bin``) and dictionary
graphs (``.fst2``). We will now describe the rules for applying
dictionaries in detail. Dictionary graphs will be described in
section [section-dictionary-graphs].

Priorities
~~~~~~~~~~

The priority rule says that if a word in a text is found in a
dictionary, this word will not be taken into account by dictionaries
with lower priority.

This allows for eliminating a part of ambiguity when applying
dictionaries. For example, the French word *par* has a nominal
interpretation in the golf domain. If you don’t want to use this
meaning, it is sufficient to create a filter dictionary containing only
the entry ``par,.PREP`` and to apply this with highest priority. This
way, even if simple word dictionaries contain different entries, they
will be ignored given the priority rule.

There are three priority levels. The dictionaries whose names without
extension end with \ ``-`` have the highest priority; those that end
with \ ``+`` have the lowest one. All other dictionaries are applied
with medium priority. The order in which dictionaries with the same
priority are applied does not matter. On the command line, the command:

``Dico ex.snt alph.txt ctr+.bin cities-.bin rivers.bin regions-.bin``

will apply the dictionaries in the following order (``ex.snt`` is the
text to which the dictionaries are applied, and ``alph.txt`` is the
alphabet file used):

#. ``cities-.bin``

#. ``regions-.bin``

#. ``rivers.bin``

#. ``ctr+.bin``

Application rules for dictionaries
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Besides the priority rule, the application of dictionaries respects
upper case letters and spaces. The upper case rule is as follows:

-  if there is an upper case letter in the dictionary, then an upper
   case letter has to be in the text;

-  if a lower case letter is in the dictionary, there can be either an
   upper or lower case letter in the text.

Thus, the entry ``peter,.N:fs`` will match the words ``peter``,
``Peter`` et ``PETER``, while

``Peter,.N+firstName`` only recognizes ``Peter`` and ``PETER``. Lower
and upper case letters are defined in the alphabet file passed to the
``Dico`` program as a parameter.

Respecting white space is a very simple rule: For each sequence in the
text to be recognized by a dictionary entry, it has to have exactly the
same number of spaces. For example, if the dictionary contains
``aujourd'hui,.ADV``, the sequence ``Aujourd' hui`` will not be
recognized because of the space that follows the apostrophe.

Dictionary graphs
~~~~~~~~~~~~~~~~~

The ``Dico`` program can also apply dictionary graphs. Dictionary
graphs, by default, [2]_ conform to the following rule: if applied by
``Locate`` in MERGE mode, they must produce output sequences that are
valid DELAF lines. When they are applied to a text, they attach the
DELAF lexical labels to the sequences.

.. figure:: resources/img/fig3-12.png
   :alt: Dictionary graph of chemical elements[elements]
   :height: 24.00000cm

   Dictionary graph of chemical elements[elements]

Figure [elements] shows a graph that recognizes chemical elements. We
can observe a first advantage of graphs over usual dictionaries: we can
force case with double quotes. Thus, this graph will correctly match
``Fe`` but not ``FE``, while this restriction cannot be specified in a
normal DELAF.

Another advantage of dictionary graphs is that they can use results
given by previous dictionaries. Thus, it is possible to apply the
standard dictionary, and then tag as proper names all the unknown words
that begin with an uppercase letter, thanks to graph ``NPr+`` shown in
figure [graph-NPr]. The ``+`` in the graph name gives to it a low
priority, so that it will be applied after the standard dictionary. This
graph works with words that are still unknown after the application of
the standard dictionary. Square brackets stand for a context definition.
For more information about contexts, see section [section-contexts].

.. figure:: resources/img/fig3-13.png
   :alt: Dictionary graph that tags unknown words beginning with an
   uppercase letter as proper names[graph-NPr]
   :width: 10.50000cm

   Dictionary graph that tags unknown words beginning with an uppercase
   letter as proper names[graph-NPr]

Since dictionary graphs are applied using the engine of ``Locate``, they
have exactly the same properties than syntactic graphs. So, you can use
morphological filters (section [section-filters]) and/or the
morphological mode (section [section-morphological-mode]). For instance,
the graph shown on Figure [graph-CR] uses morphological filters to
recognize roman numerals. Note that it also uses contexts in order to
avoid recognizing uppercase letters in some contexts.

.. figure:: resources/img/fig3-14.png
   :alt: Dictionary graph of roman numerals[graph-CR]
   :height: 24.00000cm

   Dictionary graph of roman numerals[graph-CR]

By default, dictionary graphs are applied in MERGE mode. If you want to
apply them in REPLACE mode, you must suffix graph names with ``-r``.
This can be combined with the ``+`` and ``-`` priority marks:

``bagpipe-r.fst2  McAdam-r-.fst2  phtirius-r+.fst2``

Exporting produced entries as a morphological-mode dictionary
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Dictionary entries produced by dictionary graphs are looked up by the
``Locate`` program when it comes across lexical masks involving
dictionary lookup.

However, this functionality is restricted when the lexical mask is in
morphological mode (section [section-morphological-mode]). Dictionary
graphs cannot be declared as being morphological-mode dictionaries in
the usual way (section [morph-mode-dic]), because they are not ``.bin``
files. When in morphological mode, lexical masks involving dictionary
lookup do not trigger lookup of dictionary graphs. To compensate for
this, there are several solutions.

-  Consider invoking the dictionary graph from the part of the graph
   which is in morphological mode.

-  Unitex internally generates a dictionary of the forms recognized in
   the text by a dictionary graph. If the name of the dictionary graph
   contains the ``b`` switch (see Naming conventions below), Unitex
   includes this internal dictionary among morphological-mode
   dictionaries, so that it is looked up when the ``Locate`` program
   comes across lexical masks in morphological mode. But this solution
   works only for forms recognised in the text by the dictionary graph
   during initial application of dictionaries
   (section [section-applying-dictionaries]), and not for forms that
   appear in the text only as token parts.

If you add ``z`` instead of ``b``, then the dictionary internally
generated for the text is compressed immediately, and can be looked up
when other dictionary graphs are applied later.

Naming conventions
^^^^^^^^^^^^^^^^^^

The whole naming scheme for dictionary graphs is as follows:

``name(-XYZ)([-+]).fst2``

where:

-  ``X`` is in ``[rRmM]``: ``r`` means REPLACE mode; ``M`` means MERGE
   mode (default);

-  ``Y`` is in ``[bBzZ]``: option that rules the production of a
   morphological-mode dictionary (see above Exporting produced entries
   as a morphological-mode dictionary);

-  ``Z`` is in ``[aAlLsS]``: ``a`` means that the graph will be applied
   in “All matches” mode; ``l`` means “Longest matches” mode (default);
   ``s`` means “Shortest matches” mode.

Morphological dictionary-graphs
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In a dictionary graph, by default, each path must output a lexical entry
to be added in the text dictionaries. In a morphological
dictionary-graph, each path must output a sequence of one or more tags
enclosed in braces and conforming to the syntax of a DELAF line
(section [section-DELAF-entry-syntax]). The output of such graphs will
be used as special input for the construction of the text automaton. We
call them ‘morphological dictionary-graphs’ because their main utility
is to introduce new morphological analyses in the text automaton, using
the morphological mode (see section [section-morphological-mode]). This
functionality is helpful for agglutinative languages like Korean. To
allow the use of a graph as a morphological dictionary-graph, declare it
with a slash (/) as the first character of its output, as in Figure
[morphoA].

.. figure:: resources/img/fig3-14a.png
   :alt: Example of a morphological dictionary-graph[morphoA]
   :width: 14.00000cm

   Example of a morphological dictionary-graph[morphoA]

The rule is simple: any output of a dictionary graph that begins with a
slash will be added to the file ``tags.ind``, located in the text
directory. This file is used by the ``Txt2Fst2`` program in order to add
interpretations into the text automaton. The grammar of Figure [morphoA]
matches words made of the prefix ``un`` followed by an adjective. If we
apply it as a dictionary graph, we obtain new paths in the text
automaton, as shown on Figure [morphoB]. Note that when two tags
correspond to analyses within the same token, the link between them is
displayed with a dashed line.

.. figure:: resources/img/fig3-14b.png
   :alt: Path added by a morphological dictionary-graph[morphoB]
   :width: 15.00000cm

   Path added by a morphological dictionary-graph[morphoB]

Bibliography
------------

| Table [ref-dicos] gives some references for electronic dictionaries
  with simple and compound words. For more details, see the references
  page on the Unitex website:
| http://www-igm.univ-mlv.fr/~unitex

+----------------+------------------------------------------------------------------------------------------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------+
| **Language**   | **Simple words**                                                                                                                         | **Compound words**                                                                                                                       |
+================+==========================================================================================================================================+==========================================================================================================================================+
| English        | :raw-latex:`\cite{klarsfeld}`, :raw-latex:`\cite{monceaux-1995}`                                                                         | :raw-latex:`\cite{delac-anglais}`, :raw-latex:`\cite{these-Savary}`                                                                      |
+----------------+------------------------------------------------------------------------------------------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------+
| French         | :raw-latex:`\cite{formes-ambigues}`, :raw-latex:`\cite{dicos-francais}`, :raw-latex:`\cite{jacques-1995}`                                | :raw-latex:`\cite{dicos-francais}`, :raw-latex:`\cite{Gross96}`, :raw-latex:`\cite{max-1993}`, :raw-latex:`\cite{syntaxe-de-ladverbe}`   |
+----------------+------------------------------------------------------------------------------------------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------+
| Modern Greek   | :raw-latex:`\cite{modern-greek}`, :raw-latex:`\cite{matthieu-anastasia}`, :raw-latex:`\cite{these-tita}`                                 | :raw-latex:`\cite{tita-2002}`, :raw-latex:`\cite{anastasia-2002}`                                                                        |
+----------------+------------------------------------------------------------------------------------------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------+
| Italian        | :raw-latex:`\cite{delaf-italien}`, :raw-latex:`\cite{delaf-italien-book}`                                                                | :raw-latex:`\cite{composes-italien}`                                                                                                     |
+----------------+------------------------------------------------------------------------------------------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------+
| Spanish        | :raw-latex:`\cite{blanco-2000}`                                                                                                          | :raw-latex:`\cite{blanco-1997}`                                                                                                          |
+----------------+------------------------------------------------------------------------------------------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------+
| Portuguese     | :raw-latex:`\cite{eleuterio1995}`, :raw-latex:`\cite{ranchhod1996b}`, :raw-latex:`\cite{ranchhodd1998}`, :raw-latex:`\cite{muniz2005}`   | :raw-latex:`\cite{ranchhod1991}`, :raw-latex:`\cite{ranchhodd1998}`                                                                      |
+----------------+------------------------------------------------------------------------------------------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------+

Table: Some bibliographical references for electronic
dictionaries[ref-dicos]

.. [1]
   The point represents here the concatenation operation.

.. [2]
   Morphological dictionary-graphs are an exception (section
   [section-morphological-dictionary-graphs]) .

.. |image| image:: resources/img/fig3-flexion_secher.png
   :width: 5.00000cm
.. |image| image:: resources/img/fig3-flexion_tranquil.png
   :width: 5.00000cm
.. |image| image:: resources/img/fig3-flexion_sprechen.png
   :width: 5.00000cm
.. |image| image:: resources/img/fig3-flexion_aussprechen2.png
   :width: 5.00000cm
