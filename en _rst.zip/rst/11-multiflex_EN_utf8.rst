Compound word inflection
========================

MULTIFLEX is a multi-lingual Unicode-compatible platform for automatic
inflection of *multi-word units* (MWUs), also known as *compound words*.
It is meant in particular for the creation of morphological dictionaries
of MWUs. It implements a unification-based formalism
(:raw-latex:`\cite{Savary05}`) for the description of inflectional
behavior of MWUs which supposes the existence of a module for the
inflectional morphology of simple words.

In this chapter, we present the notion of multi-word unit and we
describe the method to inflect them with MULTIFLEX.

This chapter is derived from the MULTIFLEX manual, written by Agata
Savary, the author of MULTIFLEX.

Multi-Word Units
----------------

Multi-word units (MWUs) encompass a bunch of hard-to-define and
controversial linguistic objects (cf.
:raw-latex:`\cite{HabertJacquemin93}`, :raw-latex:`\cite{Corbin92}`).
Their numerous linguistic and pragmatic definitions
(:raw-latex:`\cite{Benven74}`, :raw-latex:`\cite{Downing77}`,
:raw-latex:`\cite{Levi78}`, :raw-latex:`\cite{Bauer83}`,
:raw-latex:`\cite{Gross90}`, :raw-latex:`\cite{Anscombre90}`,
:raw-latex:`\cite{max-1993}`, :raw-latex:`\cite{Gross96}`,
:raw-latex:`\cite{Cadiot92}`) invoke three major points:

-  they are composed of two or more words

-  they show some degree of morphological, distributional or semantic
   non-compositionality

-  they have unique and constant references

However, the basic notions (a word, a reference, the
non-compositionality) and measures (degree of non-compositionality) used
in those definitions are themselves controversial.

Pragmatically, we consider a MWU as a contiguous sequence of *graphical
units* which, for some application-dependent reasons, has to be listed,
described (morphologically, syntactically, semantically, etc.) and
processed as a unit.

Formal Description of the Inflectional Behavior of Multi-word Units
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The main issue in MULTIFLEX is the inflectional morphology of MWUs. This
phenomenon has been linguistically analyzed for English, Polish and
French in :raw-latex:`\cite{these-Savary}`.

Obviously, a reliable inflection processing of single words is a
necessary condition for the inflection processing of MWUs. However, this
condition is rarely a sufficient one. For example, in order to obtain
the plural form of

-  *battle cry*

-  *battle royal*

-  *battle of nerves*

in English, not only do we need to know how to generate the plural of
*battle, royal* and *cry*, but also to know how different inflected
forms of these constituents combine:

-  *battle cr*

-  *battle royal*, or *battle royal*,

-  *battle of nerves*

but not

-  *battle cr*

-  *battle royal*

-  *battle of nerve*

Formally, a fully explicit description of the inflectional paradigms of
MWUs requires an answer to the following questions:

-  What is the MWU’s morphological class (noun, adjective, etc.) and
   thus what inflection categories (number, gender, case, etc.) are
   relevant to it? :raw-latex:`\cite{PrzepWol03}` argue for a
   morphosyntactically motivated definition of morphological classes: a
   morphological class should fully determine the inflection categories
   the word inflects for as well as those that are lexically fixed for
   the word, e.g. in Polish, a noun has a gender and inflects for number
   and case.

-  What are the exceptions to the inflection categories determined
   above? E.g. in Polish

   -  | *wybory powszechne*
      | (*general election*)

   is a compound noun but it doesn’t have a singular form (although its
   head word *wybory* does).

-  What are the inflectional characteristics (base form, morphological
   class, inflection paradigm, etc.) of the single constituents of the
   MWU? E.g. in French, *porte* (*door*) is an uninflected verb in

   -  | *porte-avion*
      | (*aircraft carrier*)

   while it is an inflected noun in

   -  | *porte-fenêtre*
      | (*French window*)

   which takes an *s* in plural

   -  *porte-fenêtre*

-  How should we combine the inflected forms of the single constituents
   in order to generate the inflected forms of the whole compound? E.g.
   to inflect *battle of nerves* and *battle cry* in number we need to
   inflect the first and the last constituent, respectively.

Lexicalized vs. Grammar-Based Approach to Morphological Description
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

A previous study (:raw-latex:`\cite{these-Savary}`) has confirmed the
status of MWUs as units on the frontier between morphology and syntax.
Their compound structure suggests productivity which can hardly be
processed without a grammar-based approach. However some of their
morphological, syntactic and semantic properties exclude their
processing merely in terms of the properties of their constituents. For
example, in both examples below:

-  *chief justice*

-  *lord justice*

there are few automatically accessible hints indicating that the former
one is morphologically a standard English *Noun Noun* phrase taking an
*s* at its last constituent in plural, while the plural of the latter
has three variants:

-  *chief justice*

-  *lord justice, lord justice, lord justice*

Thus, at least one of the above examples has to be considered as
lexicalized in order for the automatic morphological processing to be
reliable.

MULTIFLEX implements a unification-based formalism for the description
of the inflectional behavior of MWUs presented in
:raw-latex:`\cite{Savary05}`. Its features are described in
section [section:formalism]. This formalism requires the description to
be *fully* lexicalized: each MWU listed in a dictionary obtains a code
(e.g. *NC\_NN, NC\_NN2*, etc.) representing its inflectional paradigm,
for instance, in the DELA-like format:

.. math::

   \begin{array}[c]{l}
     $aircraft carrier(carrier.N1:s),\textbf{NC\_NN}$ \\
     $chief justice(justice.N1:s),\textbf{NC\_NN}$ \\
     $lord(lord.N1:s) justice(justice.N1:s),\textbf{NC\_NN2}$ \\
     \dots
   \end{array}

However, only a few codes, which can be seen as a phrase grammar of the
language, represent the big majority of all MWUs. Thus, the
lexicalization of the description mainly consists of pointing out the
MWUs which respect or don’t respect the “grammar”.

Formalism for the Computational Morphology of MWUs
--------------------------------------------------

In :raw-latex:`\cite{Savary05}` was proposed a formalism for describing
the morphological paradigms of MWUs. It has been based on studies of
English, Polish and French, and further tested for Serbian
:raw-latex:`\cite{Krstevetal06}` and Greek :raw-latex:`\cite{Foufi13}`.
It consists of a language-independent kernel which is to be completed by
a set of morphological elements characteristic for the given language.
In this section we give an in-depth description of this formalism.

Morphological Features of the Language
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

When processing MWUs of a given language we have to provide some general
data about that language. These data are included in two textual files.

The ``Morphology.txt`` file gives the morphological classes (noun,
adjective,…), categories (number, gender, case,…) and values (masculine,
feminine, singular, nominative,…). Consider the following example:

.. math::

   \begin{array}[c]{ll}
   $Polish$ \\
   $$<$CATEGORIES$>$$ \\
   $Nb: sing, pl$ \\
   $Case: Nom, Gen, Dat, Acc, Inst, Loc, Voc$ \\
   $Gen: masc\_pers, masc\_anim, masc\_inanim, fem, neu$ \\
   $$<$CLASSES$>$)$ \\
   $noun: (Nb,$<$var$>$),(Case,$<$var$>$),(Gen,$<$fixed$>$)$ \\
   $adj:(Nb,$<$var$>$),(Case,$<$var$>$),(Gen,$<$var$>$)$ \\
   $adv:$
   \end{array}

The above file says that, for Polish, three inflection categories are
considered: the number (*Nb*), the case (*Case*) and the gender (*Gen*).
Each category is given an exhaustive list of its possible values
(singular and plural for number, etc.). Further, each morphological
class is described with respect to the categories it inflects for, and
those that are fixed for it. For example, a noun inflects for number and
case, and has a (fixed) gender. The presence of such a file is necessary
if we wish to express the fact that a certain word inflects for number,
gender or case, without having to explicitly enumerate each time which
inflectional values (singular, plural, masculine, etc.) it can take.

Similarly, for French the ``Morphology.txt`` file may be as follows:

.. math::

   \begin{array}[c]{l}
   $French$ \\
   $$<$CATEGORIES$>$$ \\
   $Nb: s, p$ \\
   $Gen: m, f$ \\
   $$<$CLASSES$>$$\\
   $noun: (Nb,$<$var$>$),(Gen,$<$var$>$)$ \\
   $adj:(Nb,$<$var$>$),(Gen,$<$var$>$)$ \\
   $adv:$
   \end{array}

However, in the existing systems for computational morphology, such a
description of classes, categories and values is not always present. For
example, according to the DELA conventions
(:raw-latex:`\cite{dicos-francais}`) the morphological values of each
simple word are plain sequences of characters (e.g. *ms* for masculine
singular) without any explicit mention of their corresponding
categories. In order for the program to be compatible with such systems,
we use a list (contained in a file called ``Equivalences.txt``) that
describes which foreign inflectional feature corresponds to which
category-value pair in our description. For example, the following
lists:

.. math::

   \begin{array}[c]{ll}
   Polish                        &French\\
   s: Nb=sing                    &s: Nb=s  \\
   p: Nb=pl                      &p: Nb=p \\
   M: Case=Nom                   &f: Gen=f  \\
   D: Case=Gen                   &m: Gen=m    \\
   C: Case=Dat  &\\
   B: Case=Acc  &\\
   I: Case=Inst  &\\
   L: Case=Loc  &\\
   V: Case=Voc  &\\
   o: Gen=masc\_pers  &\\
   z: Gen=masc\_anim  &\\
   r: Gen=masc\_inanim  &\\
   f: Gen=fem  &\\
   n: Gen=neu &
   \end{array}

describe the equivalences between the previous ``Morphology.txt`` file
for Polish and French, respectively, and the single-character features
that might be used in DELA dictionaries for those languages under
Unitex.

Decomposition of a MWU into Units
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The notion of an elementary graphical unit is controversial and varies
across languages and NLP systems. For instance in Unitex an alphabet,
i.e. a set of characters, is first defined for each language. Each non
alphabet character is called a separator. A graphical unit is then
either a single separator (usually a punctuation mark, a digit, etc.) or
a contiguous sequence of alphabet characters (e.g. *aujourd’hui* in
French consists, according to this definition, of 3 units). In other
systems a graphical unit may contain a punctuation mark (e.g.
*c’est-à-dire*), or a limit between two graphical units may occur within
a sequence of alphabet characters (*widział\ :math:`\mid`\ bym*, cf
:raw-latex:`\cite{PrzepWol03}`).

This variety of possible definitions of a graphical unit obviously has
an impact on the definition of a multi-word unit. However, we wish our
formalism for MWUs to be adaptable to different morphological systems
for “simple words”. Thus, the definition of a graphical unit is a
parameter to our system: each time MULTIFLEX is used with an external
module for single units, this module has to decide how a sequence of
characters is to be divided into units.

In our formalism, units are referred to by numerical variables *$1, $2,
$3*, etc. For example with Unitex, a sequence like

-  *Athens ’04*

consists of five constituents referred to in MULTIFLEX as:

.. math::

   \begin{array}[c]{l}
   $\$1 = \emph{Athens}$ \\
   $\$2 = $<$space$>$$ \\
   $\$3 = \emph{'}$ \\
   $\$4 = \emph{0}$ \\
   $\$5 = \emph{4}$ \\
   \end{array}

Each simple unit subject to inflection within a MWU has to be
morphologically identified. The identification means providing
sufficient data so that any inflected form of the same item may be
generated on demand. For instance in:

-  *mémoire vive*

we need to know that *vive* is the feminine singular form of a lemma,
and we have to be able to generate the feminine plural form of the same
lemma, *vives*. We suppose that the external module for single units
working with MULTIFLEX is responsible for such identification and
generation of inflected forms of single units.

In Unitex, the generation of forms is strongly inspired by the DELA
system (:raw-latex:`\cite{dicos-francais}`). In order to be able to
generate one or more inflected forms of a word we have to know:

-  its lemma

-  its inflection paradigm (called inflection code)

-  the inflection features of forms to be generated

Thus, within the Unitex/MULTIFLEX interface the description of a single
unit is done as follows:

-  *vive(vif.A54:fs)*

where *A54* is the inflection code of *vif* and *fs* is the DELA-style
description using morphological features appearing in
``Equivalences.txt`` file (cf section [subsec:langfeat]). Knowing that
*vive* is a feminine singular form of *vif* we may demand the generation
of its plural without having to explicitly indicate the plural of which
gender we are interested in: since we only wish to change the number,
the gender remains as in the original word *vive*, i.e. feminine.

Inflection paradigm of a MWU
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The morphological description of MWUs in our formalism is inspired by
the DELA system in the sense that:

-  each MWU is attributed an inflection code

-  a MWU’s inflection code explicitly describes each inflected form of a
   MWU in terms of actions to be performed on the lemma, and
   inflectional features to be attached to each form

In the Unitex-interfaced version, MULTIFLEX uses inflection codes
represented as Unitex graphs compiled into the ``.fst2`` format. For
example, Figure [fig:BattleRoyal] contains the inflection graph for
*battle royal*.

.. figure:: resources/img/BattleRoyal.png
   :alt: Inflection graph for *battle royal*\ 
   :width: 10.00000cm

   Inflection graph for *battle royal*\ 

According to the Unitex convention, three constituents are present in
*battle royal*: *battle* referred to as *$1*, a space referred to as
*$2*, and *royal* referred to as *$3*. If a variable appears alone in a
box the constituent has to be the same as in the lemma of the MWU. For
instance, :math:`<`\ $3\ :math:`>` in the uppermost path means that the
unit *royal* is to be recopied as such. If the variable is accompanied
by a set of category-feature equations, the constituent has to be
inflected to the required form. E.g. :math:`<`\ $3:Nb=p\ :math:`>` means
that the plural form of *royal* is needed.

In order to generate all inflected forms of the MWU we have to explore
all the paths existing in the graph. Each path starts at the leftmost
right arrow and ends at the final encircled box. Each time we come to a
node we perform the action contained in the box (a recopy or an
inflection of a constituent) and we accumulate the morphological
features contained under the box. The total of the accumulated node
outputs should result in the complete morphological description of the
inflected form.

For example in the graph on Figure [fig:BattleRoyal] if we follow the
intermediate path shown on Figure [fig:BattleRoyalonepath]:

.. figure:: resources/img/BattleRoyalonepath.png
   :alt: One path of the inflection graph for *battle royal*\ 
   :width: 10.00000cm

   One path of the inflection graph for *battle royal*\ 

we recopy *battle* (*$1*) and the space (*$2*), and we put *royal* into
plural, which yields the plural form *battle royals* of the whole MWU.
As the graph on Figure [fig:BattleRoyal] contains three different paths
the whole set of inflected forms generated for *battle royal* would be:

.. math::

   \begin{array}[l]{l}
   \emph{battle royal $<$Nb=s$>$} \\
   \emph{battle royals $<$Nb=p$>$} \\
   \emph{battles royal $<$Nb=p$>$}
   \end{array}

 After rewriting these forms into the Unitex DELACF format we obtain the
following entries:

.. math::

   \begin{array}[l]{l}
   \emph{battle royal,battle royal.N:s} \\
   \emph{battle royals,battle royal.N:p} \\
   \emph{battles royal,battle royal.N:p}
   \end{array}

Note that this description is independent of the way we generate
inflected forms of single words because we suppose that this problem is
handled by an existing external morphological system for single words.
In the Unitex-interfaced version of MULTIFLEX, we would generate the
plural of *royal* due to the fact that its lemma is known as having the
inflection code *N1* represented on Figure [fig:N1].

.. figure:: resources/img/N1'EN.png
   :alt: Inflection graph *N1* for simple words inflecting like
   *royal*\ 
   :width: 2.80000cm

   Inflection graph *N1* for simple words inflecting like *royal*\ 

In an inflection paradigm of a MWU, each constituent is accompanied only
by those morphological categories which it should inflect for. The
categories that remain unchanged don’t have to be mentioned. For
instance, in *bateau-mouche* in French (a Paris-style river-boat), both
noun constituents have their gender set but they inflect in number:
*bateau-mouche*. That’s why on Figure [fig:BateauMouche1] containing the
inflection graph for this MWU, the corresponding boxes contain value
assignments for number only. Note that both constituents may or may not
agree in gender, here *bateau* is masculine while *mouche* is feminine.

.. figure:: resources/img/BateauMouche1.png
   :alt: Inflection graph for MWUs inflection like *bateau-mouche*\ 
   :width: 10.00000cm

   Inflection graph for MWUs inflection like *bateau-mouche*\ 

Unification Variables
^^^^^^^^^^^^^^^^^^^^^

An important feature of our formalism are *unification variables*. They
are invoked by a dollar sign followed by an identifier which may contain
any number of characters, e.g. *$g1*, *$num\_10*, *$c*, etc. For
example, Figure [fig:BateauMouche2] shows a graph roughly
equivalent [1]_ to the one on Figure [fig:BateauMouche1] in the sense
that it allows to generate the same inflected forms for the same MWUs.
However, this time, a single path represents both the singular and the
plural form. This is possible due to the unification variable *$n* which
is instantiated in turn to all values of the domain of its category
(*Nb*), here *$n=s* then *$n=p*. When a unification variable occurs in a
formula such as *Nb=$n*, with a single equal sign (=), the system
reviews all the values declared in the configuration files for the
category (cf. Section [subsec:langfeat]). For each value, it makes a new
assignment of the variable. The assignment is unique for all occurrences
of the variable on a path: if we instantiate the singular value for the
first constituent, the same value is set for the third one, as well as
for the whole MWU. Similarly, if we instantiate *$n* to *p* while
processing the first node, it remains *p* until the end of the path.

.. figure:: resources/img/BateauMouche2.png
   :alt: Inflection graph for *bateau-mouche* with a unification
   variable
   :width: 10.00000cm

   Inflection graph for *bateau-mouche* with a unification variable

The inflection graph on Figure [fig:BateauMouche2] applies to most kinds
of French compounds of types *Noun Noun* and *Noun Adjective*
(*bateau-mouche, ange gardien, circuit séquentiel*, etc.) which are of
masculine gender. That is because the output of the final node contains
*Gen=m*. For all compounds of the same types but of feminine gender,
e.g. *main courante, moissoneuse-batteuse*, etc., a new graph has to be
created which is identical to Figure [fig:BateauMouche2] up to the final
output containing *:math:`<`\ Gen=f;Nb=$n\ :math:`>`*. That is not very
intuitive since *circuit séquentiel* and *main courante* inflect in the
same way, in the sense that in both cases we need to put the first and
the last constituent in the plural in order to obtain the plural form of
the whole MWU.

That’s why another type of instantiation for unification variables has
been introduced. It is invoked by a double equal sign (*==*), as opposed
to the single equal sign *=* as for *$n* on Figure [fig:BateauMouche2].
If a unification variable is assigned to a category by this symbol, then
the variable is assigned once: it inherits the value of this category
from the corresponding constituent, as it appears in the lemma of the
MWU. For instance, Figure [fig:BateauMouche3] contains a graph
describing the inflected forms for both masculine and feminine French
compounds of types *Noun Noun* and *Noun Adjective*. Its first box
contains the double-= assignment of the gender to variable *$g*, which
means that this variable has its value set to the gender value of the
first constituent. For *bateau-mouche* it is set to masculine because
*bateau* is masculine, while for *main courante* it is set to feminine.

.. figure:: resources/img/BateauMouche3.png
   :alt: Inflection graph for *bateau-mouche* with two types of
   instantiation
   :width: 11.00000cm

   Inflection graph for *bateau-mouche* with two types of instantiation

When a double-= assignment and a single-= assignment occur on the same
path for the same variable, the double-= assignment prevails: the
variable is instantiated once. For example, on
Figure [fig:BateauMouche3], the final output contains *Gen=$g* but *$g*
takes the value determined by the first constituent only.

Unification variables are particularly useful in highly inflected
languages. For example, in Polish most nouns inflect for number (2
values) and case (7 values), which implies at least 14 different forms
(if variants and syncretic forms are distinguished). This score is even
higher for adjectives which inflect for number, case and gender (3 till
9 values, according to different approaches). If no unification
mechanism were available each of these numerous forms would have to be
described by a separate path in the graph. The use of unification
variables allows to dramatically reduce the size of the graph (to one
path only in most cases).

For example, Figure [fig:PranieMozgu] shows the graph for Polish
compounds that inflect like *pranie mózgu* (*brainwashing*) or
*powożenie koniem* (*horse coaching*). Their third constituent has its
case fixed (most often to genitive or instrumental). Their first and
third constituent inflect in number independently from each other
(*pranie mózg*, *prani mózgu*, *prani mózg*, etc.). That’s why either of
them has a different unification variable for number inflection (*$n1*
and *$n2*). The three variables :math:`\$n1`, :math:`\$n2`, and
:math:`\$c` may be instantiated to any value from their respective
domains (*{sing,pl}, {sing,pl}*, and *{Nom,Gen,Dat,Acc,Inst,Loc,Voc}*;
cf ``Morphology.txt`` file in section [subsec:langfeat]). The whole MWU
inherits its gender, number and case from its first constituent. Its
gender is fixed (*Gen==$g*) while its number and case are instantiated
to any of the 14 possible combinations. The single path in this graph
would have to be replaced by 28 different ones if the use of unification
variables were not allowed.

.. figure:: resources/img/PranieMozgu.png
   :alt: Inflection graph for *pranie mózgu*\ 
   :width: 10.00000cm

   Inflection graph for *pranie mózgu*\ 

Orthographic and Other Variants
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Our formalism allows for any constituent to be omitted or moved within
different inflected forms if there is a need for that. It also enables
the insertion of extra graphical units which do not appear in the base
form of the MWU. This allows to extend an inflection paradigm to a more
general variation description, e.g. orthographic or, partly, syntactic
variation (see :raw-latex:`\cite{Jacquemin01}` for an extensive study on
term variation). For example, in English, *student union* appears in
corpus also as *student union*, and *student union*, in singular or
plural in each case. Our formalism allows to include both types of
variation in one description (cf. Figure [fig:StudentUnion]).

.. figure:: resources/img/StudentUnion.png
   :alt: Inflection graph for *student union*\ 
   :width: 10.00000cm

   Inflection graph for *student union*\ 

Figure [fig:BirthDate] shows an example in which, additionally to the
insertion of a new constituent, the order of constituents may be
reverted. The upper path allows to generate e.g. *birth date* and *birth
dates* while the lower one represents the syntactic variants of the
previous forms: *date of birth* and *dates of birth*.

.. figure:: resources/img/BirthDate.png
   :alt: Inflection graph for *birth date*\ 
   :width: 10.00000cm

   Inflection graph for *birth date*\ 

Interface with the Morphological System for Simple Words
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

MULTIFLEX is an implementation of the formalism for the inflectional
morphology of MWUs presented above. It supposes the existence of a
morphological system for single words which satisfies the following
interface constraints:

-  For a given sequence of characters it returns its segmentation into
   indivisible graphical units (tokens) (cf section [subsec:decomp]).
   For instance, in case of Unitex’ definition of a token, sequence
   *Athens ’04* is to be divided into 5 tokens:

   .. math::

      \begin{array}[l]{l}
      \emph{``Athens '04'' $\rightarrow$ (``Athens'','' ``,''''',''0'',''4'')}
      \end{array}

-  For a given simple inflected form it returns all its possible
   morphological identifications. A morphological identification has to
   allow the generation of any other inflected form of the same lemma on
   demand by the same morphological module. For instance, in case of
   Unitex, the form *porte* yields 7 morphological identifications (6 of
   which are factorized with respect to their inflection code):

   .. math::

      \begin{array}[l]{l}
      \emph{porte $\rightarrow$ ((porte,porte.N21:s),(porte,porter.V3:P1s:P3s:S1s:S3s:Y2s))}
      \end{array}

   In case of ambiguïty, as above, the proper identification has to be
   done, for the time being, by the user during the edition of the MWU
   lemma to be inflected (in future, this task will be partly
   automated). For instance, in case of *porte-fenêtre* the first
   constituent has to be identified by the user as a noun rather than a
   verb.

-  For a given morphological identification and a set of inflectional
   values it returns all corresponding inflected forms. For instance, in
   Polish, if the instrumental forms of the word *rka* are to be
   produced, three forms should be returned: *rk* (singular
   instrumental), *rkami* and *rkoma* (two variants of the plural
   instrumental).

   .. math::

      \begin{array}[l]{lll}
      \emph{(r\k{e}ka,$<$Case=Inst$>$)}&  \rightarrow    & \emph{((r\k{e}k\k{a},<Nb=sing;Gen=fem;Case=Inst>)}, \\
                                          &              & \emph{(r\k{e}kami,<Nb=pl;Gen=fem;Case=Inst>)}, \\
                                          &              & \emph{(r\k{e}koma,<Nb=pl;Gen=fem;Case=Inst>))}
      \end{array}

Such definition of an interface between the morphological system for
simple words and the one for MWUs allows a better modularity and
independence of one another. The latter doesn’t need to know how
inflected forms of simple words are described, analyzed and generated.
It only requires a set of correct inflected forms of a MWU’s
constituents. Conversely, the former system knows nothing about how the
latter one combines the provided forms to produce multi-word sequences.

Integration in Unitex
---------------------

One of the major design principles of MULTIFLEX is to be as independent
as possible of the morphological system for simple words. However, the
existence of such a system is inevitable because MWUs consist of simple
words which we need to be able to inflect in order to inflect a MWU as a
whole.

In its present version, MULTIFLEX relies on the Unitex simple word
inflection system:

-  MULTIFLEX uses the same character encoding standards as Unitex, i.e.
   Unicode 3.0.

-  MULTIFLEX uses the Unitex’ graph editor for the representation of
   inflectional paradigms of MWUs.

-  MULTIFLEX admits similar principles of the morphological description
   as those admitted in the DELA system implemented in Unitex. Thus, an
   inflection paradigm is a set of actions to be performed on the lemma
   in order to generate its inflected forms, and of corresponding
   inflection features to be attached to each generated form.

-  MULTIFLEX allows to extend the Unitex dictionary treatment to the
   inflection of a DELAC (DELA electronic dictionary of compounds) into
   a DELACF (DELA electronic dictionary of compounds’ inflected forms).
   The format of the generated DELACF is compatible with Unitex, while
   the format of the DELAC is novel but inspired from the one of the
   DELAS (DELA electronic dictionary of simple words).

The following sections present, for several languages, complete examples
of a DELAC into DELACF inflection within the MULTIFLEX/Unitex interface.

Complete Example in English
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Let us assume that the description of morphological features of English
is given by the following ``Morphology.txt`` file:

.. math::

   \begin{array}[l]{l}
   $English$ \\
   $<CATEGORIES>$ \\
   $Nb:s,p$ \\
   $<CLASSES>$ \\
   $noun:(Nb,<var>)$ \\
   $adj:$
   \end{array}

and that the equivalences between these features and their corresponding
codes in DELA dictionaries are given by the following
``Equivalences.txt`` file:

.. math::

   \begin{array}[l]{l}
   $English$ \\
   $s : Nb=s$ \\
   $p : Nb=p$ \\
   \end{array}

Consider the following sample English DELAC file:

::

    angle(angle.N1:s) of reflection,NC_NXXXX
    Adam's apple(apple.N1:s),NC_XXXXN
    air brake(brake.N1:s),NC_XXN
    birth date(date.N1:s),NC_NN_NofN
    criminal police,NC_XXXinv
    cross-roads,NC_XXNs
    head(head.N1:s) of government(government.N1:s),NC_NofNs
    notary(notary.N3:s) public(public.N1:s),NC_NsNs
    rolling stone(stone.N1:s),NC_XXN
    student(student.N1:s) union(union.N1:s),NC_Ns'N

The corresponding inflection graphs *N1* and *N3* for simple words are
represented on figures [fig:N1’EN] and  [fig:N3’EN] while those for
compounds are shown on figures [fig:NC’NXXXX’EN]
through [fig:NC’Ns’N’EN].

The DELACF dictionary resulting from the inflection, via MULTIFLEX, of
the above DELAC is as follows:

::

    angle of reflection,angle of reflection.NC_NXXXX:s
    angles of reflection,angle of reflection.NC_NXXXX:p
    Adam's apple,Adam's apple.NC_XXXXN:s
    Adam's apples,Adam's apple.NC_XXXXN:p
    air brake,air brake.NC_XXN:s
    air brakes,air brake.NC_XXN:p
    date of birth,birth date.NC_NN_NofN:s
    dates of birth,birth date.NC_NN_NofN:p
    birth date,birth date.NC_NN_NofN:s
    birth dates,birth date.NC_NN_NofN:p
    criminal police,criminal police.NC_XXXinv:p
    cross-roads,cross-roads.NC_XXNs:s
    cross-roads,cross-roads.NC_XXNs:p
    heads of government,head of government.NC_NofNs:p
    heads of governments,head of government.NC_NofNs:p
    head of government,head of government.NC_NofNs:s
    notaries public,notary public.NC_NsNs:p
    notary public,notary public.NC_NsNs:s
    notary publics,notary public.NC_NsNs:p
    rolling stone,rolling stone.NC_XXN:s
    rolling stones,rolling stone.NC_XXN:p
    students' union,student union.NC_Ns'N:s
    students' unions,student union.NC_Ns'N:p
    students union,student union.NC_Ns'N:s
    students unions,student union.NC_Ns'N:p
    student union,student union.NC_Ns'N:s
    student unions,student union.NC_Ns'N:p

[c]0.45 |Inflection graph *N3* for English simple words|

[c]0.5 |Inflection graph *N3* for English simple words|

.. figure:: resources/img/NC'NXXXX'EN.png
   :alt: Inflection graph *NC\_NXXXX* for English MWUs
   :width: 10.00000cm

   Inflection graph *NC\_NXXXX* for English MWUs

.. figure:: resources/img/NC'XXXXN'EN.png
   :alt: Inflection graph *NC\_XXXXN* for English MWUs
   :width: 9.70000cm

   Inflection graph *NC\_XXXXN* for English MWUs

.. figure:: resources/img/NC'XXN'EN.png
   :alt: Inflection graph *NC\_XXN* for English MWUs
   :width: 7.80000cm

   Inflection graph *NC\_XXN* for English MWUs

.. figure:: resources/img/NC'NN'NofN'EN.png
   :alt: Inflection graph *NC\_NN\_NofN* for English MWUs
   :width: 10.00000cm

   Inflection graph *NC\_NN\_NofN* for English MWUs

.. figure:: resources/img/NC'XXXinv'EN.png
   :alt: Inflection graph *NC\_XXXinv* for English MWUs
   :width: 7.00000cm

   Inflection graph *NC\_XXXinv* for English MWUs

.. figure:: resources/img/NC'XXNs'EN.png
   :alt: Inflection graph *NC\_XXNs* for English MWUs
   :width: 7.00000cm

   Inflection graph *NC\_XXNs* for English MWUs

.. figure:: resources/img/NC'NofNs'EN.png
   :alt: Inflection graph *NC\_NofNs* for English MWUs
   :width: 10.40000cm

   Inflection graph *NC\_NofNs* for English MWUs

.. figure:: resources/img/NC'NsNs'EN.png
   :alt: Inflection graph *NC\_NsNs* for English MWUs
   :width: 10.40000cm

   Inflection graph *NC\_NsNs* for English MWUs

.. figure:: resources/img/NC'Ns'N'EN.png
   :alt: Inflection graph *NC\_Ns’N* for English MWUs
   :width: 9.80000cm

   Inflection graph *NC\_Ns’N* for English MWUs

Complete Example in French
~~~~~~~~~~~~~~~~~~~~~~~~~~

Let us assume that the description of morphological features of French
is given by the following ``Morphology.txt`` file:

.. math::

   \begin{array}[l]{l}
   $French$ \\
   $<CATEGORIES>$ \\
   $Nb : s, p$ \\
   $Gen : m, f$ \\
   $<CLASSES>$ \\
   $noun : (Nb,<var>),(Gen,<var>)$ \\
   $adj:(Nb,<var>),(Gen,<var>)$ \\
   $adv:$
   \end{array}

and that the equivalences between these features and their corresponding
codes in DELA dictionaries are given by the following
``Equivalences.txt`` file:

.. math::

   \begin{array}[l]{l}
   $French$ \\
   $s : Nb=s$ \\
   $p : Nb=p$ \\
   $m : Gen=m$ \\
   $f : Gen=f$
   \end{array}

Consider the following sample French DELAC file (the DELAS inflection
codes may vary from those present in UNITEX):

::

    avant-garde(garde.N21:fs),NC_XXN
    bateau(bateau.N3:ms)-mouche(mouche.N21:fs),NC_NN
    café(café.N1:ms) au lait,NC_NXXXX
    carte(carte.N21:fs) postale(postal.A8:fs),NC_NN$
    cousin(cousin.N8:ms) germain(germain.A8:ms),NC_NNmf
    franc(franc.A47:ms) maçon(maçon.N41:ms),NC_AN1
    mémoire(mémoire.N21:fs) vive(vif.A48:fs),NC_NN
    microscope(microscope.N1:ms) à effet tunnel,NC_NXXXXXX
    porte-serviette(serviette.N21:fs),NC_VNm

The corresponding inflection graphs for MWUs are shown on
figures [fig:NC’XXN’FR] through [fig:NC’VNm’FR].

The DELACF dictionary resulting from the inflection, via MULTIFLEX, of
the above DELAC is as follows:

::

    avant-garde,avant-garde.NC_XXN:fs
    avant-gardes,avant-garde.NC_XXN:fp
    bateau-mouche,bateau-mouche.NC_NN:ms
    bateaux-mouches,bateau-mouche.NC_NN:mp
    café au lait,café au lait.NC_NXXXX:ms
    cafés au lait,café au lait.NC_NXXXX:mp
    carte postale,carte postale.NC_NN:fs
    cartes postales,carte postale.NC_NN:fp
    cousin germain,cousin germain.NC_NNmf:ms
    cousins germains,cousin germain.NC_NNmf:mp
    cousine germaine,cousin germain.NC_NNmf:fs
    cousines germaines,cousin germain.NC_NNmf:fp
    franc-maçon,franc maçon.NC_AN1:ms
    franc-maçonne,franc maçon.NC_AN1:fs
    franc maçon,franc maçon.NC_AN1:ms
    franc maçonne,franc maçon.NC_AN1:fs
    francs-maçons,franc maçon.NC_AN1:mp
    francs-maçonnes,franc maçon.NC_AN1:fp
    francs maçons,franc maçon.NC_AN1:mp
    francs maçonnes,franc maçon.NC_AN1:fp
    mémoire vive,mémoire vive.NC_NN:fs
    mémoires vives,mémoire vive.NC_NN:fp
    microscope à effet tunnel,microscope à effet tunnel.NC_NXXXXXX:ms
    microscopes à effet tunnel,microscope à effet tunnel.NC_NXXXXXX:mp
    porte-serviette,porte-serviette.NC_VNm:ms
    porte-serviettes,porte-serviette.NC_VNm:ms
    porte-serviettes,porte-serviette.NC_VNm:mp 

.. figure:: resources/img/NC'XXN'FR.png
   :alt: Inflection graph *NC\_XXN* for French MWUs
   :width: 10.20000cm

   Inflection graph *NC\_XXN* for French MWUs

.. figure:: resources/img/NC'NN'FR.png
   :alt: Inflection graph *NC\_NN* for French MWUs
   :width: 10.80000cm

   Inflection graph *NC\_NN* for French MWUs

.. figure:: resources/img/NC'NXXXX'FR.png
   :alt: Inflection graph *NC\_NXXXX* for French MWUs
   :width: 12.00000cm

   Inflection graph *NC\_NXXXX* for French MWUs

.. figure:: resources/img/NC'NNmf'FR.png
   :alt: Inflection graph *NC\_NNmf* for French MWUs
   :width: 12.00000cm

   Inflection graph *NC\_NNmf* for French MWUs

.. figure:: resources/img/NC'AN1'FR.png
   :alt: Inflection graph *NC\_AN1* for French MWUs
   :width: 12.00000cm

   Inflection graph *NC\_AN1* for French MWUs

.. figure:: resources/img/NC'NXXXXXX'FR.png
   :alt: Inflection graph *NC\_NXXXXXX* for French MWUs
   :width: 12.20000cm

   Inflection graph *NC\_NXXXXXX* for French MWUs

.. figure:: resources/img/NC'VNm'FR.png
   :alt: Inflection graph *NC\_VNm* for French MWUs
   :width: 9.20000cm

   Inflection graph *NC\_VNm* for French MWUs

Complete Example in Serbian
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Let us assume that the description of morphological features of Serbian
is given by the following ``Morphology.txt`` file:

.. math::

   \begin{array}[l]{l}
   $Serbian$ \\
   $<CATEGORIES>$ \\
   $Nb:s,p,w$ \\
   $Case:1,2,3,4,5,6,7$ \\
   $Gen:m,f,n$ \\
   $Anim:v,q,g$ \\
   $Comp:a,b,c$ \\
   $Det:d,k,e$ \\
   $<CLASSES>$ \\
   $noun:(Nb,<var>),(Case,<var>),(Gen,<var>),(Anim,<fixed>)$ \\
   $adj:(Nb,<var>),(Case,<var>),(Gen,<var>),(Anim,<var>),(Comp,<var>),(Det,<var>)$ \\
   $adv:$
   \end{array}

The particuliarity of this morphological model is not only its reachness
but also the existence of *no-care* features like *Anim=g* or *Det=e*.
These features agree with all other features in the same category. They
are used only for some particular sublasses of nouns or adjectives and
are necessary for a better compactness of the inflection paradigms of
simple words which are already considerably huge, and would be even
larger if no *no-care* symbols were used.

Let us assume that the equivalences between the above features and their
corresponding codes in DELA dictionaries are given by the following
``Equivalences.txt`` file:

.. math::

   \begin{array}[l]{l}
   $Serbian$ \\
   $s:Nb=s$ \\
   $p:Nb=p$ \\
   $w:Nb=w$ \\
   $1:Case=1$ \\
   $2:Case=2$ \\
   $3:Case=3$ \\
   $4:Case=4$ \\
   $5:Case=5$ \\
   $6:Case=6$ \\
   $7:Case=7$ \\
   $m:Gen=m$ \\
   $f:Gen=f$ \\
   $n:Gen=n$ \\
   $v:Anim=v$ \\
   $q:Anim=q$ \\
   $g:Anim=g$ \\
   $a:Comp=a$ \\
   $b:Comp=b$ \\
   $c:Comp=c$ \\
   $d:Det=d$ \\
   $k:Det=k$ \\
   $e:Det=e$
   \end{array}

Consider the following sample Serbian DELAC file (the DELAS inflection
codes may vary from those present in Unitex):

::

    zxiro racyun(racyun.N1:ms1q),NC_2XN1+N+Comp
    avio-prevoznik(prevoznik.N10:ms1v),NC_2XN2+N+Comp
    predsednik(predsednik.N10:ms1v) drzxave(drzxava.N600:fs2q),NC_N2X1+N+Comp
    Ujedinxene(Ujedinxen.A1:aefp1g) nacije(nacija.N600:fp1q),NC_AXN3+N+Comp+NProp+Org
    Kosovo(Kosovo.N308:ns1q) i Metohija(Metohija.N623:fs1q),NC_N3XN+N+Comp+NProp+Top+Reg 
    istrazxni(istrazxni.A2:adms1g) sudija(sudija.N679:ms1v),NC_AXNF+N+Comp
    Mirosinka(Mirosinka.N1637:fs1v) Dinkicx(Dinkicx.N1028:ms1v),NC_ImePrezime+N+Comp+Hum+PersName
    gladan(gladan.A18:akms1g) kao vuk(vuk.N128:ms1v),AC_A3XN2/hungry as a wolf

The corresponding inflection graphs for MWUs are shown on
figures [fig:NC’2XN1’SRB] through [fig:AC’A3XN2’SRB].

The DELACF dictionary resulting from the inflection, via MULTIFLEX, of
the above DELAC is as follows:

::

    zxiro-racyun,zxiro racyun.NC_2XN1+N+Comp:s1qm
    zxiro-racyuna,zxiro racyun.NC_2XN1+N+Comp:s2qm
    zxiro-racyunu,zxiro racyun.NC_2XN1+N+Comp:s3qm
    zxiro-racyun,zxiro racyun.NC_2XN1+N+Comp:s4qm
    zxiro-racyune,zxiro racyun.NC_2XN1+N+Comp:s5qm
    zxiro-racyunom,zxiro racyun.NC_2XN1+N+Comp:s6qm
    zxiro-racyunu,zxiro racyun.NC_2XN1+N+Comp:s7qm
    zxiro-racyuni,zxiro racyun.NC_2XN1+N+Comp:p1qm
    zxiro-racyuna,zxiro racyun.NC_2XN1+N+Comp:p2qm
    zxiro-racyunima,zxiro racyun.NC_2XN1+N+Comp:p3qm
    zxiro-racyune,zxiro racyun.NC_2XN1+N+Comp:p4qm
    zxiro-racyuni,zxiro racyun.NC_2XN1+N+Comp:p5qm
    zxiro-racyunima,zxiro racyun.NC_2XN1+N+Comp:p6qm
    zxiro-racyunima,zxiro racyun.NC_2XN1+N+Comp:p7qm
    zxiro-racyuna,zxiro racyun.NC_2XN1+N+Comp:w2qm
    zxiro-racyuna,zxiro racyun.NC_2XN1+N+Comp:w4qm
    zxiro racyun,zxiro racyun.NC_2XN1+N+Comp:s1qm
    zxiro racyuna,zxiro racyun.NC_2XN1+N+Comp:s2qm
    zxiro racyunu,zxiro racyun.NC_2XN1+N+Comp:s3qm
    zxiro racyun,zxiro racyun.NC_2XN1+N+Comp:s4qm
    zxiro racyune,zxiro racyun.NC_2XN1+N+Comp:s5qm
    zxiro racyunom,zxiro racyun.NC_2XN1+N+Comp:s6qm
    zxiro racyunu,zxiro racyun.NC_2XN1+N+Comp:s7qm
    zxiro racyuni,zxiro racyun.NC_2XN1+N+Comp:p1qm
    zxiro racyuna,zxiro racyun.NC_2XN1+N+Comp:p2qm
    zxiro racyunima,zxiro racyun.NC_2XN1+N+Comp:p3qm
    zxiro racyune,zxiro racyun.NC_2XN1+N+Comp:p4qm
    zxiro racyuni,zxiro racyun.NC_2XN1+N+Comp:p5qm
    zxiro racyunima,zxiro racyun.NC_2XN1+N+Comp:p6qm
    zxiro racyunima,zxiro racyun.NC_2XN1+N+Comp:p7qm
    zxiro racyuna,zxiro racyun.NC_2XN1+N+Comp:w2qm
    zxiro racyuna,zxiro racyun.NC_2XN1+N+Comp:w4qm
    avio-prevoznik,avio-prevoznik.NC_2XN2+N+Comp:s1vm
    avio-prevoznika,avio-prevoznik.NC_2XN2+N+Comp:s2vm
    avio-prevozniku,avio-prevoznik.NC_2XN2+N+Comp:s3vm
    avio-prevoznika,avio-prevoznik.NC_2XN2+N+Comp:s4vm
    avio-prevoznicye,avio-prevoznik.NC_2XN2+N+Comp:s5vm
    avio-prevoznikom,avio-prevoznik.NC_2XN2+N+Comp:s6vm
    avio-prevozniku,avio-prevoznik.NC_2XN2+N+Comp:s7vm
    avio-prevoznici,avio-prevoznik.NC_2XN2+N+Comp:p1vm
    avio-prevoznika,avio-prevoznik.NC_2XN2+N+Comp:p2vm
    avio-prevoznicima,avio-prevoznik.NC_2XN2+N+Comp:p3vm
    avio-prevoznike,avio-prevoznik.NC_2XN2+N+Comp:p4vm
    avio-prevoznici,avio-prevoznik.NC_2XN2+N+Comp:p5vm
    avio-prevoznicima,avio-prevoznik.NC_2XN2+N+Comp:p6vm
    avio-prevoznicima,avio-prevoznik.NC_2XN2+N+Comp:p7vm
    avio-prevoznika,avio-prevoznik.NC_2XN2+N+Comp:w2vm
    avio-prevoznika,avio-prevoznik.NC_2XN2+N+Comp:w4vm
    avioprevoznik,avio-prevoznik.NC_2XN2+N+Comp:s1vm
    avioprevoznika,avio-prevoznik.NC_2XN2+N+Comp:s2vm
    avioprevozniku,avio-prevoznik.NC_2XN2+N+Comp:s3vm
    avioprevoznika,avio-prevoznik.NC_2XN2+N+Comp:s4vm
    avioprevoznicye,avio-prevoznik.NC_2XN2+N+Comp:s5vm
    avioprevoznikom,avio-prevoznik.NC_2XN2+N+Comp:s6vm
    avioprevozniku,avio-prevoznik.NC_2XN2+N+Comp:s7vm
    avioprevoznici,avio-prevoznik.NC_2XN2+N+Comp:p1vm
    avioprevoznika,avio-prevoznik.NC_2XN2+N+Comp:p2vm
    avioprevoznicima,avio-prevoznik.NC_2XN2+N+Comp:p3vm
    avioprevoznike,avio-prevoznik.NC_2XN2+N+Comp:p4vm
    avioprevoznici,avio-prevoznik.NC_2XN2+N+Comp:p5vm
    avioprevoznicima,avio-prevoznik.NC_2XN2+N+Comp:p6vm
    avioprevoznicima,avio-prevoznik.NC_2XN2+N+Comp:p7vm
    avioprevoznika,avio-prevoznik.NC_2XN2+N+Comp:w2vm
    avioprevoznika,avio-prevoznik.NC_2XN2+N+Comp:w4vm
    predsednik drzxave,predsednik drzxave.NC_N2X1+N+Comp:s1vm
    predsednika drzxave,predsednik drzxave.NC_N2X1+N+Comp:s2vm
    predsedniku drzxave,predsednik drzxave.NC_N2X1+N+Comp:s3vm
    predsednika drzxave,predsednik drzxave.NC_N2X1+N+Comp:s4vm
    predsednicye drzxave,predsednik drzxave.NC_N2X1+N+Comp:s5vm
    predsednikom drzxave,predsednik drzxave.NC_N2X1+N+Comp:s6vm
    predsedniku drzxave,predsednik drzxave.NC_N2X1+N+Comp:s7vm
    predsednici drzxave,predsednik drzxave.NC_N2X1+N+Comp:p1vm
    predsednici drzxava,predsednik drzxave.NC_N2X1+N+Comp:p1vm
    predsednika drzxave,predsednik drzxave.NC_N2X1+N+Comp:p2vm
    predsednika drzxava,predsednik drzxave.NC_N2X1+N+Comp:p2vm
    predsednicima drzxave,predsednik drzxave.NC_N2X1+N+Comp:p3vm
    predsednicima drzxava,predsednik drzxave.NC_N2X1+N+Comp:p3vm
    predsednike drzxave,predsednik drzxave.NC_N2X1+N+Comp:p4vm
    predsednike drzxava,predsednik drzxave.NC_N2X1+N+Comp:p4vm
    predsednici drzxave,predsednik drzxave.NC_N2X1+N+Comp:p5vm
    predsednici drzxava,predsednik drzxave.NC_N2X1+N+Comp:p5vm
    predsednicima drzxave,predsednik drzxave.NC_N2X1+N+Comp:p6vm
    predsednicima drzxava,predsednik drzxave.NC_N2X1+N+Comp:p6vm
    predsednicima drzxave,predsednik drzxave.NC_N2X1+N+Comp:p7vm
    predsednicima drzxava,predsednik drzxave.NC_N2X1+N+Comp:p7vm
    predsednika drzxave,predsednik drzxave.NC_N2X1+N+Comp:w2vm
    predsednika drzxava,predsednik drzxave.NC_N2X1+N+Comp:w2vm
    predsednika drzxave,predsednik drzxave.NC_N2X1+N+Comp:w4vm
    predsednika drzxava,predsednik drzxave.NC_N2X1+N+Comp:w4vm
    Ujedinxene nacije,Ujedinxene nacije.NC_AXN3+N+Comp+NProp+Org:fp1q
    Ujedinxenih nacija,Ujedinxene nacije.NC_AXN3+N+Comp+NProp+Org:fp2q
    Ujedinxenima nacijama,Ujedinxene nacije.NC_AXN3+N+Comp+NProp+Org:fp3q
    Ujedinxenim nacijama,Ujedinxene nacije.NC_AXN3+N+Comp+NProp+Org:fp3q
    Ujedinxene nacije,Ujedinxene nacije.NC_AXN3+N+Comp+NProp+Org:fp4q
    Ujedinxene nacije,Ujedinxene nacije.NC_AXN3+N+Comp+NProp+Org:fp5q
    Ujedinxenima nacijama,Ujedinxene nacije.NC_AXN3+N+Comp+NProp+Org:fp6q
    Ujedinxenim nacijama,Ujedinxene nacije.NC_AXN3+N+Comp+NProp+Org:fp6q
    Ujedinxenima nacijama,Ujedinxene nacije.NC_AXN3+N+Comp+NProp+Org:fp7q
    Ujedinxenim nacijama,Ujedinxene nacije.NC_AXN3+N+Comp+NProp+Org:fp7q
    Kosovo i Metohija,Kosovo i Metohija.NC_N3XN+N+Comp+NProp+Top+Reg:ns1q
    Kosova i Metohije,Kosovo i Metohija.NC_N3XN+N+Comp+NProp+Top+Reg:ns2q
    Kosovu i Metohiji,Kosovo i Metohija.NC_N3XN+N+Comp+NProp+Top+Reg:ns3q
    Kosovo i Metohiju,Kosovo i Metohija.NC_N3XN+N+Comp+NProp+Top+Reg:ns4q
    Kosovo i Metohijo,Kosovo i Metohija.NC_N3XN+N+Comp+NProp+Top+Reg:ns5q
    Kosovom i Metohijom,Kosovo i Metohija.NC_N3XN+N+Comp+NProp+Top+Reg:ns6q
    Kosovu i Metohiji,Kosovo i Metohija.NC_N3XN+N+Comp+NProp+Top+Reg:ns7q
    istrazxne sudije,istrazxni sudija.NC_AXNF+N+Comp:1vfp
    istrazxnih sudija,istrazxni sudija.NC_AXNF+N+Comp:2vfp
    istrazxnima sudijama,istrazxni sudija.NC_AXNF+N+Comp:3vfp
    istrazxnim sudijama,istrazxni sudija.NC_AXNF+N+Comp:3vfp
    istrazxne sudije,istrazxni sudija.NC_AXNF+N+Comp:4vfp
    istrazxne sudije,istrazxni sudija.NC_AXNF+N+Comp:5vfp
    istrazxnima sudijama,istrazxni sudija.NC_AXNF+N+Comp:6vfp
    istrazxnim sudijama,istrazxni sudija.NC_AXNF+N+Comp:6vfp
    istrazxnima sudijama,istrazxni sudija.NC_AXNF+N+Comp:7vfp
    istrazxnim sudijama,istrazxni sudija.NC_AXNF+N+Comp:7vfp
    istrazxne sudije,istrazxni sudija.NC_AXNF+N+Comp:2vfw
    istrazxne sudije,istrazxni sudija.NC_AXNF+N+Comp:4vfw
    istrazxnoga sudiju,istrazxni sudija.NC_AXNF+N+Comp:ms4v
    istrazxnog sudiju,istrazxni sudija.NC_AXNF+N+Comp:ms4v
    istrazxni sudija,istrazxni sudija.NC_AXNF+N+Comp:1vms
    istrazxnoga sudije,istrazxni sudija.NC_AXNF+N+Comp:2vms
    istrazxnog sudije,istrazxni sudija.NC_AXNF+N+Comp:2vms
    istrazxnomu sudiji,istrazxni sudija.NC_AXNF+N+Comp:3vms
    istrazxnome sudiji,istrazxni sudija.NC_AXNF+N+Comp:3vms
    istrazxnom sudiji,istrazxni sudija.NC_AXNF+N+Comp:3vms
    istrazxnomu sudiji,istrazxni sudija.NC_AXNF+N+Comp:7vms
    istrazxnome sudiji,istrazxni sudija.NC_AXNF+N+Comp:7vms
    istrazxnom sudiji,istrazxni sudija.NC_AXNF+N+Comp:7vms
    istrazxni sudijo,istrazxni sudija.NC_AXNF+N+Comp:5vms
    istrazxni sudija,istrazxni sudija.NC_AXNF+N+Comp:5vms
    istrazxnim sudijom,istrazxni sudija.NC_AXNF+N+Comp:6vms
    Dinkicx Mirosinka,Mirosinka Dinkicx.NC_ImePrezime+N+Comp+Hum+PersName:s1vf
    Dinkicx Mirosinke,Mirosinka Dinkicx.NC_ImePrezime+N+Comp+Hum+PersName:s2vf
    Dinkicx Mirosinki,Mirosinka Dinkicx.NC_ImePrezime+N+Comp+Hum+PersName:s3vf
    Dinkicx Mirosinku,Mirosinka Dinkicx.NC_ImePrezime+N+Comp+Hum+PersName:s4vf
    Dinkicx Mirosinka,Mirosinka Dinkicx.NC_ImePrezime+N+Comp+Hum+PersName:s5vf
    Dinkicx Mirosinkom,Mirosinka Dinkicx.NC_ImePrezime+N+Comp+Hum+PersName:s6vf
    Dinkicx Mirosinki,Mirosinka Dinkicx.NC_ImePrezime+N+Comp+Hum+PersName:s7vf
    Mirosinka Dinkicx,Mirosinka Dinkicx.NC_ImePrezime+N+Comp+Hum+PersName:s1vf
    Mirosinke Dinkicx,Mirosinka Dinkicx.NC_ImePrezime+N+Comp+Hum+PersName:s2vf
    Mirosinki Dinkicx,Mirosinka Dinkicx.NC_ImePrezime+N+Comp+Hum+PersName:s3vf
    Mirosinku Dinkicx,Mirosinka Dinkicx.NC_ImePrezime+N+Comp+Hum+PersName:s4vf
    Mirosinka Dinkicx,Mirosinka Dinkicx.NC_ImePrezime+N+Comp+Hum+PersName:s5vf
    Mirosinkom Dinkicx,Mirosinka Dinkicx.NC_ImePrezime+N+Comp+Hum+PersName:s6vf
    Mirosinki Dinkicx,Mirosinka Dinkicx.NC_ImePrezime+N+Comp+Hum+PersName:s7vf
    gladni kao vuk,gladan kao vuk.AC_A3XN2:s1mgda//hungry as a wolf
    gladan kao vuk,gladan kao vuk.AC_A3XN2:s1mgka//hungry as a wolf
    gladna kao vuk,gladan kao vuk.AC_A3XN2:s1fgea//hungry as a wolf
    gladno kao vuk,gladan kao vuk.AC_A3XN2:s1ngea//hungry as a wolf
    gladnoga kao vuk,gladan kao vuk.AC_A3XN2:s2mgda//hungry as a wolf
    gladnog kao vuk,gladan kao vuk.AC_A3XN2:s2mgda//hungry as a wolf
    gladna kao vuk,gladan kao vuk.AC_A3XN2:s2mgka//hungry as a wolf
    gladne kao vuk,gladan kao vuk.AC_A3XN2:s2fgea//hungry as a wolf
    gladnoga kao vuk,gladan kao vuk.AC_A3XN2:s2ngda//hungry as a wolf
    gladnog kao vuk,gladan kao vuk.AC_A3XN2:s2ngda//hungry as a wolf
    gladna kao vuk,gladan kao vuk.AC_A3XN2:s2ngka//hungry as a wolf
    gladnome kao vuk,gladan kao vuk.AC_A3XN2:s3mgda//hungry as a wolf
    gladnom kao vuk,gladan kao vuk.AC_A3XN2:s3mgda//hungry as a wolf
    gladnu kao vuk,gladan kao vuk.AC_A3XN2:s3mgka//hungry as a wolf
    gladnoj kao vuk,gladan kao vuk.AC_A3XN2:s3fgea//hungry as a wolf
    gladnome kao vuk,gladan kao vuk.AC_A3XN2:s3ngda//hungry as a wolf
    gladnom kao vuk,gladan kao vuk.AC_A3XN2:s3ngda//hungry as a wolf
    gladnu kao vuk,gladan kao vuk.AC_A3XN2:s3ngka//hungry as a wolf
    gladnu kao vuk,gladan kao vuk.AC_A3XN2:s4fgea//hungry as a wolf
    gladno kao vuk,gladan kao vuk.AC_A3XN2:s4ngea//hungry as a wolf
    gladni kao vuk,gladan kao vuk.AC_A3XN2:s5mgea//hungry as a wolf
    gladna kao vuk,gladan kao vuk.AC_A3XN2:s5fgea//hungry as a wolf
    gladno kao vuk,gladan kao vuk.AC_A3XN2:s5ngea//hungry as a wolf
    gladnim kao vuk,gladan kao vuk.AC_A3XN2:s6mgea//hungry as a wolf
    gladnom kao vuk,gladan kao vuk.AC_A3XN2:s6fgea//hungry as a wolf
    gladnim kao vuk,gladan kao vuk.AC_A3XN2:s6ngea//hungry as a wolf
    gladnome kao vuk,gladan kao vuk.AC_A3XN2:s7mgda//hungry as a wolf
    gladnom kao vuk,gladan kao vuk.AC_A3XN2:s7mgda//hungry as a wolf
    gladnu kao vuk,gladan kao vuk.AC_A3XN2:s7mgka//hungry as a wolf
    gladnoj kao vuk,gladan kao vuk.AC_A3XN2:s7fgea//hungry as a wolf
    gladnome kao vuk,gladan kao vuk.AC_A3XN2:s7ngda//hungry as a wolf
    gladnom kao vuk,gladan kao vuk.AC_A3XN2:s7ngda//hungry as a wolf
    gladnu kao vuk,gladan kao vuk.AC_A3XN2:s7ngka//hungry as a wolf
    gladni kao vuk,gladan kao vuk.AC_A3XN2:p1mgea//hungry as a wolf
    gladni kao vuci,gladan kao vuk.AC_A3XN2:p1mgea//hungry as a wolf
    gladni kao vukovi,gladan kao vuk.AC_A3XN2:p1mgea//hungry as a wolf
    gladne kao vuk,gladan kao vuk.AC_A3XN2:p1fgea//hungry as a wolf
    gladne kao vuci,gladan kao vuk.AC_A3XN2:p1fgea//hungry as a wolf
    gladne kao vukovi,gladan kao vuk.AC_A3XN2:p1fgea//hungry as a wolf
    gladna kao vuk,gladan kao vuk.AC_A3XN2:p1ngea//hungry as a wolf
    gladna kao vuci,gladan kao vuk.AC_A3XN2:p1ngea//hungry as a wolf
    gladna kao vukovi,gladan kao vuk.AC_A3XN2:p1ngea//hungry as a wolf
    gladnih kao vuk,gladan kao vuk.AC_A3XN2:p2mgea//hungry as a wolf
    gladnih kao vuci,gladan kao vuk.AC_A3XN2:p2mgea//hungry as a wolf
    gladnih kao vukovi,gladan kao vuk.AC_A3XN2:p2mgea//hungry as a wolf
    gladnih kao vuk,gladan kao vuk.AC_A3XN2:p2fgea//hungry as a wolf
    gladnih kao vuci,gladan kao vuk.AC_A3XN2:p2fgea//hungry as a wolf
    gladnih kao vukovi,gladan kao vuk.AC_A3XN2:p2fgea//hungry as a wolf
    gladnih kao vuk,gladan kao vuk.AC_A3XN2:p2ngea//hungry as a wolf
    gladnih kao vuci,gladan kao vuk.AC_A3XN2:p2ngea//hungry as a wolf
    gladnih kao vukovi,gladan kao vuk.AC_A3XN2:p2ngea//hungry as a wolf
    gladnima kao vuk,gladan kao vuk.AC_A3XN2:p3mgea//hungry as a wolf
    gladnima kao vuci,gladan kao vuk.AC_A3XN2:p3mgea//hungry as a wolf
    gladnima kao vukovi,gladan kao vuk.AC_A3XN2:p3mgea//hungry as a wolf
    gladnim kao vuk,gladan kao vuk.AC_A3XN2:p3mgea//hungry as a wolf
    gladnim kao vuci,gladan kao vuk.AC_A3XN2:p3mgea//hungry as a wolf
    gladnim kao vukovi,gladan kao vuk.AC_A3XN2:p3mgea//hungry as a wolf
    gladnima kao vuk,gladan kao vuk.AC_A3XN2:p3fgea//hungry as a wolf
    gladnima kao vuci,gladan kao vuk.AC_A3XN2:p3fgea//hungry as a wolf
    gladnima kao vukovi,gladan kao vuk.AC_A3XN2:p3fgea//hungry as a wolf
    gladnim kao vuk,gladan kao vuk.AC_A3XN2:p3fgea//hungry as a wolf
    gladnim kao vuci,gladan kao vuk.AC_A3XN2:p3fgea//hungry as a wolf
    gladnim kao vukovi,gladan kao vuk.AC_A3XN2:p3fgea//hungry as a wolf
    gladnima kao vuk,gladan kao vuk.AC_A3XN2:p3ngea//hungry as a wolf 
    gladnima kao vuci,gladan kao vuk.AC_A3XN2:p3ngea//hungry as a wolf
    gladnima kao vukovi,gladan kao vuk.AC_A3XN2:p3ngea//hungry as a wolf
    gladnim kao vuk,gladan kao vuk.AC_A3XN2:p3ngea//hungry as a wolf
    gladnim kao vuci,gladan kao vuk.AC_A3XN2:p3ngea//hungry as a wolf
    gladnim kao vukovi,gladan kao vuk.AC_A3XN2:p3ngea//hungry as a wolf
    gladne kao vuk,gladan kao vuk.AC_A3XN2:p4mgea//hungry as a wolf
    gladne kao vuci,gladan kao vuk.AC_A3XN2:p4mgea//hungry as a wolf
    gladne kao vukovi,gladan kao vuk.AC_A3XN2:p4mgea//hungry as a wolf
    gladne kao vuk,gladan kao vuk.AC_A3XN2:p4fgea//hungry as a wolf
    gladne kao vuci,gladan kao vuk.AC_A3XN2:p4fgea//hungry as a wolf
    gladne kao vukovi,gladan kao vuk.AC_A3XN2:p4fgea//hungry as a wolf
    gladna kao vuk,gladan kao vuk.AC_A3XN2:p4ngea//hungry as a wolf
    gladna kao vuci,gladan kao vuk.AC_A3XN2:p4ngea//hungry as a wolf
    gladna kao vukovi,gladan kao vuk.AC_A3XN2:p4ngea//hungry as a wolf
    gladni kao vuk,gladan kao vuk.AC_A3XN2:p5mgea//hungry as a wolf
    gladni kao vuci,gladan kao vuk.AC_A3XN2:p5mgea//hungry as a wolf
    gladni kao vukovi,gladan kao vuk.AC_A3XN2:p5mgea//hungry as a wolf
    gladne kao vuk,gladan kao vuk.AC_A3XN2:p5fgea//hungry as a wolf
    gladne kao vuci,gladan kao vuk.AC_A3XN2:p5fgea//hungry as a wolf
    gladne kao vukovi,gladan kao vuk.AC_A3XN2:p5fgea//hungry as a wolf
    gladna kao vuk,gladan kao vuk.AC_A3XN2:p5ngea//hungry as a wolf
    gladna kao vuci,gladan kao vuk.AC_A3XN2:p5ngea//hungry as a wolf
    gladna kao vukovi,gladan kao vuk.AC_A3XN2:p5ngea//hungry as a wolf
    gladnima kao vuk,gladan kao vuk.AC_A3XN2:p6mgea//hungry as a wolf
    gladnima kao vuci,gladan kao vuk.AC_A3XN2:p6mgea//hungry as a wolf
    gladnima kao vukovi,gladan kao vuk.AC_A3XN2:p6mgea//hungry as a wolf
    gladnim kao vuk,gladan kao vuk.AC_A3XN2:p6mgea//hungry as a wolf
    gladnim kao vuci,gladan kao vuk.AC_A3XN2:p6mgea//hungry as a wolf
    gladnim kao vukovi,gladan kao vuk.AC_A3XN2:p6mgea//hungry as a wolf
    gladnima kao vuk,gladan kao vuk.AC_A3XN2:p6fgea//hungry as a wolf
    gladnima kao vuci,gladan kao vuk.AC_A3XN2:p6fgea//hungry as a wolf
    gladnima kao vukovi,gladan kao vuk.AC_A3XN2:p6fgea//hungry as a wolf
    gladnim kao vuk,gladan kao vuk.AC_A3XN2:p6fgea//hungry as a wolf
    gladnim kao vuci,gladan kao vuk.AC_A3XN2:p6fgea//hungry as a wolf
    gladnim kao vukovi,gladan kao vuk.AC_A3XN2:p6fgea//hungry as a wolf
    gladnima kao vuk,gladan kao vuk.AC_A3XN2:p6ngea//hungry as a wolf
    gladnima kao vuci,gladan kao vuk.AC_A3XN2:p6ngea//hungry as a wolf
    gladnima kao vukovi,gladan kao vuk.AC_A3XN2:p6ngea//hungry as a wolf
    gladnim kao vuk,gladan kao vuk.AC_A3XN2:p6ngea//hungry as a wolf
    gladnim kao vuci,gladan kao vuk.AC_A3XN2:p6ngea//hungry as a wolf
    gladnim kao vukovi,gladan kao vuk.AC_A3XN2:p6ngea//hungry as a wolf
    gladnima kao vuk,gladan kao vuk.AC_A3XN2:p7mgea//hungry as a wolf
    gladnima kao vuci,gladan kao vuk.AC_A3XN2:p7mgea//hungry as a wolf
    gladnima kao vukovi,gladan kao vuk.AC_A3XN2:p7mgea//hungry as a wolf
    gladnim kao vuk,gladan kao vuk.AC_A3XN2:p7mgea//hungry as a wolf
    gladnim kao vuci,gladan kao vuk.AC_A3XN2:p7mgea//hungry as a wolf
    gladnim kao vukovi,gladan kao vuk.AC_A3XN2:p7mgea//hungry as a wolf
    gladnima kao vuk,gladan kao vuk.AC_A3XN2:p7fgea//hungry as a wolf
    gladnima kao vuci,gladan kao vuk.AC_A3XN2:p7fgea//hungry as a wolf
    gladnima kao vukovi,gladan kao vuk.AC_A3XN2:p7fgea//hungry as a wolf
    gladnim kao vuk,gladan kao vuk.AC_A3XN2:p7fgea//hungry as a wolf
    gladnim kao vuci,gladan kao vuk.AC_A3XN2:p7fgea//hungry as a wolf
    gladnim kao vukovi,gladan kao vuk.AC_A3XN2:p7fgea//hungry as a wolf
    gladnima kao vuk,gladan kao vuk.AC_A3XN2:p7ngea//hungry as a wolf
    gladnima kao vuci,gladan kao vuk.AC_A3XN2:p7ngea//hungry as a wolf
    gladnima kao vukovi,gladan kao vuk.AC_A3XN2:p7ngea//hungry as a wolf
    gladnim kao vuk,gladan kao vuk.AC_A3XN2:p7ngea//hungry as a wolf
    gladnim kao vuci,gladan kao vuk.AC_A3XN2:p7ngea//hungry as a wolf
    gladnim kao vukovi,gladan kao vuk.AC_A3XN2:p7ngea//hungry as a wolf
    gladna kao vuk,gladan kao vuk.AC_A3XN2:w2mgea//hungry as a wolf
    gladna kao vuci,gladan kao vuk.AC_A3XN2:w2mgea//hungry as a wolf
    gladna kao vukovi,gladan kao vuk.AC_A3XN2:w2mgea//hungry as a wolf
    gladne kao vuk,gladan kao vuk.AC_A3XN2:w2fgea//hungry as a wolf
    gladne kao vuci,gladan kao vuk.AC_A3XN2:w2fgea//hungry as a wolf
    gladne kao vukovi,gladan kao vuk.AC_A3XN2:w2fgea//hungry as a wolf
    gladna kao vuk,gladan kao vuk.AC_A3XN2:w2ngea//hungry as a wolf
    gladna kao vuci,gladan kao vuk.AC_A3XN2:w2ngea//hungry as a wolf
    gladna kao vukovi,gladan kao vuk.AC_A3XN2:w2ngea//hungry as a wolf
    gladna kao vuk,gladan kao vuk.AC_A3XN2:w4mgea//hungry as a wolf
    gladna kao vuci,gladan kao vuk.AC_A3XN2:w4mgea//hungry as a wolf
    gladna kao vukovi,gladan kao vuk.AC_A3XN2:w4mgea//hungry as a wolf
    gladne kao vuk,gladan kao vuk.AC_A3XN2:w4fgea//hungry as a wolf
    gladne kao vuci,gladan kao vuk.AC_A3XN2:w4fgea//hungry as a wolf
    gladne kao vukovi,gladan kao vuk.AC_A3XN2:w4fgea//hungry as a wolf
    gladna kao vuk,gladan kao vuk.AC_A3XN2:w4ngea//hungry as a wolf
    gladna kao vuci,gladan kao vuk.AC_A3XN2:w4ngea//hungry as a wolf
    gladna kao vukovi,gladan kao vuk.AC_A3XN2:w4ngea//hungry as a wolf

.. figure:: resources/img/NC'2XN1'SRB.png
   :alt: Inflection graph *NC\_2XN1* for Serbian MWUs
   :width: 12.40000cm

   Inflection graph *NC\_2XN1* for Serbian MWUs

.. figure:: resources/img/NC'2XN2'SRB.png
   :alt: Inflection graph *NC\_2XN2* for Serbian MWUs
   :width: 12.40000cm

   Inflection graph *NC\_2XN2* for Serbian MWUs

.. figure:: resources/img/NC'N2X1'SRB.png
   :alt: Inflection graph *NC\_N2X1* for Serbian MWUs
   :width: 12.20000cm

   Inflection graph *NC\_N2X1* for Serbian MWUs

.. figure:: resources/img/NC'AXN3'SRB.png
   :alt: Inflection graph *NC\_AXN3* for Serbian MWUs
   :width: 15.00000cm

   Inflection graph *NC\_AXN3* for Serbian MWUs

.. figure:: resources/img/NC'N3XN'SRB.png
   :alt: Inflection graph *NC\_N3XN* for Serbian MWUs
   :width: 10.00000cm

   Inflection graph *NC\_N3XN* for Serbian MWUs

.. figure:: resources/img/NC'AXNF'SRB.png
   :alt: Inflection graph *NC\_AXNF* for Serbian MWUs
   :width: 15.00000cm

   Inflection graph *NC\_AXNF* for Serbian MWUs

.. figure:: resources/img/NC'ImePrezime'SRB.png
   :alt: Inflection graph *NC\_ImePrezime* for Serbian MWUs
   :width: 15.00000cm

   Inflection graph *NC\_ImePrezime* for Serbian MWUs

.. figure:: resources/img/AC'A3XN2'SRB.png
   :alt: Inflection graph *AC\_A3XN2* for Serbian MWUs
   :width: 15.00000cm

   Inflection graph *AC\_A3XN2* for Serbian MWUs

.. [1]
   Up to the case when single constituents appearing in the lemma of a
   MWU are already in the plural, as in *cross-road*.

.. |Inflection graph *N3* for English simple words| image:: resources/img/N1'EN.png
   :width: 2.50000cm
.. |Inflection graph *N3* for English simple words| image:: resources/img/N3'EN.png
   :width: 3.00000cm
