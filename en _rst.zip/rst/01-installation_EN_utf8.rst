Installation of Unitex
======================

Unitex is a multi-platform system that runs on Windows as well as on
Linux or OS X. This chapter describes how to install and how to launch
Unitex on any of these systems. It also presents the procedures used to
add new languages and to uninstall Unitex.

Licenses
--------

Unitex is free software. This means that the source of the programs is
distributed with the software, and that anyone can modify and
redistribute it. The code of the Unitex programs is under the LGPL
licence (:raw-latex:`\cite{LGPL}`), except for:

#. the TRE library for dealing with regular expressions by Ville
   Laurikari (:raw-latex:`\cite{TRE}`), which is under a 2-clause
   BSD-style license;

#. the wingetopt library, by Todd Miller and the NetBSD Foundation, also
   under a 2-clause BSD-style license, more permissive than the LGPL;

#. the pstdin library, a cross platform source code header for precisely
   sized integers on all platforms, by Paul Hsieh, which is under a
   3-clause BSD-style license;

#. the Xerces2-j XML Parser, by the Apache Software Foundation, which is
   under the Apache Software License version 2.0;

#. the LibYAML library by Kirill Simonov, under MIT license, which is
   also more permissive than LGPL;

#. the SVNKit library by TMate Software, which is under TMate license.

The LGPL license is more permissive than the GPL, because it makes it
possible to use LGPL code in nonfree software. In both cases, the
software can be freely used and distributed.

All the language resources that go with Unitex are distributed under the
LGPLLR license (:raw-latex:`\cite{LGPLLR}`).

Full text versions of LGPL, 2-clause BSD, Apache, MIT, TMate and LGPLLR
can be found in the appendices of this manual.

Java runtime environment
------------------------

Unitex consists of a graphical interface written in Java and external
programs written in *C/C-.05em-.1em*. This mixture of programming
languages is responsible for a fast and portable application that runs
on different operating systems.

Before you can use the graphical interface, you first have to install
the runtime environment, usually called Java virtual machine or JRE
(Java Runtime Environment).

For the graphical mode, Unitex needs Java version 1.6 (or newer). If you
have an older version of Java, Unitex will stop after you have chosen
the working language.

You can download the virtual machine for your operating system for free
from the Sun Microsystems web site (:raw-latex:`\cite{site-java}`) at
the following address: http://java.sun.com.

If you are working under Linux or OS X, or if you are using a Windows
version with personal user accounts, you have to ask your system
administrator to install Java.

Installers
----------

The Unitex/GramLab installers can be downloaded from:

`\\UnitexURLLatestReleases <\UnitexURLLatestReleases>`__

Installer for Windows
~~~~~~~~~~~~~~~~~~~~~

The downloaded file will be named something like:

Then, double-click on this file and follow the instructions
(Fig. [fig-installer]). It is recommended to uninstall any existing
versions before installing a new one. Unitex/GramLab will be installed
in a directory (folder) which should preferably be located in the
``Program Files`` directory, and which will be called in this manual the
Unitex system directory.

.. figure:: resources/img/installer.png
   :alt: The Windows installer[fig-installer]
   :width: 13.00000cm

   The Windows installer[fig-installer]

When the installation is finished, a Unitex icon and a GramLab icon
should appear on the desktop: double-click on them to start Unitex or
GramLab (see [section-first-use]). (If the installer did not create
these icons, open the Unitex system directory: it contains several
subdirectories, one of which is named ``App``. This directory contains
two files named ``Unitex.jar`` and ``GramLab.jar``. They are the Java
files that launch the graphical interfaces. Double-click on one of them
to start Unitex or GramLab (see [section-first-use]). To facilitate
launching the interface, you may want to add shortcuts to these files on
the desktop.)

If Unitex is to be installed on a multi-user Windows machine, it is
recommended that the system administrator performs the installation. If
you are the only user on your machine, you can perform the installation
yourself.

The Windows installer can also be launched in command line and accepts
several optional command line parameters. Some of them are:

+----------------------------------+-------------------------------------------+
| ``/AllUsers``                    | Sets default to a per-machine install     |
+----------------------------------+-------------------------------------------+
| ``/CurrentUser``                 | Sets default to a per-user install        |
+----------------------------------+-------------------------------------------+
| ``/D C:\path\without quotes\``   | Sets the default installation directory   |
+----------------------------------+-------------------------------------------+
| ``/NCRC``                        | Skip the cyclic redundancy check          |
+----------------------------------+-------------------------------------------+
| ``/S``                           | Runs the installer silently               |
+----------------------------------+-------------------------------------------+

If you run Unitex under Windows 7, you may experience trouble with your
Unitex configuration file, because Unitex tries to write it in the
``Users`` subdirectory, and Windows 7 forbids it.

Installer for GNU/Linux and OS X
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The downloaded file will be named something like:

Then, give it executable permissions, by typing, for example
(Fig. [fig-installer-linux]):

chmod a+x

The ``.run`` file is a self-extracting archive. Execute it with:

./

.. figure:: resources/img/installer-linux.png
   :alt: The GNU/Linux and OS X installer[fig-installer-linux]
   :width: 13.00000cm

   The GNU/Linux and OS X installer[fig-installer-linux]

The GNU/Linux and OS X installer accepts several optional command line
parameters. Some of them are:

+--------------------+-------------------------------------------------------+
| ``--confirm``      | Ask before running the embedded installation script   |
+--------------------+-------------------------------------------------------+
| ``--quiet``        | Do not print anything except error messages           |
+--------------------+-------------------------------------------------------+
| ``--noexec``       | Do not run the embedded installation script           |
+--------------------+-------------------------------------------------------+
| ``--target dir``   | Sets the default installation directory               |
+--------------------+-------------------------------------------------------+

Manual installation
-------------------

You can also install Unitex/GramLab manually from the source
distribution package. Download it from:

`\\UnitexURLLatestReleases/source <\UnitexURLLatestReleases/source>`__

The downloaded file will be named something like:

Decompress it into a directory called for example Unitex, which should
preferably be created in the ``Program Files`` directory, and which will
be the Unitex system directory.

If your computer runs one of the following operating systems, the
installation is finished: Windows (32-bit, 64-bit), GNU/Linux (i686,
x86\_64) and OS X (10.7+). (If it runs another Unix-like OS, like
FreeBSD, or has another processor architecture, like ARM, go into the
``App/install`` directory and type:

``sh setup``

This script checks if Java is installed, compiles the C++ core sources,
sets up the Unitex and GramLab personal working directories and creates
some desktop shortcuts. [1]_)

When the installation is finished, the Unitex system directory contains
several subdirectories, one of which is called ``App``.

-  On Windows: the ``App`` directory contains files named ``Unitex.jar``
   and ``GramLab.jar``. They are the Java files that launch the
   graphical interfaces. Double-click on one of them to start Unitex or
   GramLab (see [section-first-use]). To facilitate launching the
   interfaces, you may want to add shortcuts to these files on the
   desktop.

-  On Linux or OS X: the ``App`` directory contains two shell scripts
   named ``Unitex`` and ``GramLab``. Launch one of them to start Unitex
   or GramLab (see [section-first-use]). If you have run the setup
   script, it should have added shortcuts to these files on the desktop.

First use
---------

If you work on Windows, the program will ask you to choose a personal
working directory, which you can change later in
“Info>Preferences...>Directories”. To create a directory, click on the
icon showing a file (see figure [fig-creation-personal-directory]).

If you are using Linux or OS X, the program will automatically create a
personal working directory called ``/unitex`` in your ``$HOME``
directory.

The personal working directory, or user’s directory, allows you to save
your personal Unitex data. For each language that you will be using, the
program will copy the root directory of that language to your working
directory, except the dictionaries. You can then modify your copy of the
files without risking to damage the system files stored in the Unitex
system directory.

.. figure:: resources/img/fig1-1.png
   :alt: First use under Windows
   :width: 6.30000cm

   First use under Windows

.. figure:: resources/img/fig1-2.png
   :alt: First use under Linux
   :width: 7.00000cm

   First use under Linux

.. figure:: resources/img/fig1-3.png
   :alt: Creating the personal working
   directory[fig-creation-personal-directory]
   :width: 13.00000cm

   Creating the personal working
   directory[fig-creation-personal-directory]

Adding new languages
--------------------

There are two different ways to add languages. If you want to add a
language that is to be accessible by all users, you have to copy the
corresponding directory to the Unitex system directory, for which you
will need to have the access rights (this might mean that you need to
ask your system administrator to do it). On the other hand, if you are
the only user working with the language, you can also copy the directory
to your working directory. You can work with this language without it
being shown to other users.

Uninstalling Unitex
-------------------

No matter which operating system you are working with, it is sufficient
to delete the Unitex system directory to completely delete all the
program files. Under Windows you may have to delete the shortcut to
``Unitex.jar`` if you have created one on your desktop. The same has to
be done on Linux, if you have created an alias.

Unitex for developers
---------------------

If you are a programmer, you may be interested in linking your code to
the C++ core of Unitex. To facilitate such operation, you can compile
Unitex as a dynamic library that contains all Unitex functions, except
``main``\ s, of course. The page
http://docs.unitexgramlab.org/projects/unitex-library/en/latest/
contains documentation about the library. The C++ core of Unitex
contains source code for Java JNI, Ruby and Microsoft .NET bindings. The
page https://github.com/patwat/python-unitex contains Python bindings.

Under Linux/OS X, type:

``make LIBRARY=yes``

and you will obtain a library named ``libunitex.so``. If you want to
produce a Windows DLL named ``unitex.dll``, use the following commands:

Windows: ``make SYSTEM=windows LIBRARY=yes``

Cross-compiling with mingw32: ``make SYSTEM=mingw32 LIBRARY=yes``

In all cases, you will also obtain a program named
``Test_lib``\ (``.exe``). If everything worked fine, this program should
display the following:

::

    Expression converted.
    Reg2Grf exit code: 0

    #Unigraph
    SIZE 1313 950
    FONT Times New Roman:  12
    OFONT Times New Roman:B 12
    BCOLOR 16777215
    FCOLOR 0
    ACOLOR 12632256
    SCOLOR 16711680
    CCOLOR 255
    DBOXES y
    DFRAME y
    DDATE y
    DFILE y
    DDIR y
    DRIG n
    DRST n
    FITS 100
    PORIENT L
    #
    7
    "<E>" 100 100 1 5
    "" 100 100 0
    "a" 100 100 1 6
    "b" 100 100 1 4
    "c" 100 100 1 6
    "<E>" 100 100 2 2 3
    "<E>" 100 100 1 1

.. [1]
   If you want to compile only the C++ core sources, extract the files
   from the source distribution package, go into the Src/C++/build
   directory and type make install.
