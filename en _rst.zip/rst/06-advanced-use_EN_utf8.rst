Advanced use of graphs
======================

Types of graphs
---------------

Unitex can handle several types of graphs that correspond to the
following uses: automatic inflection of dictionaries, preprocessing of
texts, normalization of text automata, dictionary graphs, search for
patterns, disambiguation and automatic graph generation. These different
types of graphs are not interpreted in the same way by Unitex. Certain
operations, like transduction, are allowed for some types and forbidden
for others. In addition, special symbols are not the same depending on
the type of graph. This section presents each type of graph and shows
their peculiarities.

Inflection transducers
~~~~~~~~~~~~~~~~~~~~~~

An inflection transducer describes the morphological variation that is
associated with a word class by assigning inflectional codes to each
variant. The paths of such a transducer describe the modifications that
have to be applied to the canonical forms and the corresponding outputs
contain the inflectional information that will be produced.

.. figure:: resources/img/fig6-1.png
   :alt: Example of an inflectional grammar
   :width: 4.50000cm

   Example of an inflectional grammar

The paths may contain operators and letters. The possible operators are
represented by the characters ``L``, ``R``, ``C``, ``D``, ``U``,\ ``P``
and ``W``. All letters that are not operators are characters. The only
allowed special symbol is the empty word ``<E>``. It is not possible to
refer to information in dictionaries in an inflection transducer, but it
is possible to reference subgraphs.

Transducer outputs are concatenated in order to produce a string of
characters. This string is then appended to the produced dictionary
entry. Outputs with variables do not make sense in an inflection
transducer.

Case of letters is respected: lowercase letters stay lowercase, the same
for uppercase letters. Besides, the connection of two boxes is exactly
equivalent to the concatenation of their contents together with the
concatenation of their outputs. (cf.
figure [fig-equivalent-inflection-paths]).

.. figure:: resources/img/fig6-2.png
   :alt: Two equivalent paths in an inflection
   grammar[fig-equivalent-inflection-paths]
   :width: 5.50000cm

   Two equivalent paths in an inflection
   grammar[fig-equivalent-inflection-paths]

Inflection transducers may be compiled before being used by the
inflection program. If not, the inflection program will compile them on
the fly.

For more details, see section [section-automatic-inflection].

Preprocessing graphs
~~~~~~~~~~~~~~~~~~~~

Preprocessing graphs are meant to be applied to texts before they are
tokenized into lexical units. These graphs can be used for inserting or
replacing sequences in the texts. The two customary uses of these graphs
are normalization of non-ambiguous forms and sentence boundary
recognition.

The interpretation of these graphs in Unitex is very close to that of
syntactic graphs used by the search for patterns. The differences are
the following:

-  you can use the special symbol ``<^>`` that recognizes a newline;

-  if you work in character by character mode, you can use the special
   symbol ``<L>`` that recognizes one letter, as defined in the alphabet
   file;

-  it is impossible to refer to information in dictionaries;

-  it is impossible to use morphological filters;

-  it is impossible to use morphological mode;

-  it is impossible to use contexts.

The figures [fig-example-sentence-splitting] (page )
and [fig-normalization-grammar] (page ) show examples of preprocessing
graphs.

Graphs for normalizing the text automaton
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Graphs for normalizing the text automaton allow you to normalize
ambiguous forms. They can describe several labels for the same form.
These labels are then inserted into the text automaton thus making the
ambiguity explicit. Figure [fig-tfst-normalization-grammar] shows an
extract of the normalization graph used by default for French.

.. figure:: resources/img/fig6-3.png
   :alt: Extract of the normalization graph used for
   French[fig-tfst-normalization-grammar]
   :width: 13.50000cm

   Extract of the normalization graph used for
   French[fig-tfst-normalization-grammar]

The paths describe the forms that have to be normalized. Lower case and
upper case variants are taken into account according to the following
principle: uppercase letters in the graph only recognize uppercase
letters in the text automaton; lowercase letters can recognize both
lowercase and uppercase letters.

The transducer outputs represent the sequences of labels that will be
inserted into the text automaton. These labels can be dictionary entries
or strings of characters. The labels that represent dictionary entries
have to respect the DELAF format and must be enclosed by the ``{`` and
``}`` symbols. Outputs with variables do not make sense in this kind of
graph. You cannot use morphological filters, morphological mode or
contexts.

It is possible to reference subgraphs. It is not possible to reference
information in dictionaries in order to describe the forms to normalize.
The only special symbol that is recognized in this type of graph is the
empty word ``<E>``. The graphs for normalizing ambiguous forms need to
be compiled before using them.

Syntactic graphs
~~~~~~~~~~~~~~~~

Syntactic graphs, often called local grammars, allow you to describe
syntactic patterns that can then be searched in the texts. Of all kinds
of graphs these have the greatest expressive power because they allow
you to refer to information in dictionaries.

Lower case/upper case variants may be used according to the principle
described above. It is still possible to enforce respect of case by
enclosing an expression in double quotes. The use of double quotes also
allows you to enforce the respect of spaces. In fact, Unitex by default
assumes that a space is possible between two boxes. In order to enforce
the presence of a space you have to enclose it in double quotes. For
prohibiting the presence of a space you have to use the special symbol
``#``.

Syntactic graphs can reference subgraphs (cf.
section [section-subgraphs]). They also have outputs including outputs
with variables. The produced sequences are interpreted as strings of
characters that will be inserted in the concordances or in the text if
you want to modify it (cf. section [section-modifying-text]).

Syntactic graphs can use contexts (see section [section-contexts]).

Syntactic graphs can use morphological filters (see section
[section-filters]).

Syntactic graphs can use morphological mode (see section
[section-morphological-mode]).

The special symbols that are supported by the syntactic graphs are the
same as those that are usable in regular expressions (cf.
section [section-special-symbols]).

It is not obligatory to compile syntactic graphs before using them for
pattern matching. If a graph is not compiled the system will compile it
automatically.

ELAG grammars
~~~~~~~~~~~~~

ELAG grammars for disambiguation between lexical symbols in text
automata are described in section [section-elag-grammars], page .

Parameterized graphs
~~~~~~~~~~~~~~~~~~~~

Parameterized graphs are meta-graphs that allow you to generate a family
of graphs using a lexicon-grammar table. It is possible to construct
parameterized graphs for all possible kinds of graphs. The construction
and use of parameterized graphs are explained in
chapter [chap-lexicon-grammar].

Compilation of a grammar
------------------------

Compilation of a graph
~~~~~~~~~~~~~~~~~~~~~~

Compilation is the operation that converts the ``.grf`` format to a
format that can be manipulated more easily by Unitex programs. In order
to compile a graph, you must open it and then click on “Compile FST2” in
the “Tools” submenu of the menu “FSGraph”. Unitex then launches the
``Grf2Fst2`` program. You can keep track of its execution in a window
(cf. Figure [fig-compilation-frame]).

.. figure:: resources/img/fig6-4.png
   :alt: Compilation window[fig-compilation-frame]
   :width: 14.70000cm

   Compilation window[fig-compilation-frame]

If the graph references subgraphs, those are automatically compiled. The
result is a ``.fst2`` file that contains all the graphs that make up a
grammar. The grammar is then ready to be used by Unitex programs.

Approximation with a finite state transducer
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[flatten-section] The FST2 format conserves the architecture in
subgraphs of the grammars, which is what makes them different from
strict finite state transducers. The ``Flatten`` program allows you to
turn a FST2 grammar into a finite state transducer whenever this is
possible, and to construct an approximation if not. This function thus
permits to obtain objects that are easier to manipulate and to which all
classical algorithms on automata can be applied.

In order to compile and thus transform a grammar, select the command
“Compile & Flatten FST2” in the “Tools” submenu of the “FSGraph” menu.
The window of Figure [fig-flatten-configuration] allows you to configure
the approximation process.

.. figure:: resources/img/fig6-5.png
   :alt: Configuration of approximation of a
   grammar[fig-flatten-configuration]
   :width: 10.40000cm

   Configuration of approximation of a
   grammar[fig-flatten-configuration]

The box “Flattening depth” lets you specify the level of embedding of
subgraphs. This value represents the maximum depth up to which the
callings of subgraphs will be replaced by the subgraphs themselves.

The “Expected result grammar format” box allows you to determine the
behavior of the program beyond the selected limit. If you select the
“Finite State Transducer” option, the calls to subgraphs will be
replaced by ``<E>`` beyond the maximum depth. This option guarantees
that we obtain a finite state transducer, however possibly not
equivalent to the original grammar. On the contrary, the “equivalent
FST2” option indicates that the program should allow for subgraph calls
beyond the limited depth. This option guarantees the strict equivalence
of the result with the original grammar but does not necessarily produce
a finite state transducer. This option can be used for optimizing
certain grammars.

A message indicates at the end of the approximation process if the
result is a finite state transducer or an FST2 grammar and in the case
of a transducer if it is equivalent to the original grammar (cf.
Figure [fig-flatten-result]).

.. figure:: resources/img/fig6-6.png
   :alt: Resultat of the approximation of a grammar[fig-flatten-result]
   :width: 14.70000cm

   Resultat of the approximation of a grammar[fig-flatten-result]

Constraints on grammars
~~~~~~~~~~~~~~~~~~~~~~~

With the exception of inflection grammars, a grammar can never have an
empty path. This means that the paths of a main graph must not recognize
the empty word but this does not prevent a subgraph of that grammar from
recognizing epsilon.

It is not possible to associate a transducer output with a call to a
subgraph. Such outputs are ignored by Unitex. It is therefore necessary
to use an empty box that is situated to the left of the call to the
subgraph in order to specify the output (cf.
Figure [fig-subgraph-output]).

.. figure:: resources/img/fig6-7.png
   :alt: How to associate an output with a call to a
   subgraph[fig-subgraph-output]
   :width: 9.10000cm

   How to associate an output with a call to a
   subgraph[fig-subgraph-output]

The grammars must not contain void loops because the Unitex programs
cannot terminate the exploration of such a grammar. A void loop is a
configuration that causes the ``Locate`` program to enter an infinite
loop. Void loops can originate from transitions that are labeled by the
empty word or from recursive calls to subgraphs.

Void loops due to transitions with the empty word can have two origins
of which the first is illustrated by the
Figure [fig-epsilon-output-loop]. This type of loops is due to the fact
that a transition with the empty word cannot be eliminated automatically
by Unitex because it is associated with an output. Thus, the transition
with the empty word of Figure [fig-epsilon-output-loop] will not be
suppressed and will cause a void loop.

.. figure:: resources/img/fig6-8.png
   :alt: Void loop due to a transition by the empty word with a
   transduction[fig-epsilon-output-loop]
   :width: 6.20000cm

   Void loop due to a transition by the empty word with a
   transduction[fig-epsilon-output-loop]

The second category of loop by epsilon concerns the call to subgraphs
that can recognize the empty word. This case is illustrated in
Figure [fig-epsilon-subgraph-loop]: if the subgraph ``Adj`` recognizes
epsilon, there is a void loop that Unitex cannot detect.

.. figure:: resources/img/fig6-9.png
   :alt: Void loop due to a call to a subgraph that recognizes epsilon
   [fig-epsilon-subgraph-loop]
   :width: 7.90000cm

   Void loop due to a call to a subgraph that recognizes epsilon
   [fig-epsilon-subgraph-loop]

The third possibility of void loops is related to recursive calls to
subgraphs. Look at the graphs ``Det`` and ``DetCompose`` in
figure [fig-recursive-calls-loop].

.. figure:: resources/img/fig6-10.png
   :alt: Void loop caused by two graphs calling each
   other[fig-recursive-calls-loop]
   :width: 15.50000cm

   Void loop caused by two graphs calling each
   other[fig-recursive-calls-loop]

Each of these graphs can call the other *without reading any text*. The
fact that none of these two graphs has labels between the initial state
and the call to the subgraph is crucial. In fact, if there were at least
one label different from epsilon between the beginning of the graph
``Det`` and the call to ``DetCompose``, this would mean that the Unitex
programs exploring the graph ``Det`` would have to read the pattern
described by that label in the text before calling ``DetCompose``
recursively. In this case the programs would loop infinitely only if
they recognized the pattern an infinite number of times in the text,
which is impossible.

Interval for number of repetitions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In order to recognize token sequences in which one pattern appears once,
several times in sequence or never, you can attach an integer interval
to a box. This sets limits to the number of times the pattern occurs.
The pattern must be described in a single box. If you attach the
interval [m,M] to a box containing <A> (figure [intervals]), the path
will match sequences with at least :math:`m` consecutive adjectives and
no more than :math:`M`.

.. figure:: resources/img/fig6-10a.png
   :alt: Use of an interval to match several consecutive
   tokens[intervals]
   :width: 13.50000cm

   Use of an interval to match several consecutive tokens[intervals]

Intervals are attached by inserting ``$[m,M]$`` into the output of the
box, just after the character “/”, and according to the following rules
:

-  ``[m,M]`` = at least :math:`m` consecutive terms and no more than
   :math:`M`

-  ``[,M]`` = 0 to :math:`M`

-  ``[m,]`` = at least :math:`m`

The box must not be connected to itself with a direct loop. An interval
is compatible with an output in the usual sense. For example, to insert
``<ADJ position='anteposed'>`` as an output under the box of
figure [intervals], type ``<A>/$[1,4]$/<ADJ position='anteposed'>`` in
the text field.

Error detection
~~~~~~~~~~~~~~~

In order to keep the programs from blocking or crashing, Unitex
automatically detects errors during graph compilation. The graph
compiler checks that the main graph does not recognize the empty word
and searches for all possible forms of void loops. When an error is
encountered, an error message is displayed in the compilation window.
Figure [fig-error-message] shows the message that appears if one tries
to compile the graph ``Det`` of Figure [fig-recursive-calls-loop].

.. figure:: resources/img/fig6-11.png
   :alt: Error message when trying to compile
   ``Det``\ [fig-error-message]
   :width: 15.00000cm

   Error message when trying to compile ``Det``\ [fig-error-message]

When you start a pattern search with a ``.grf`` graph , if Unitex
detects an error at the graph compilation, the locate operation is
automatically interrupted.

Contexts
--------

[section-contexts]

Unitex graphs as we described them up to here are equivalent to
algebraic grammars. These are also known as context-free grammars,
because if you want to match a sequence :math:`A`, the context of
:math:`A` is irrelevant. Thus, you cannot use a contex-free graph for
matching occurences of ``president`` not followed by
``of the republic``.

However, you can draw graphs with positive or negative contexts. In that
case, graphs are no more equivalent to algebraic grammars, but to
context-sensitive grammars that do not have the same theoretical
properties.

Right contexts
~~~~~~~~~~~~~~

To define a right context, you must bound a zone of the graph with boxes
containing ``$[`` and ``$]``, which indicate the start and the end of
the right context. These bounds appear in the graph as green square
brackets. Both bounds of a right context must be located in the same
graph.

.. figure:: resources/img/fig6-12.png
   :alt: Using a right context[fig-context1]
   :width: 7.40000cm

   Using a right context[fig-context1]

Figure [fig-context1] shows a simple right context. The graph matches
numbers followed by a currency symbol, but this symbol will not appear
in matched sequences, *i.e.* in the concordance.

Right contexts are interpreted as follows. During the application of a
grammar on a text, let us assume that a right context start is found.
Let :math:`pos` be the current position in the text at this time. Now,
the ``Locate`` program tries to match the expression described inside
the right context. If it fails, then there will be no match. If it
matches the whole right context (that is to say if ``Locate`` reaches
the right context end), then the program will rewind at position
:math:`pos` and go on exploring the grammar after the right context end.

Weights (section [Transducers]) are ignored in right contexts.

You can also define negative right contexts, using ``$![`` to indicate
the right context start. Figure [fig-context2] shows a graph that
matches numbers that are not followed by ``th``. The difference with
positive right contexts is that when ``Locate`` tries to match the
expression described inside the context, reaching the context stop will
be considered as a failure, because it would have matched a forbidden
sequence. At the opposite, if the context stop cannot be reached, then
``Locate`` will rewind at the position :math:`pos` and go on exploring
the grammar after the context end.

.. figure:: resources/img/fig6-13.png
   :alt: Using a negative right context[fig-context2]
   :width: 7.30000cm

   Using a negative right context[fig-context2]

Right contexts can appear anywhere in the graph, including the beginning
of the graph. Figure [fig-context3] shows a graph that matches an
adjective in the right context of something that is not a past
participle. In other words, this graph matches adjectives that are not
ambiguous with past participles.

.. figure:: resources/img/fig6-14.png
   :alt: Matching an adjective that is not ambiguous with a past
   participle[fig-context3]
   :width: 7.50000cm

   Matching an adjective that is not ambiguous with a past
   participle[fig-context3]

In graphs like that of Figure [fig-context3], the negative right context
does not need to match the same number of tokens as the box after it.
For example, before the graph of Figure [too-also] recognizes ``too``,
the negative right context checks if it occurs in a phrase like
``too early`` or ``too many``.

.. figure:: resources/img/fig-too-also.png
   :alt: A context that does not check the same number of words as the
   box after it[too-also]
   :width: 7.50000cm

   A context that does not check the same number of words as the box
   after it[too-also]

Negative right contexts allow you to formulate complex patterns. For
instance, the graph of figure [fig-context4] matches a sequence of two
simple nouns that is not ambiguous with a compound word. In fact, the
pattern ``<CDIC><<^([^ ]+ [^ ]+)$>>`` matches a compound word with
exactly one space, and the pattern ``<N><<^([^ ]+)$>>`` matches a noun
without space, that is to say a simple noun. Thus, in the sentence
*Black cats should like the town hall*, this graph will match *Black
cats*, but not *town hall*, which is a compound word.

.. figure:: resources/img/fig6-15.png
   :alt: Advanced use of right contexts[fig-context4]
   :width: 8.90000cm

   Advanced use of right contexts[fig-context4]

You can use nested contexts. For instance, the graph shown in
figure [fig-context5] matches a number that is not followed by a dot,
except for a dot followed by a number. Thus, in the sequence
*5.0+7.=12*, this graph will match *5*, *0* and *12*.

.. figure:: resources/img/fig6-16.png
   :alt: Nested contexts[fig-context5]
   :width: 12.00000cm

   Nested contexts[fig-context5]

If a right context contains boxes with transducer outputs, the outputs
are ignored. However, it is possible to use a variable that was defined
inside a right context (cf. figure [fig-context6]). If you apply this
graph in MERGE mode to the text *the cat is white*, you will obtain:

``the is white``

.. figure:: resources/img/fig6-17.png
   :alt: Variable defined inside a right context[fig-context6]
   :width: 12.20000cm

   Variable defined inside a right context[fig-context6]

Left contexts
~~~~~~~~~~~~~

It is also possible to look for an expression :math:`X` only if it
occurs after an expression :math:`Y`. Of course, it was already possible
to do that with a grammar like the one shown on Figure
[fig-left-context1]. However, with such a grammar, the context part on
the left will be included in the match, as shown on Figure
[fig-left-context2].

.. figure:: resources/img/fig6-17a.png
   :alt: Matching a noun that occurs after a numeral
   determiner[fig-left-context1]
   :width: 7.00000cm

   Matching a noun that occurs after a numeral
   determiner[fig-left-context1]

.. figure:: resources/img/fig6-17b.png
   :alt: Results of the application of the grammar shown on Figure
   [fig-left-context1][fig-left-context2]
   :width: 14.00000cm

   Results of the application of the grammar shown on Figure
   [fig-left-context1][fig-left-context2]

To avoid that, you can use the special symbol ``$*`` to indicate the end
of the left context of the expression you want to match. This symbol
will be represented by a green star in the graph, as shown on Figure
[fig-left-context3]. The effect of such a context is to use this part of
the grammar for computing matches, but to ignore it in the results, as
shown on Figure [fig-left-context4].

.. figure:: resources/img/fig6-17c.png
   :alt: Matching a noun after a left context[fig-left-context3]
   :width: 9.00000cm

   Matching a noun after a left context[fig-left-context3]

.. figure:: resources/img/fig6-17d.png
   :alt: Results of the application of the grammar shown on Figure
   [fig-left-context3][fig-left-context4]
   :width: 14.00000cm

   Results of the application of the grammar shown on Figure
   [fig-left-context3][fig-left-context4]

All the outputs produced in the left context are ignored, as you can see
in the concordance of Figure [fig-left-context6], showing the results
obtained with the grammar of Figure [fig-left-context5].

.. figure:: resources/img/fig6-17e.png
   :alt: Ignored output in a left context[fig-left-context5]
   :width: 9.00000cm

   Ignored output in a left context[fig-left-context5]

.. figure:: resources/img/fig6-17f.png
   :alt: Results of the application of the grammar shown on Figure
   [fig-left-context5][fig-left-context6]
   :width: 15.00000cm

   Results of the application of the grammar shown on Figure
   [fig-left-context5][fig-left-context6]

However, you can store information in variables (see section
[section-variables]) and use it outside the left context, as shown on
the grammar of Figure [fig-left-context7] which produces the concordance
of Figure [fig-left-context8].

.. figure:: resources/img/fig6-17g.png
   :alt: Using a variable in a left context[fig-left-context7]
   :width: 10.00000cm

   Using a variable in a left context[fig-left-context7]

.. figure:: resources/img/fig6-17h.png
   :alt: Results of the application of the grammar shown on Figure
   [fig-left-context7][fig-left-context8]
   :width: 15.00000cm

   Results of the application of the grammar shown on Figure
   [fig-left-context7][fig-left-context8]

A graph with left contexts may be invoked in a grammar, but this
requires caution. When the left context part is excluded from the match,
any sequences that had been matched before by any of the calling graphs
are excluded from the match too, because the eventual matched sequence
must be contiguous. Any outputs in excluded sequences are ignored too.

Thus, with left and right contexts, you can make a distinction between
patterns used to match spots in texts, and the delimitation of the
sequences to be extracted into your results. For instance, the grammar
shown on Figure [fig-left-context9] looks for expressions like
``the animal's``, but only extracts nouns, as you can see on Figure
[fig-left-context10].

.. figure:: resources/img/fig6-17i.png
   :alt: A grammar with both left and right contexts[fig-left-context9]
   :width: 10.00000cm

   A grammar with both left and right contexts[fig-left-context9]

.. figure:: resources/img/fig6-17j.png
   :alt: Results of the application of the grammar shown on Figure
   [fig-left-context9][fig-left-context10]
   :width: 15.00000cm

   Results of the application of the grammar shown on Figure
   [fig-left-context9][fig-left-context10]

Weights (section [Transducers]) work normally in left contexts.

The morphological mode
----------------------

Why ?
~~~~~

As Unitex works on a tokenized version of the text, it is not possible
to perform queries that need to enter inside tokens, except with
morphological filters (see section [section-filters]), as shown on
Figure [fig-morpho1].

.. figure:: resources/img/fig6-17k.png
   :alt: Matching morphological elements[fig-morpho1]
   :width: 7.00000cm

   Matching morphological elements[fig-morpho1]

However, even morphological filters cannot allow any query, since they
cannot refer to information stored in dictionaries. Thus, it is
impossible to formulate this way a query like “*a word made of the
prefix* ``un`` *followed by an adjective suffixed with* ``able``”.

To overcome this difficulty, we introduced a morphological mode in the
``Locate`` program. It consists of bounding a part of your grammar with
the special symbols ``$<`` and ``$>``. Within this zone, sequences are
matched letter by letter, as shown on Figure [fig-morpho2].

.. figure:: resources/img/fig6-17l.png
   :alt: Example of morphological zone in a grammar[fig-morpho2]
   :width: 11.00000cm

   Example of morphological zone in a grammar[fig-morpho2]

The rules
~~~~~~~~~

In this mode, the content of the graph is not interpreted as it is in
the normal way.

#. There is no implicit space between boxes. So, if you want to match a
   space, you have to make it explicit with ``" "`` (a space between
   double quotes).

#. You can still use subgraphs, but the end of the morphological zone
   must occur in the same graph as its beginning.

#. You can use lexical masks involving dictionary lookup—such as
   ``<DIC>``, ``<be>`` or ``<N:ms>``, which refer to information stored
   in a dictionary—, provided that the dictionary has been previously
   declared as a morphological-mode dictionary
   (section [morph-mode-dic]).

#. You can use lexical masks involving a lookup in a dictionary graph
   (section [section-dictionary-graphs]), provided that the name of the
   dictionary graph contains the ``b`` switch. However, this feature
   works only for forms recognized by the dictionary graph in the text
   during initial application of dictionaries
   (section [section-applying-dictionaries]), and not for forms that
   occur in the text only as token parts.

#. You can use morphological filters (section [section-filters]).
   However, morphological filters used alone or on ``<TOKEN>`` will only
   apply to the current character. As a consequence, filters like
   ``<<[1-9][0-9]>>`` that are meant to match more than one character
   will never match anything. In fact, in morphological mode,
   morphological filters should only be used to express negations like
   ``<<[^aeiouy]>>`` (any character that is not a vowel).

#. Left and right contexts are forbidden.

#. You can use outputs.

#. ``<LETTER>`` will match any letter, as defined in the alphabet file.

#. ``<LOWER>`` will match any lowercase letter, as defined in the
   alphabet file.

#. ``<UPPER>`` will match any uppercase letter, as defined in the
   alphabet file.

#. ``<DIC>`` will match any word present in a morphological-mode
   dictionary, but the meta-symbols ``#``, ``<FIRST>``, ``<NB>``,
   ``<SDIC>`` and ``<CDIC>`` are forbidden.

#. If you reach the end of the morphological zone and if you are not at
   the end of a token, the match will fail. For instance, if the text
   contains ``enabled``, you cannot match ``enable`` only.

Earlier codes for ``<LETTER>``, ``<LOWER>`` and ``<UPPER>`` were
respectively ``<MOT>``, ``<MIN>`` and ``<MAJ>`` . They can still be used
for backward compatibility of the system with existing graphs. Though
there are no current plans to remove this codes, it is recommended to
avoid them in graphs designed to be used with more recent versions, [1]_
so that the number of lexical masks in use does not increase uselessly.

Morphological-mode dictionaries
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[morph-mode-dic] In morphological mode, you can perform queries using
dictionaries. For instance, the grammar of Figure [fig-morpho3] searches
for every word made of the prefix ``un`` followed by an adjective.

.. figure:: resources/img/fig6-17m.png
   :alt: Matching words made of ’un’+adjective ending with
   ’able’[fig-morpho3]
   :width: 11.00000cm

   Matching words made of ’un’+adjective ending with ’able’[fig-morpho3]

.. figure:: resources/img/fig6-17n.png
   :alt: Configuration of morphological-mode dictionaries[fig-morpho4]
   :width: 11.00000cm

   Configuration of morphological-mode dictionaries[fig-morpho4]

To be able to match with this grammar the word ``unaware``, the system
must know that ``aware`` is an adjective. The lexical mask ``<A>``
involves a dictionary lookup. But ``aware`` may not be present in the
text, so that we cannot rely on the text dictionaries. [2]_ This is the
reason why we must define a list of dictionaries to be looked up in the
morphological mode. To do that, go in
“Info>Preferences>Morphological-mode dictionaries”, as shown on Figure
[fig-morpho4]. You can select as many dictionaries as you want, but they
MUST be ``.bin`` ones. Once this is done, you can apply your grammar and
get results. In order to specify that a dictionary-graph should be
looked up in the morphological mode, use option ``b`` or ``z``
(section [section-dictionary-graphs], Exporting produced entries as a
morphological-mode dictionary).

Dictionary-entry variables
~~~~~~~~~~~~~~~~~~~~~~~~~~

[dictionary-variables] You can set variables to information stored in
morphological-mode dictionaries. The initialization of such a variable
must be associated to a box that contains a pattern referring to
information stored in a morphological-mode dictionary, except for the
pattern ``<DIC>``. Set the output of the box with ``$xxx$`` where
``xxx`` is a valid variable name (cf.
section [section-using-variables]). That sets a special variable named
``xxx`` to the dictionary entry that matches with your pattern. In the
rest of the paths that contain the box, you can get the inflected form,
lemma and codes of the entry with ``$xxx.INFLECTED$``, ``$xxx.LEMMA$``
and ``$xxx.CODE$``, as shown on Figure [fig-morpho5]. You can also use
the following patterns:

-  ``$xxx.CODE.GRAM$``: provides only the first grammatical code,
   supposed to be the POS category

-  ``$xxx.CODE.SEM$``: provides all remaining grammatical codes, if any,
   separated with ``+``

-  ``$xxx.CODE.FLEX$``: provides all inflectional codes, if any,
   separated with ``:``

-  ``$xxx.CODE.ATTR=yyy$``: provides the value of an attribute-value
   pair contained in the semantic codes, i.e. the value ``zzz`` of the
   ``yyy`` attribute if there is a code of the form ``yyy=zzz``.

Dictionary-entry variables can be used even after the end of the
morphological mode, as shown on Figure [fig-morpho7]. They can also be
tested as explained in section [section-variables].

.. figure:: resources/img/fig6-17o.png
   :alt: Using a dictionary-entry variable[fig-morpho5]
   :width: 16.00000cm

   Using a dictionary-entry variable[fig-morpho5]

.. figure:: resources/img/fig6-17p.png
   :alt: Results of grammar of Figure [fig-morpho5] applied in MERGE
   mode [fig-morpho6]
   :width: 15.00000cm

   Results of grammar of Figure [fig-morpho5] applied in MERGE mode
   [fig-morpho6]

.. figure:: resources/img/fig6-17q.png
   :alt: Using a dictionary-entry variable in normal mode[fig-morpho7]
   :width: 15.50000cm

   Using a dictionary-entry variable in normal mode[fig-morpho7]

**Dictionary-entry variables in LocateTfst**

In grammars to be applied with ``LocateTfst`` (cf.
section [section-locate-tfst]), you have an extra feature. If you are
not in morphological mode, your grammar can extract information from a
lexical tag contained in the text automaton, and capture it into a
dictionary-entry variable. In your grammar, you have to set the output
of a box with ``$:xxx$``, where ``xxx`` is a valid variable name. In the
rest of the paths that contain the box, you can use ``xxx`` as a
dictionary-entry variable, in the same way as described above for the
morphological mode: you can get from this variable the inflected form,
lemma and codes of the entry, its POS code, semantic codes, inflectional
codes and the value ``zzz`` of the ``yyy`` attribute if there is a code
of the form ``yyy=zzz``.

Exploring grammar paths
-----------------------

It is possible to generate the paths recognized by a grammar, if they
are in finite number, for example to check that it correctly generates
the expected forms. For that, open the main graph of your grammar, and
ensure that the graph window is the active window (the active window has
a blue title bar, while the inactive windows have a gray title bar). Now
go to the “FSGraph” menu and then to the “Tools” menu, and click on
“Explore Graph paths”. The Window of figure [fig-explore-graph-paths]
appears.

.. figure:: resources/img/fig6-18.png
   :alt: Exploring the paths of a grammar[fig-explore-graph-paths]
   :width: 10.40000cm

   Exploring the paths of a grammar[fig-explore-graph-paths]

The upper box contains the name of the main graph of the grammar to be
explored. The following options are connected to the outputs of the
grammar and to subgraph calls:

-  “Ignore outputs”: outputs are ignored;

-  “Separate inputs and outputs”: outputs are displayed after inputs
   (`` a b c / A B C``);

-  “Merge inputs and outputs”: each output is emitted immediately after
   the input to which it corresponds (``a/A b/B c/C``).

-  “Only paths”: calls to subgraphs are explored recursively;

-  “Do not explore subgraphs recursively”: calls to subgraphs are
   printed but not explored recursively.

If the option “Maximum number of sequences” is activated, the specified
number will be the maximum number of generated paths. If the option is
not selected, all paths will be generated, if they are in finite number.

Here you see what is created for the graph shown on Figure [fig-glace]
with default settings (ignoring outputs, limit = 100 paths):

``<NB> <boule> de glace à la pistache``

``<NB> <boule> de glace à la fraise``

``<NB> <boule> de glace à la vanille``

``<NB> <boule> de glace vanille``

``<NB> <boule> de glace fraise``

``<NB> <boule> de glace pistache``

``<NB> <boule> de pistache``

``<NB> <boule> de fraise``

``<NB> <boule> de vanille``

``glace à la pistache``

``glace à la fraise``

``glace à la vanille``

``glace vanille``

``glace fraise``

``glace pistache``

.. figure:: resources/img/fig6-19.png
   :alt: Sample graph [fig-glace]
   :width: 10.90000cm

   Sample graph [fig-glace]

Graph collections
-----------------

It can happen that one wants to apply several grammars located in the
same directory. For that, it is possible to automatically build a
grammar starting from a file tree structure. Let us suppose for example
that one has the following tree structure:

-  *Dicos*:

   -  *Banque*:

      -  ``carte.grf``

   -  *Nourriture*:

      -  ``eau.grf``

      -  ``pain.grf``

   -  ``truc.grf``

If one wants to gather all these grammars in only one, one can do it
with the “Build Graph Collection” command in the “FSGraph Tools”
sub-menu. One configures this operation by means of the window seen in
figure [fig-build-graph-collection].

.. figure:: resources/img/fig6-20.png
   :alt: Building a graph collection[fig-build-graph-collection]
   :width: 9.00000cm

   Building a graph collection[fig-build-graph-collection]

In the “Source Directory” field, select the root directory which you
want to explore (in our example, the directory *Dicos*). In the field
“Resulting GRF grammar”, enter the name of the produced grammar.

WARNING: Do not place the output grammar in the tree structure which you
want to explore, because in this case the program will try to read and
to write simultaneously in this file, which will cause a crash.

When you click on “OK”, the program will copy the graphs to the
directory of the output grammar, and will create subgraphs corresponding
to the various sub-directories, as one can see in
figure [fig-graph-collection], which shows the output graph generated
for our example.

One can observe that one box contains the calls with subgraphs
corresponding to sub-directories (here directories *Banque* and
*Nourriture*), and that the other box calls all the graphs which were in
the directory (here the graph ``truc.grf``).

.. figure:: resources/img/fig6-21.png
   :alt: Main graph of a graph collection[fig-graph-collection]
   :width: 11.00000cm

   Main graph of a graph collection[fig-graph-collection]

Rules for applying transducers
------------------------------

This section describes the rules for the application of transducers
along with the operations of preprocessing and the search for patterns.
The following does not apply to inflection graphs and normalization
graphs for ambiguous forms.

Insertion to the left of the matched pattern
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

When a transducer is applied in REPLACE mode, the output replaces the
sequences that have been read in the text. When a box in a transducer
has no output, it is processed as if it had an ``<E>`` output. In MERGE
mode, the output is inserted to the left of the recognized sequences.

.. figure:: resources/img/fig6-22.png
   :alt: Example of a transducer[fig-transducer-example]
   :width: 7.20000cm

   Example of a transducer[fig-transducer-example]

Look at the transducer in Figure [fig-transducer-example]. If this
transducer is applied to the novel *Ivanhoe* by Sir Walter Scott in
MERGE mode, the following concordance is obtained.

.. figure:: resources/img/fig6-23.png
   :alt: Concordance obtained in MERGE mode with the transducer of
   figure [fig-transducer-example]
   :width: 14.40000cm

   Concordance obtained in MERGE mode with the transducer of
   figure [fig-transducer-example]

Application while advancing through the text
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

During the preprocessing operations, the text is modified as it is being
read. In order to avoid the risk of infinite loops, it is necessary that
the sequences that are produced by a transducer will not be re-analyzed
by the same one. Therefore, whenever a sequence is inserted into the
text, the application of the transducer is continued after that
sequence. This rule only applies to preprocessing transducers, because
during the application of syntactic graphs, the transductions do not
modify the processed text but a concordance file which is distinct from
the text.

Priority of the leftmost match
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

During the application of a local grammar, overlapping occurrences are
all indexed. Note that we talk about real overlapping occurrences like
``abc`` and ``bcd``, not nested occurrences like ``abc`` and ``bc``.
During the construction of the concordance all these overlapping
occurrences are presented (cf. Figure [fig-overlappping-occurrences]).

.. figure:: resources/img/fig6-24.png
   :alt: Overlapping occurrences in
   concordance[fig-overlappping-occurrences]
   :width: 13.00000cm

   Overlapping occurrences in concordance[fig-overlappping-occurrences]

On the other hand, if you modify a text instead of constructing a
concordance, it is necessary to choose among these occurrences the one
that will be taken into account. Unitex applies the following priority
rule for that purpose: the leftmost sequence is used.

If this rule is applied to the three occurrrences of the preceding
concordance, the occurrence overlaps with . The first is retained
because this is the leftmost occurrence and is eliminated. The following
occurrence of is no longer in conflict with and can therefore appear in
the result:

``...Don, there extended large forest...``

The rule of priority of the leftmost match is applied only when the text
is modified, be it during preprocessing or after the application of a
syntactic graph (cf. section [section-modifying-text]).

Priority of the longest match
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

During the application of a syntactic graph it is possible to choose if
the priority should be given to the shortest or the longest sequences or
if all sequences should be retained. During preprocessing, the priority
is always given to the longest sequences.

Transducer outputs with variables
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

As we have seen in Section [section-using-variables], it is possible to
use input variables to store some text that has been analyzed by a
grammar. Such variables can be used in preprocessing graphs and in
syntactic graphs.

.. figure:: resources/img/fig6-25.pdf
   :alt: Definition of an input variable in a
   subgraph[fig-variable-definition]
   :width: 16.00000cm

   Definition of an input variable in a
   subgraph[fig-variable-definition]

You have to give names to the variables you use. These names can contain
non-accented lower-case and upper-case letters between ``A`` and ``Z``,
digits and the character ``_`` (underscore).

In order to delimit the zone to be stored in an input variable, either
use the button with red parentheses in the toolbar above the graph
(Section [toolbar-commands]) or create two boxes, one containing the
name of the variable enclosed in the characters ``$`` and ``(`` for the
beginning of the zone and the other in ``$`` and ``)`` for the end. In
order to use a variable in a transducer output, its name must be
surrounded by the character ``$`` (cf.
Figure [fig-variable-definition]).

Variables are global. This means that you can define a variable in a
graph and reference it in another as is illustrated in the graphs of
Figure [fig-variable-definition]. If the graph ``TitleName`` is applied
in MERGE mode to the text *Ivanhoe*, the concordance in Figure [fig6-14]
is obtained.

.. figure:: resources/img/fig6-26.png
   :alt: Concordance obtained by application of graph ``TitleName`` of
   Fig. [fig-variable-definition][fig6-14]
   :width: 13.00000cm

   Concordance obtained by application of graph ``TitleName`` of
   Fig. [fig-variable-definition][fig6-14]

Outputs with variables can be used to move phrases. In fact, the
application of a transducer in REPLACE mode inserts only the produced
sequences into the text. In order to swap two phrases, you just have to
store them into variables and produce an output with these variables in
the desired order. Thus, the application of the transducer in
Figure [fig-swapping-words] in REPLACE mode to the text *Ivanhoe*
results in the concordance of Figure [fig-no-space-problem].

.. figure:: resources/img/fig6-27.png
   :alt: Swapping words using two input variables[fig-swapping-words]
   :width: 11.30000cm

   Swapping words using two input variables[fig-swapping-words]

.. figure:: resources/img/fig6-28.png
   :alt: Result of the application of the transducer in
   figure [fig-swapping-words][fig-no-space-problem]
   :width: 13.40000cm

   Result of the application of the transducer in
   figure [fig-swapping-words][fig-no-space-problem]

If the beginning or the end of variable does not conform to the syntax
above (end of a variable before its beginning, or absence of the
beginning or end of a variable), by default, it will be ignored during
the emission of outputs. See section [section-advanced-search-options]
for other variable error policies.

There is no limit to the number of possible variables.

Input variables can be nested and even overlap as is shown in
figure [fig-overlapping-variables].

.. figure:: resources/img/fig6-29.png
   :alt: Overlapping input variables[fig-overlapping-variables]
   :width: 15.00000cm

   Overlapping input variables[fig-overlapping-variables]

Output variables
----------------

Input variables declared either with the red-parentheses button or with
``$xxx(`` and ``$xxx)`` capture portions of the input text. It is also
possible to capture portions of the outputs produced by your grammar.
This is done with output variables. Such variables are declared either
with the button with blue parentheses in the toolbar above the graph
(Section [toolbar-commands]) or with ``$|xxx(`` and ``$|xxx)``. The
resulting boxes appear in blue as shown on Figure
[fig-output-variables]. This example grammar applied to *Ivanhoe* will
produce in MERGE mode the concordance shown on Figure
[fig-output-variables-concord].

.. figure:: resources/img/fig6-17r.png
   :alt: Output variables[fig-output-variables]
   :width: 8.00000cm

   Output variables[fig-output-variables]

.. figure:: resources/img/fig6-17s.png
   :alt: Concordance obtained with grammar of Figure
   [fig-output-variables][fig-output-variables-concord]
   :width: 15.00000cm

   Concordance obtained with grammar of Figure
   [fig-output-variables][fig-output-variables-concord]

When an output variable is being initialized, the output sequences of
the transducer are not emitted into the output for the current
occurrence; they are just stored into the pending output variable(s).
For instance, the outputs ``ADJ`` and ``NOUN`` of
Figure [fig-output-variables] have not been inserted to the left of the
input text on Figure [fig-output-variables-concord]. Outputs are
processed before being stored, so that if an output string contains
something like ``$A.LEMMA$``, the output variable will actually not
contain this raw string but the lemma associated to variable ``A``.

Output variables only capture explicit outputs produced by your grammar.
Thus, even in MERGE mode, output variables never capture the input text
(Figures [fig-output-variables] and [fig-output-variables-concord]).

When a box redefines a variable that had already been defined, the new
value overrides the previous one. Thus, if the variable is defined in a
loop, the value of the variable just after the loop depends on the last
iteration of the loop.

Operations on variables
-----------------------

Testing variables
~~~~~~~~~~~~~~~~~

It is possible to test whether a variable has been defined or not, in
order to block the current matching operation if the condition is not
verified. This is done by inserting the sequence ``$xxx.SET$`` in the
output of a graph box. Then, if a variable named ``xxx`` has been
defined, this sequence will be ignored in the output and the matching
process will go on; otherwise, matching will be stopped and the program
will backtrack. This operates on input variables as well as on output
variables and dictionary-entry variables defined in morphological mode.
You can check out if a variable has not been defined in the same way
using ``$xxx.UNSET$``. Figure [fig-testing-a-variable] shows a graph
that use a such a variable test. Figure [fig-testing-a-variable-results]
shows results obtained with this graph in MERGE mode.

.. figure:: resources/img/fig6-29b.png
   :alt: Testing a variable[fig-testing-a-variable]
   :width: 9.00000cm

   Testing a variable[fig-testing-a-variable]

.. figure:: resources/img/fig6-29c.png
   :alt: Results of a variable test[fig-testing-a-variable-results]
   :width: 10.00000cm

   Results of a variable test[fig-testing-a-variable-results]

Comparing variables
~~~~~~~~~~~~~~~~~~~

Another kind of test you can perform consists of variable comparison.
You can compare a variable of any kind (whether an input variable, an
output variable or a dictionary-entry variable) against a constant
string or another variable. To do that, insert in the output of a graph
box a sequence with the following syntax:

``$abc.EQUAL=xyz$``

This test acts like a switch that will block the grammar exploration if
the value of variable ``abc`` is different from the value of variable
``xyz``. Note that for dictionary-entry variables, what is used in the
test is the inflected form as found in the dictionary (beware of case
variations!). If you want to compare variable ``abc`` against the
constant string ``JKL``, use the following test:

``$abc.EQUAL=#JKL$``

You can also test if contents differ with ``UNEQUAL``.

If you want to compare variables so that case variations are ignored,
you can use the following tests:

| ``$abc.EQUALcC=xyz$``
| or
| ``$abc.UNEQUALcC=xyz$``

Querying variables
~~~~~~~~~~~~~~~~~~

You can search a dictionary-entry variable
(section [dictionary-variables]) for a ‘semantic code’ (in the sense of
section [section-DELAF-entry-syntax]). To do that, insert in the output
of a graph box a sequence with the following syntax:

``$abc.EQ=Conc$``

This test acts like a switch that will block the grammar exploration if
``Conc`` is not found among the ‘semantic codes’ of the dictionary-entry
variable ``abc``. You can search a variable for one code at a time. To
check several codes, chain several boxes.

This feature is used in large sets of morphological dictionary-graphs in
order to dissociate in distinct boxes a check for a grammatical code and
subsequent checks for semantic codes, as in
:raw-latex:`\cite{paumier_nam_2014}`, page 486. The grammatical code is
checked with the aid of a lexical mask, and the semantic codes are
checked by searching the corresponding dictionary-entry variable. Such
dissociation may speed up the application of the graphs if:

-  all the graphs are directly or indirectly invoked from a single main
   graph,

-  the main graph is compiled and flattened (see
   section [flatten-section]),

-  the box with the lexical mask is common to more paths than the boxes
   searching the dictionary-entry variable for the semantic codes. [3]_

Applying graphs to texts
------------------------

This section only applies to syntactic graphs.

Configuration of the search
~~~~~~~~~~~~~~~~~~~~~~~~~~~

In order to apply a graph to a text, you open the text, then click on
“Locate Pattern...” in the “Text” menu, or press <Ctrl+L>. You can then
configure your search in the window shown in figure [fig-regexp-frame].

In the “Locate pattern in the form of” field, choose “Graph” and select
your graph by clicking on the “Set” button. You can choose a graph in
``.grf`` format (Unicode Graphs) or a compiled graph in ``.fst2`` format
(Unicode Compiled Graphs). If your graph is a ``.grf`` one, Unitex will
compile it automatically before starting the search. If you click on
“Activate debug mode”, the concordance will be displayed in a window in
which you will also find the automaton and, for each match, the list of
states of the path that matches it. This window is described with more
details in section [section-debug-mode].

The “Index” field allows to select the recognition mode.

-  “Shortest matches” : give precedence to the shortest matches;

-  “Longest matches” : give precedence to the longest sequences. This is
   the default mode;

-  “All matches” : give out all recognized sequences.

The “Search limitation” field allows you to limit the search to a
certain number of occurrences. By default, the search is limited to the
200 first occurrences.

.. figure:: resources/img/fig6-30.png
   :alt: Locate pattern Window[fig-regexp-frame]
   :width: 9.00000cm

   Locate pattern Window[fig-regexp-frame]

The “Grammar outputs” field concerns transducers. The “Merge with input
text” mode allows you to insert the output sequences in input sequences.
The “Replace recognized sequences” mode allows you to replace the
recognized sequences with the produced sequences. The third mode ignores
all outputs. This latter mode is used by default.

In the “Search algorithm” frame, you can specify wether you want to
perform the locate operation on the text using the Locate program or on
the text automaton with LocateTfst. By default, search is done with the
Locate program, as Unitex always did until now. If you want to use
LocateTfst, please read dedicated section [section-locate-tfst]. After
you have selected the parameters, click on “SEARCH” to start the search.

Advanced search options
~~~~~~~~~~~~~~~~~~~~~~~

[section-advanced-search-options] If you select the “Advanced options”
tab, you will see the frame shown on Figure [fig6-advanced-options1].

.. figure:: resources/img/fig6-advanced-options1.png
   :alt: Advanced search options[fig6-advanced-options1]
   :width: 9.00000cm

   Advanced search options[fig6-advanced-options1]

The “Ambiguous output policy” option can be illustrated with the graph
shown on Figure [fig6-advanced-options2].

.. figure:: resources/img/fig6-advanced-options2.png
   :alt: A graph with ambiguous outputs[fig6-advanced-options2]
   :width: 9.00000cm

   A graph with ambiguous outputs[fig6-advanced-options2]

When a determiner is followed by a word that can be either adjective or
noun, it can produce two distinct outputs for the same text input
sequence (the transducer is said to be ambiguous). If we apply this
graph on *Ivanhoe* with the “Allow ambiguous outputs” option (the
default one), we will obtain the text order concordance shown of Figure
[fig6-advanced-options3]. As you can see, two outputs have been produced
for the input sequence *the noble*.

.. figure:: resources/img/fig6-advanced-options3.png
   :alt: Ambiguous outputs for *the noble*\ [fig6-advanced-options3]
   :width: 8.80000cm

   Ambiguous outputs for *the noble*\ [fig6-advanced-options3]

At the opposite, with the “Forbid ambiguous outputs” option, we will
obtain the text order concordance shown of Figure
[fig6-advanced-options4], with only one arbitrarily chosen output for
the input sequence *the noble*.

.. figure:: resources/img/fig6-advanced-options4.png
   :alt: Single output for *the noble*\ [fig6-advanced-options4]
   :width: 9.00000cm

   Single output for *the noble*\ [fig6-advanced-options4]

The “Variable error policy” option allows you to specify what
``Locate``/``LocateTfst`` is supposed to do when an output is found that
contains a reference to a variable that has not been correctly defined.
Note that this parameter has no effect if outputs are to be ignored. For
instance, let us consider the graph shown on Figure
[fig6-advanced-options5].

.. figure:: resources/img/fig6-advanced-options5.png
   :alt: A variable *A* that may be undefined[fig6-advanced-options5]
   :width: 9.00000cm

   A variable *A* that may be undefined[fig6-advanced-options5]

With the “Ignore variable errors” option, *A* will just be ignored, as
if it had an empty content, as shown on Figure [fig6-advanced-options6].

.. figure:: resources/img/fig6-advanced-options6.png
   :alt:  variable *A* that may be undefined[fig6-advanced-options6]
   :width: 12.00000cm

    variable *A* that may be undefined[fig6-advanced-options6]

With the “Exit on variable error” option, ``Locate``/``LocateTfst`` will
exit with an error message, as shown on Figure [fig6-advanced-options7].

.. figure:: resources/img/fig6-advanced-options7.png
   :alt: Exiting on variable error[fig6-advanced-options7]
   :width: 9.00000cm

   Exiting on variable error[fig6-advanced-options7]

With the “Backtrack on variable error” option, ``Locate``/``LocateTfst``
will stop exploring the current path in the grammar. Thus, variables
play the role of switches that cut paths when variables are undefined.
For instance, the application of grammar [fig6-advanced-options5] will
only produce matches containing an adjective, as shown on Figure
[fig6-advanced-options8].

.. figure:: resources/img/fig6-advanced-options8.png
   :alt: Backtracking on variable error[fig6-advanced-options8]
   :width: 13.00000cm

   Backtracking on variable error[fig6-advanced-options8]

Concordance
~~~~~~~~~~~

The result of a search is an index file that contains the positions of
all encountered occurrences. The window of
Figure [fig-configuration-display-occurrences] lets you choose whether
to construct a concordance or modify the text.

In order to display a concordance, you have to click on the “Build
concordance” button. You can parameterize the size of left and right
contexts in characters. You can also choose the sorting mode that will
be applied to the lines of the concordance in the “Sort According to”
menu. For further details on the parameters of concordance construction,
refer to section [section-display-occurrences].

.. figure:: resources/img/fig6-31.png
   :alt: Configuration for displaying the encountered occurrences
   [fig-configuration-display-occurrences]
   :width: 10.00000cm

   Configuration for displaying the encountered occurrences
   [fig-configuration-display-occurrences]

The concordance is produced in the form of an HTML file. You can
parameterize Unitex so that concordance files can be read using a web
browser (cf. section [section-display-occurrences]).

If you display concordances with the window provided by Unitex, you can
access a recognized sequence in the text by clicking on the occurrence.
If the text window is not iconified and the text is not too long to be
displayed, you see the selected sequence appear (cf.
Figure [fig-back-to-text]).

.. figure:: resources/img/fig6-32.png
   :alt: Selection of an occurrence in the text[fig-back-to-text]
   :width: 13.50000cm

   Selection of an occurrence in the text[fig-back-to-text]

Furthermore, if the text automaton has been constructed, and if the
corresponding window is not iconified, clicking on an occurrence selects
the automaton of the sentence that contains this occurrence.

Modification of the text
~~~~~~~~~~~~~~~~~~~~~~~~

You can choose to modify the text instead of constructing a concordance.
In order to do that, type a file name in the “Modify text” field in the
window of Figure [fig-configuration-display-occurrences]. This file has
to have the extension ``.txt``.

If you want to modify the current text, you have to choose the
corresponding ``.txt`` file. If you choose another file name, the
current text will not be affected. Click on the “GO” button to start the
modification of the text. The precedence rules that are applied during
these operations are described in
section [section-applying-transducers-rules].

After this operation, the resulting file is a copy of the text in which
transducer outputs have been taken into account. Normalization
operations and splitting into lexical units are automatically applied to
this text file. The existing text dictionaries are not modified. Thus,
if you have chosen to modify the current text, the modifications will be
effective immediately. You can then start new searches on the text.

WARNING: if you have chosen to apply your graph ignoring the transducer
outputs, all occurrences will be erased from the text.

Extracting occurrences
~~~~~~~~~~~~~~~~~~~~~~

To extract from a text all sentences containing matches, set the name of
your output text file using the “Set File” button in the “Extract units”
frame (Figure [fig-configuration-display-occurrences]). Then, click on
“Extract matching units”. At the opposite, if you click on “Extract
unmatching units”, all sentences that do not contain any match will be
extracted.

Comparing concordances
~~~~~~~~~~~~~~~~~~~~~~

With the “Show differences with previous concordance” option, you can
compare the current concordance with the previous one. The
``ConcorDiff`` program builds both concordances according to text order
and compares them line by line. The result is an HTML page that presents
alternatively lines from both concordances, leaving an empty line when a
match appears in only one concordance. Lines are greyed for the previous
concordance and left with a white background for the current one. In
each line, only matched tokens are coloured. You can click on each match
to open the text at its position. Figure [fig-concordiff] gives an
example.

.. figure:: resources/img/fig6-33.png
   :alt: Example of a concordance comparison[fig-concordiff]
   :width: 10.00000cm

   Example of a concordance comparison[fig-concordiff]

Blue indicates that an occurrence is common to the two concordances. Red
indicates that a match is common but with a different range, i.e. the
two matches only overlap partially. Green indicates an occurrence that
appears in only one concordance.

If you have no previous concordance the button is deactivated.

Debug mode
~~~~~~~~~~

When you apply a graph to a text with the Locate menu in the window
shown in figure [fig-regexp-frame], if you activate the debug mode in
the “Locate pattern in the form of” field, the concordance will be
displayed in a special window such as in figure [fig-debug-mode],
divided into three parts :

.. figure:: resources/img/fig6-34.png
   :alt: The Concordance window in debug mode[fig-debug-mode]
   :height: 9.00000cm

   The Concordance window in debug mode[fig-debug-mode]

In the top right part of the window is the concordance. It is identical
to the classical concordance in which the sequences matched by the graph
appear in blue.

In the bottom right you will find the graph used for the search.

In the left side of the window is a table of 3 columns : “Tag”, “output”
and “matched”. Each token of the matched sequence appear in the
“matched” column, the Tag column contains what is in the box of the
automaton that matched it, and if this box has any output, it will
appear in the “output” column.

For each matched sequence in the concordance, if you click on its line
in the concordance, the table on the left will be actualized and
clicking on a row of the table will colour the corresponding box in the
graph. This will help you to see, for each occurrence of a matched
sequence in the text, which path in the automaton recognized it. A red
number above each box indicates the number of sequences in the text in
which that box matched a token.

When you apply a graph in debug mode through the
``Text > Locate Pattern`` menu, the system compiles it into a ``fst2``
file in a special debug-mode format, which is not supported by CasSys.
See section [graphs-for-cassys] to solve this problem.

.. [1]
   From version 3.1beta, revision 4072, October 2, 2015.

.. [2]
   The text dictionaries are compiled during initial application of
   dictionaries (section [section-applying-dictionaries]), not during
   search for patterns.

.. [3]
   Thus, the lexical mask provokes a search in morphological-mode
   dictionaries which is performed once before several searches for
   semantic codes. If you check the grammatical code and a semantic code
   by the same lexical mask, these masks are more numerous in the
   complete grammar and they provoke more searches in morphological-mode
   dictionaries.
