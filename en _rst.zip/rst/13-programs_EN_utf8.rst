Use of external programs
========================

This chapter presents the use of the different programs of which Unitex
is composed. These programs, which can be found in the ``Unitex/App``
directory, are automatically called by the interface (in fact,
``UnitexToolLogger`` is actually called, in order to reduce
significantly the size of the downloadable zip file). It is possible to
see the commands that have been executed by clicking on “Info>Console”.
It is also possible to see the options of the different programs on
“Info>Help on commands” (see Figure [fig-help]). Note that that all
Unitex programs support the ``-h``/``--help`` option.

.. figure:: resources/img/fig11-1.png
   :alt: Help on commands[fig-help]
   :width: 14.00000cm

   Help on commands[fig-help]

WARNING: many programs use the text directory (``my_text_snt``). This
directory is created by the graphical interface after the normalization
of the text. If you work with the command line, you have to create the
directory manually before the execution of the program ``Normalize``.

WARNING (2): whenever a parameter contains spaces, it needs to be
enclosed in quotation marks so it will not be considered as multiple
parameters.

WARNING (3): many programs need an ``Alphabet.txt`` file. For all those
programs, this information can be omitted. In that case, a default
definition of letters is used (see ``u_is_letter`` in ``Unicode.cpp``
source file).

Creating log files
------------------

[section-creating-log-files]

.. figure:: resources/img/fig11-1a.png
   :alt: Logging configuration[fig-logging-config]
   :width: 10.00000cm

   Logging configuration[fig-logging-config]

You can create log files of external program launches. These log files
can be useful for debugging or regression tests. You just need to enable
this feature in the Preferences frame. You have to choose a log
directory where all log files will be stored and to select the “Produce
log” check box. Clicking on the “Clear all logs” button will remove all
log files contained in this directory, if any. Then, any further program
execution will produce a ``unitex_log_XXX.ulp`` file located in the log
directory. ``XXX`` stands for the log number that can be found in the
console (see next section).

The console
-----------

[section-console] When Unitex launches an external program, the invoked
command line is stored in the console. To see it, click on
“Info>Console”. When a command emits no error message, it is displayed
with a green icon. Otherwise, the icon is a red triangle that you can
click on to see the error messages, as shown on Figure [fig-console].
This is useful when an error message occurs so fast that you cannot read
it. If a command has been logged, its log number appears in the second
column. Note that you can export all the commands diplayed in the
console to the clipboard with Ctrl+C.

.. figure:: resources/img/fig11-2.png
   :alt: Console[fig-console]
   :width: 15.00000cm

   Console[fig-console]

Unitex JNI
----------

[section-unitex-JNI]

You can use Unitex as a Java Native interface by including the following
imports :

::

    import fr.umlv.unitex.jni.UnitexJni;
    import java.io.*;
    import fr.umlv.unitex.*;

This will allow you to load .bin, .fst2 and alphabet files and to keep
them in memory persistently. You use the filename created by
loadPersistent\* function.

::

    String persistentAlphabet = UnitexJni.loadPersistentAlphabet("/.../unitex/French/Alphabet.txt");
    String persistentFst2 = UnitexJni.loadPersistentFst2("/.../unitex/French/Dela/fogg-r.fst2");
    String persistentDictionary = UnitexJni.loadPersistentDictionary(
            "/.../unitex/French/Dela/communesFR+.bin");

Text file encoding parameters
-----------------------------

[section-text-file-encoding-parameters] Unitex uses Unicode for text
file[unicode-encoding]. All program which read or write text file share
same encoding parameters. Possible format are utf16le-bom,
utf16le-no-bom, utf16be-bom, utf16be-no-bom, utf8-bom, utf8-no-bom, for
Unicode Big-Endian, Little-Endian and UTF-8, with or without Unicode
byte order mark at the beginning of the file. For the input format, you
can specify several \*-bom encoding separated by comma, but only one
\*-no-bom encoding.

**OPTIONS:**

-  ``-k=ENCODING``/``--input_encoding=ENCODING``: input text file
   format. Can contain several value, separated by a comma;

-  ``-q=ENCODING``/``--output_encoding=ENCODING``: output text file
   format.

By default, value are
``--input_encoding=utf16le-bom,utf16be-bom,utf8-bom --output_encoding=utf16le-bom``.

BuildKrMwuDic
-------------

``BuildKrMwuDic [OPTIONS] dic``

This program generates a MWU dictionary graph from a text table ``dic``
describing each component of each MWU.

**OPTIONS:**

-  ``-o GRF``/``--output=GRF``: .grf file to produce;

-  ``-d DIR``/``--directory=DIR``: inflection directory containing the
   inflection graphs required to produce morphological variants of
   roots;

-  ``-a ALPH``/``--alphabet=ALPH``: alphabet file to use;

-  ``-b BIN``/``--binary=BIN``: .bin simple word dictionary to use.

CasSys
------

``Cassys [OPTIONS] <snt>``

This program applies an ordered list of grammars to a text and
constructs an index of the occurrences found.

**OPTIONS:**

-  ``-a ALPH``/``--alphabet=ALPH``: the language alphabet file

-  ``-r X``/``--transducer_dir=X``: take tranducer on directory X (so
   you don’t specify full path for each transducer; note that X must be
   (back)slash terminated

-  ``-l TRANSDUCERS_LIST``/``--transducers_list=TRANSDUCERS_LIST``: the
   transducers list file with their output policy

-  ``-s transducer.fst2``/``--transducer_file=transducer.fst2``: a
   transducer to apply

-  ``-m output_policy``/``--transducer_policy=output_policy``: the
   output policy of the transducer specified

-  ``-t TXT``/``--text=TXT``: the text file to be modified, with
   extension .snt;

-  ``-i``/``--in_place``: mean uses the same csc/snt directories for
   each transducer

-  ``-d``/``--no_create_directory``: mean the all snt/csc directories
   already exist and don’t need to be created

-  ``-g minus``/``--negation_operator=minus``: uses minus as negation
   operator for Unitex 2.0 graphs

-  ``-g tilde``/``--negation_operator=tilde``: uses tilde as negation
   operator (default)

-  ``-h``/``--help``: display this help

CasSys applies a list of grammar to a text and saves the matching
sequence index in a file named concord.ind" stored in the text
directory. The target text file has to be a preprocessed snt file with
its \_snt/ directory. The transducer list file is a file in which each
line contains the path to a transducer followed by the output policy to
be applied to this transducer.

Instead a list file, you can specify each file and each output policy by
a set of couple of -s/–transducer\_file and -m/–transducer\_policy
argument to enumerate the list

The policy may be MERGE or REPLACE.

The file option, the alphabet option and the transducer list file option
are mandatory

As the locate pattern program, this program saves the references to the
found occurrences in a file called concord.ind stored in the \_snt
directory of the text. The file concord.ind produced is in the same
format as described in the chapter [chap-file-formats] , but the cascade
may be constituted of graphs applied in merge or replace mode so the #M
or #R at the first line of the file concord.ind has no sense in this
context.

CheckDic
--------

``CheckDic [OPTIONS] dic``

This program carries out the verification of the format of a dictionary
of DELAS or DELAF type. ``dic`` corresponds to the name of the
dictionary that is to be verified.

**OPTIONS:**

-  ``-f``/``--delaf``: checks an inflected dictionary;

-  ``-s``/``--delas``: checks a non inflected dictionary;

-  ``-r``/``--strict``: strict syntax checking against unprotected dot
   and comma;

-  ``-t``/``--tolerate``: tolerates unprotected dot and comma (default);

-  ``-n``/``--no_space_warning``: tolerates spaces in
   grammatical/semantic/inflectional codes;

-  ``-p``/``--skip_path``: does not display the full path of the
   dictionary (useful for consistent log files across several systems);

-  ``-a ALPH``/``--alphabet=ALPH``: specifies the alphabet file to use.

The program checks the syntax of the lines of the dictionary. It also
creates a list of all characters occurring in the inflected and
canonical forms of words in the text, the list of grammatical codes and
syntax, as well as the list of inflection codes used. The results of the
verification are stored in a file called ``CHECK_DIC.TXT``.

Selecting strict syntax checking detects using unprotected dot in
inflected form, or unprotected comma in lemma. The ``--tolerate`` option
acts like Unitex 2.0 and lower and does not detect them.

Compress
--------

[section-compress] ``Compress [OPTIONS] dictionary``

**OPTIONS:**

-  ``-o BIN``/``--output=BIN``: sets the output file. By default, a file
   ``xxx.dic`` will produce a file ``xxx.bin``;

-  ``-f``/``--flip``: indicates that the inflected and canonical forms
   should be swapped in the compressed dictionary. This option is used
   to construct an inverse dictionary which is necessary for the program
   ``Reconstrucao``;

-  ``-s``/``--semitic``: indicates that the semitic compression
   algorithm should be used. Setting this option with semitic languages
   like Arabic significantly reduces the size of the output dictionary.

-  ``--v1``: produces an old style .bin file

-  ``--v2``: produces a new style .bin file, with no file size
   limitation to 16 Mb and a smaller size (default)

This program takes a DELAF dictionary as a parameter and compresses it.
The compression of a dictionary ``dico.dic`` produces two files:

-  ``dico.bin``: a binary file containing the minimum automaton of the
   inflected forms of the dictionary;

-  ``dico.inf``: a text file containing the compressed forms required
   for the reconstruction of the dictionary lines from the inflected
   forms contained in the automaton.

For more details on the format of these files, see chapter
[chap-file-formats].

Concord
-------

[section-Concord] ``Concord [OPTIONS] <index>``

This program takes a concordance index file produced by the program
``Locate`` and produces a concordance. It is also possible to produce a
modified text version taking into account the transducer outputs
associated to the occurrences. Here is the description of the
parameters:

**OPTIONS:**

-  ``-f FONT``/``--font=FONT``: the name of the font to use if the
   output is an HTML file;

-  ``-s N``/``--fontsize=N``: the font size to use if the output is an
   HTML file. The font parameters are required if the output is an HTML
   file;

-  ``--only_ambiguous``: Only displays identical occurrences with
   ambiguous outputs, in text order.

-  ``--only_matches``: this option will force empty right and left
   contexts. Moreover, if used with -t/–text, Concord will not surround
   matches with tabulations

-  ``-l X``/``--left=X``: number of characters on the left of the
   occurrences (default=0). In Thai mode, this means the number of
   non-diacritic characters.

-  ``-r X``/``--right=X``: number of characters (non-diacritic ones in
   Thai mode) on the right of the occurrences (default=0). If the
   occurrence is shorter than this value, the concordance line is
   completed up to ``right``. If the occurrence is longer than the
   length defined by ``right``, it is nevertheless saved as whole.

   NOTE: For both ``--left`` and ``--right``, you can add the ``s``
   character to stop at the first ``{S}`` tag. For instance, if you set
   ``40s`` for the left value, the left context will end at 40
   characters at most, less if the ``{S}`` tag is found before.

**Sort order options:**

-  ``--TO``: order in which the occurrences appear in the text
   (default);

-  ``--LC``: left context for primary sort, then occurrence for
   secondary sort;

-  ``--LR``: left context, then right context;

-  ``--CL``: occurrence, then left context;

-  ``--CR``: occurrence, then right context;

-  ``--RL``: right context, then left context;

-  ``--RC``: left context, then occurrence.

For details on the sorting modes, see section
[section-display-occurrences].

**Output options:**

-  ``-H``/``--html``: produces a concordance in HTML format encoded in
   UTF-8 (default);

-  ``-t``/``--text``: produces a concordance in Unicode text format;

-  ``-g SCRIPT``/``--glossanet=SCRIPT``: produces a concordance for
   GlossaNet in HTML format. The HTML file is encoded in UTF-8;

-  ``-p SCRIPT``/``--script=SCRIPT``: produces a HTML concordance file
   where occurrences are links described by ``SCRIPT``. For instance, if
   you use

   ``-phttp://www.google.com/search?q=``, you will obtain a HTML
   concordance file where occurrences are hyperlinks to Google queries;

-  ``-i``/``--index``: produces an index of the concordance, made of the
   content of the occurrences (with the grammar outputs, if any),
   preceded by the positions of the occurrences in the text file given
   in characters;

-  ``-u`` ``offsets``/``--uima=offsets``: produces an index of the
   concordance relative to the original text file, before any Unitex
   operation. Offsets is supposed to be the file produced by Tokenize’s
   ``--output_offsets`` option

-  ``--PRLG=X,Y``: produces a concordance for PRLG corpora where each
   line is prefixed by information extracted with Unxmlize’s ``--PRLG``
   option. X is the file produced by Unxmlize’s ``--PRLG`` option and Y
   is the file produced by Tokenize’s ``--output_offsets`` option. Note
   that if this option is used in addition with ``-u``, the Y argument
   oferrides the argument of ``-u``;

-  ``-e``/``--xml``: produces xml index of the concordance;

-  ``-w``/``--xml-with-header``: produces xml index of the concordance
   with full xml header;

-  ``-A``/``--axis``: quite the same as ``--index``, but the numbers
   represent the median character of each occurrence. Fore more
   information, see :raw-latex:`\cite{axis}`;

-  ``-x``/``--xalign``: another index file, used by the text alignment
   module. Each line is made of 3 integers :math:`X` :math:`Y` :math:`Z`
   followed by the content of the occurrence. :math:`X` is the sentence
   number, starting from 1. :math:`Y` and :math:`Z` are the starting and
   ending positions of the occurrence in the sentence, given in
   characters;

-  ``-m TXT``/``--merge=TXT``: indicates to the program that it is
   supposed to produce a modified version of the text and save it in a
   file named ``TXT`` (see section [section-modifying-text]).

**Other options:**

-  ``-d DIR``/``--directory=DIR``: indicates to the program that it must
   not work in the same directory than ``<index>`` but in ``DIR``;

-  ``-a ALPH``/``--alphabet=ALPH``: alphabet file used for sorting;

-  ``-T``/``--thai``: option to use for Thai concordances.

The result of the application of this program is a file called
``concord.txt`` if the concordance was constructed in text mode, a file
called ``concord.html`` if the output mode was ``--html``,
``--glossanet`` or ``--script``, and a text file with the name defined
by the user of the program if the program has constructed a modified
version of the text.

In ``--html`` mode, the occurrence is coded as a hypertext link. The
reference associated to this link is of the form ``<a href="X Y Z">``.
``X`` et ``Y`` represent the beginning and ending positions of the
occurrence in characters in the file ``text_name.snt``. ``Z`` represents
the number of the sentence in which the occurrence was found.

ConcorDiff
----------

``ConcorDiff [OPTIONS] <concor1> <concor2>``

This program takes two concordance files and produces an HTML page that
shows their differences (see section [section-comparing-concordances],
page ). ``<concor1>`` and ``<concor2>`` concordance index files must
have absolute names, because Unitex uses these names to deduce on which
text there were computed.

**OPTIONS:**

-  ``-o X``/``--out=X``: output HTML page;

-  ``-f FONT``/``--font=FONT``: name of the font to use in output HTML
   page;

-  ``-s N``/``--size=N``: font size to use in output HTML page.

-  ``-d/--diff_only``: don’t show identical sequences;

Convert
-------

``Convert [OPTIONS] <text_1> [<text_2> <text_3> ...]``

With this program you can transcode text files.

**OPTIONS:**

-  ``-s X``/``--src=X``: input encoding;

-  ``-d X``/``--dest=X``: output encoding (default=``LITTLE-ENDIAN``);

**Transliteration options (only for Arabic):**

-  ``-F``/``--delaf``: the input is a DELAF and we only want to
   transliterate the inflected form and the lemma;

-  ``-S``/``--delas``: the input is a DELAS and we only want to
   transliterate the lemma.

**Output options:**

-  ``-r``/``--replace``: input files are overwritten (default);

-  ``-o file``/``--output=file``: name of destination file (only one
   file to convert);

-  ``--ps=PFX``: input files are renamed with the ``PFX`` prefix
   (``toto.txt`` :math:`\Rightarrow` ``PFXtoto.txt``);

-  ``--pd=PFX``: ouput files are renamed with the ``PFX`` prefix;

-  ``--ss=SFX``: input files are named with the ``SFX`` suffix;
   (``toto.txt`` :math:`\Rightarrow` ``totoSFX.txt``);

-  ``--sd=SFX``: ouput files are named with the ``SFX`` suffix.

**HTML options:**

``Convert`` offers some special options dedicated to HTML files. You can
use a combination of the following options:

-  ``--dnc`` (Decode Normal Chars): things like ``&eacute;`` ``&#120;``
   and ``&#xF8;`` will be decoded as the single equivalent unicode
   character, except if it represents an HTML control character;

-  ``--dcc`` (Decode Control Chars): ``&lt;`` ``&gt;`` ``&amp;`` and
   ``&quot;`` will be decoded as ``<`` ``>`` ``&`` and the quote (the
   same for their decimal and hexadecimal representations);

-  ``--eac`` (Encode All Chars): every character that is not supported
   by the output encoding will be encoded as a string like ``&#457;``

-  ``--ecc`` (Encode Control Chars): ``<`` ``>`` ``&`` and the quote
   will be encoded by ``&lt;`` ``&gt;`` ``&amp;`` and ``&quot;``

All HTML options are deactivated by default.

**Other options:**

-  ``-m``/``--main-names``: prints the list of the encoding main names;

-  ``-a``/``--aliases``: prints the list of the encoding aliases;

-  ``-A``/``--all-infos``: prints all the information about all the
   encodings;

-  ``-i X``/``--info=X``: prints all the information about the encoding
   X.

The encodings can take values in the following list (non exhaustive, see
below):

``FRENCH``

``ENGLISH``

``GREEK``

``THAI``

``CZECH``

``GERMAN``

``SPANISH``

``PORTUGUESE``

``ITALIAN``

``NORWEGIAN``

``LATIN`` (default latin code page)

``windows-1252``: Microsoft Windows 1252 - Latin I (Western Europe &
USA)

``windows-1250``: Microsoft Windows 1250 - Central Europe

``windows-1257``: Microsoft Windows 1257 - Baltic

``windows-1251``: Microsoft Windows 1251 - Cyrillic

``windows-1254``: Microsoft Windows 1254 - Turkish

``windows-1258``: Microsoft Windows 1258 - Viet Nam

``iso-8859-1  ``: ISO 8859-1 - Latin 1 (Europe de l’ouest & USA)

``iso-8859-15 ``: ISO 8859-15 - Latin 9 (Western Europe & USA)

``iso-8859-2  ``: ISO 8859-2 - Latin 2 (Eastern and Central Europe)

``iso-8859-3  ``: ISO 8859-3 - Latin 3 (Southern Europe)

``iso-8859-4  ``: ISO 8859-4 - Latin 4 (Northern Europe)

``iso-8859-5  ``: ISO 8859-5 - Cyrillic

``iso-8859-7  ``: ISO 8859-7 - Greek

``iso-8859-9  ``: ISO 8859-9 - Latin 5 (Turkish)

``iso-8859-10 ``: ISO 8859-10 - Latin 6 (Nordic)

``next-step   ``: NextStep code page

``LITTLE-ENDIAN``

``BIG-ENDIAN``

``UTF8``

Dico
----

``Dico [OPTIONS] <dic_1> [<dic_2> <dic_3>...]``

This program applies dictionaries to a text. The text must have been cut
up into lexical units by the ``Tokenize`` program.

**OPTIONS:**

-  ``-t TXT``/``--text=TXT``: complete ``.snt`` text file name;

-  ``-a ALPH``/``--alphabet=ALPH``: the alphabet file to use;

-  ``-m DICS``/``--morpho=DICS``: this optional parameter indicates
   which morphological-mode dictionaries are to be used, if needed by
   some ``.fst2`` dictionaries. ``DICS`` represents a list of ``.bin``
   files (with full paths) separated with semi-colons;

-  ``-K``/``--korean``: tells ``Dico`` that it works on Korean;

-  ``-s``/``--semitic``: tells ``Dico`` that it works on a semitic
   language (needed if ``Dico`` has to compress a dictionary);

-  ``-u X``/``--arabic_rules=X``: specifies the Arabic typographic rule
   configuration file.

-  ``r X``/``--raw=X``: indicates that Dico should just produce one
   output file X containing both simple and compound words, without
   requiring a text directory. If X is omitted, results are displayed on
   the standard output.

``<dic_i>`` represents the path and name of a dictionary. The dictionary
must be a ``.bin`` dictionary (obtained with the ``Compress`` program)
or a dictionary graph in the ``.fst2`` format (see section
[section-applying-dictionaries], page ). It is possible to give
priorities to the dictionaries. For details see section
[section-dictionary-priorities].

The program ``Dico`` produces the following files, and saves them in the
directory of the text:

-  ``dlf``: dictionary of simple words in the text;

-  ``dlc``: dictionary of compound words in the text;

-  ``err``: list of unknown words in the text;

-  ``tags_err``: unrecognized simple words that are not matched by the
   ``tags.ind`` file;

-  ``tags.ind`` : sequences to be inserted in the text automaton (see
   section [section-dictionary-graphs], page );

-  ``stat_dic.n``: file containing the number of simple words, the
   number of compound words, and the number of unknown words in the
   text.

NOTE: Files ``dlf``, ``dlc``, ``err`` and ``tags_err`` are not sorted.
Use the program ``SortTxt`` to sort them.

DumpOffsets
-----------

[section-DumpOffsets] **Usage:** ``DumpOffsets [OPTIONS] <txt>``

``<txt>: an offset file to read``

DumpOffsets dump sequence offset to study them.

**OPTIONS:**

-  ``-o X``/``--old=X``: name of old file to read

-  ``-n X``/``--new=X``: name of new file to read

-  ``-p X``/``--output=X``: name of output dump file to write

-  ``-f``/``--full``: dump common text additionaly

-  ``-q``/``--quiet``: display no message

-  ``-c``/``--no_escape_sequence``: don’t escape text sequence

-  ``-h``/``--help``: this help

Example:

::

         UnitexToolLogger Normalize -r .\resource\Norm.txt
                .\work\text_file.txt     
                --output_offsets .\work\text_file_offset.txt     
         UnitexToolLogger DumpOffsets -o .\work\text_file_offset.txt
                -n .\work\text_file_offset.snt   
                -p .\work\dump\dump_offsets.txt .\work\text_file_offset.txt      

**Other Usage:** ``DumpOffsets [-m/--merge] [OPTIONS] <txt>``

``<txt>: an offset file to read``

Merge two offset file([subsection-offsets-diff], page )) produced by two
successive modification of text

**OPTIONS:**

-  ``-o X``/``--old=X``: name of old file to read

-  ``-n X``/``--output=X``: name of output merged offset file to write

**Other Usage:**
``DumpOffsets [-v/--convert_modified_to_common] [OPTIONS] <txt>``

``<txt>: an offset file to read``

Create an offset file which list offset of common string between the
original and modified file. At least one size must be provided

**OPTIONS:**

-  ``-s N``/``--old_size=N``: size of original file (in characters)

-  ``-S N``/``--new_size=N``: size of modified file (in characters)

-  ``-p X``/``--output=X``: name of output common offset file to write

-  ``-h``/``--help``: this help

**Other Usage:**
``DumpOffsets [-M/--convert_modified_to_common] [OPTIONS] <txt>``

``<txt>: an offset file to read``

Create a standard modified offset file from offset of common string
between the original and modified file. Both size must be provided

**OPTIONS:**

-  ``-s N``/``--old_size=N``: size of original file (in characters)

-  ``-S N``/``--new_size=N``: size of modified file (in characters)

-  ``-p X``/``--output=X``: name of output common offset file to write

-  ``-h``/``--help``: this help

**Other Usage:** ``DumpOffsets -o <list_of_position_file_to_read.txt>``

``<list_of_position_file_to_read.txt>`` is a text file with just one
number (a position) at each line.

This will convert a list of position using the offset file. The created
file contain the converted position at each line, with a + at the end of
line if the character at this position is on result file, a - is it was
removed.

-  ``-p <list_to_create> -T <offset_file_to_read>``

| Using ``-t`` instead ``-T`` will do the reverse translation
| **OPTIONS:**

-  ``-d``/``--denormalize=``: Denormalize the output

This programs reproduces the white spaces removed by Normalize. It also
adds the text deleted by the Preprocessing or by a graph. It preserves
the text added as long as it is between the brackets (<,>).

The file fichier\_dump contains the text of the file fichier version 1
and the text added in the file fichier version 2.

::

    DumpOffsets [OPTIONS] -d -o <fichier_version1>
    -n <fichier_version2> <fichier_offset> -p <fichier_dump>

Elag
----

``Elag [OPTIONS] <tfst>``

This program takes a ``.tfst`` text automaton ``<tfst>`` and applies to
it ambiguity removal rules.

**OPTIONS:**

-  ``-l LANG/--language=LANG``: ELAG configuration file for the language
   of the text;

-  ``-r RULES/--rules=RULES``: rule file compiled in the ``.rul``
   format;

-  ``-o OUT/--output=OUT``: output text automaton.

ElagComp
--------

``ElagComp [OPTIONS]``

This program compiles the ELAG grammar named ``GRAMMAR``, or all the
grammars specified in the ``RULES`` file. The result is stored in the
``OUT`` file that will be used by the ``Elag`` program.

**OPTIONS:**

-  ``-r RULES``/``--rules=RULES``: file listing ELAG grammars;

-  ``-g GRAMMAR``/``--grammar=GRAMMAR``: single ELAG grammars;

-  ``-l LANG``/``--language=LANG``: ELAG configuration file for the
   language of the grammar(s);

-  ``-o OUT``/``--output=OUT``: output file. By default, the output file
   name is the same as ``RULES``, except for the extension that is
   ``.rul``.

Evamb
-----

``Evamb [OPTIONS] <tfst>``

This program computes an average lexical ambiguity rate on the text
automaton ``<tfst>``, or just on the sentence which number is specified
by ``N``. The results of the computation are displayed on the standard
output. The text automaton is not modified.

**OPTIONS:**

-  ``-o OUT``/``--output=OUT``: optional output filename;

-  ``-s N``/``--sentence=N``: sentence number.

Extract
-------

``Extract [OPTIONS] <text>``

This program extracts from the given text all sentences that contain at
least one occurrence from the concordance. The parameter ``<text>``
represents the complete path of the text file, without omitting the
extension ``.snt``.

**OPTIONS:**

-  ``-y``/``--yes``: extracts all sentences containing matching units
   (default);

-  ``-n``/``--no``: extracts all sentences that don’t contain matching
   units;

-  ``-o OUT``/``--output=OUT``: output text file;

-  ``-i X``/``--index=X``: the ``.ind`` file that describes the
   concordance. By default, ``X`` is the ``concord.ind`` file located in
   the text directory.

The result file is a text file that contains all extracted sentences,
one sentence per line.

Flatten
-------

``Flatten [OPTIONS] <fst2>``

This program takes a ``.fst2`` grammar as its parameter, and tries to
transform it into a finite-state transducer.

**OPTIONS:**

-  ``-f``/``--fst``: the grammar is “unfolded” to the maximum depth and
   is truncated if there are calls to sub-graphs. Truncated calls are
   replaced by void transitions. The result is a ``.fst2`` grammar that
   only contains a single finite-state transducer;

-  ``-r``/``--rtn``: calls to sub-graphs that remain after the
   transformation are left as they are. The result is therefore a
   finite-state transducer in the favorable case, and an optimized
   grammar strictly equivalent to the original grammar if not (default);

-  ``-d N``/``--depth=N``: maximum depth to which graph calls should be
   unfolded. The default value is 10.

Fst2Check
---------

``Fst2Check [OPTIONS] <fst2>``

This programs checks if a .fst2 file has no error for Locate.

**OPTIONS:**

-  ``-y``/``--loop_check``: enables error checking (loop detection);

-  ``-n``/``--no_loop_check``: disables error checking (default);

-  ``-t``/``--tfst_check``: checks wether the given graph can be
   considered as a valid sentence automaton or not;

-  ``-e``/``--no_empty_graph_warning``: no warning will be emitted when
   a graph matches the empty word. This option is used by ``MultiFlex``
   in order not to scare users with meaningless error messages when they
   design an inflection grammar that matches the empty word.

**Output options:**

-  ``-o file``/``--output=file``: output file for error message;

-  ``-a``/``--append``: opens the message output file in append mode;

-  ``-s``/``--statistics``: displays statistics about fst2 file.

Fst2List
--------

``Fst2List [-o out][-p s/f/d][-[a/t] s/m][-m][-f s/a][-s[0s] "Str"]``

``         [-r[s/l] "Str"] [-l line#] [-i subname]*``

``         [-c SS=0xxxx]* fname``

This program takes a ``.fst2`` file and lists the sequences recognized
by this grammar. The parameters are:

-  ``fname`` : grammar name, including ``.fst2``;

-  ``-o out`` : specifies the output file, ``lst.txt`` by default;

-  ``-S`` : display result on standard output. Exclusive with ``-o``;

-  ``-[a/t] s/m`` : indicates if the program must take into account
   (``t``) or not (``a``) the outputs of the grammars if any. ``s``
   indicates that there is only one initial state, whereas ``m``
   indicates that there are several ones (this mode is useful in
   Korean). The default value is ``-a s``;

-  ``-l line#`` : maximum number of lines to be printed in the output
   file;

-  ``-i subname`` : indicates that the recursive exploration must end
   when the program enters in graph ``subname``. This parameter can be
   used several times in order to specify several stop graphs;

-  ``-p s/f/d`` : ``s`` displays paths graph by graph; ``f`` (default)
   displays global paths; ``d`` displays global paths with information
   on nested graph calls;

-  ``-c SS=0xXXXX``: replaces symbol ``SS`` when it appears between
   angle brackets by the Unicode character whose hexadecimal number is
   ``0xXXXX``;

-  ``-s "L[,R]"`` : specifies the left (``L``) and right (``R``)
   delimiters that will enclose items. By default, no delimiters are
   specified;

-  ``-s0 "Str"`` : if the program must take outputs into account, this
   parameter specifies the sequence ``Str`` that will be inserted
   between input and output. By default, there is no separator;

-  ``-f a/s`` : if the program must take outputs into account, this
   parameter specifies the format of the lines that will be generated:
   ``in0 in1 out0 out1`` (``s``) or ``in0 out0 in1 out1`` (``a``). The
   default value is ``s``;

-  ``-ss "stop"``: set “str” as the mark of stop exploitation at
   “<stop>”. The defauld value is ``null``

-  ``-v`` : prints information during the process (verbose mode);

-  ``-m`` : mode special for description with alphabet

-  ``-rx "L,[R]"``: specifies how cycles must be displayed. ``L`` and
   ``R`` are delimiters. If we consider the graph shown on Figure
   [cycle], here are the results for ``L``\ =“``[``” and
   ``R``\ =“``]*``”:

   ``il fait [très très]*``

   ``il fait très beau``

   .. figure:: resources/img/fig10-1.png
      :alt: Graph with a cycle[cycle]
      :width: 7.00000cm

      Graph with a cycle[cycle]

Fst2Txt
-------

[section-Fst2Txt] ``Fst2Txt [OPTIONS] <fst2>``

This program applies a transducer to a text in longest match mode at the
preprocessing stage, when the text has not been cut into lexical units
yet.

**OPTIONS:**

-  ``-t TXT``/``--text=TXT``: the text file to be modified, with
   extension ``.snt``;

-  ``-a ALPH``/``--alphabet=ALPH``: the alphabet file of the language of
   the text;

-  ``-s``/``--start_on_space``: this parameter indicates that the search
   will start at any position in the text, even before a space. This
   parameter should only be used to carry out morphological searches;

-  ``-x``/``--dont_start_on_space``: forbids the program to match
   expressions that start with a space (default);

-  ``-c``/``--char_by_char``: works in character by character
   tokenization mode. This is useful for languages like Thai;

-  ``-w``/``--word_by_word``: works in word by word tokenization mode
   (default);

**Output options:**

-  ``-M``/``--merge``: merge transducer outputs with text inputs
   (default);

-  ``-R``/``--replace``: replace texts inputs with corresponding
   transducer outputs.

This program modifies the input text file.

Grf2Fst2
--------

``Grf2Fst2 [OPTIONS] <grf>``

This program compiles a grammar into a ``.fst2`` file (for more details
see section [section-graph-compilation]). The parameter ``<grf>``
denotes the complete path of the main graph of the grammar, without
omitting the extension ``.grf``.

**OPTIONS:**

-  ``-y``/``--loop_check``: enables error checking (loop detection);

-  ``-n``/``--no_loop_check``: disables error checking (default);

-  ``-a ALPH``/``--alphabet=ALPH``: specifies the alphabet file to be
   used for tokenizing the content of the grammar boxes into lexical
   units;

-  ``-c``/``--char_by_char``: tokenization will be done character by
   character. If neither ``-c`` nor ``-a`` option is used, lexical units
   will be sequences of any Unicode letters.

-  ``-d DIR``/``--pkgdir=DIR``: specifies the repository directory to
   use (see section [section-repository], page ).

-  ``-e``/``--no_empty_graph_warning``: no warning will be emitted when
   a graph matches the empty word. This option is used by ``MultiFlex``
   in order not to scare users with meaningless error messages when they
   design an inflection grammar that matches the empty word.

-  ``-t``/``--tfst_check``: checks wether the given graph can be
   considered as a valid sentence automaton or not.

-  ``-s``/``--silent_grf_name``: does not print the graph names (needed
   for consistent log files across several systems).

-  ``-r XXX``/``--named_repositories=XXX``: declaration of named
   repositories. XXX is made of one or more X=Y sequences, separated by
   ‘;’, where X is the name of the repository denoted by pathname Y. You
   can use this option several times.

-  ``--debug``: compile graphs in debug mode.

-  ``-v``/``check_variables``: check output validity to avoid malformed
   variable expressions.

The result is a file with the same name as the graph passed to the
program as a parameter, but with extension ``.fst2``. This file is saved
in the same directory as ``<grf>``.

GrfDiff
-------

GrfDiff <grf1> <grf2>: .grf files to be compared

**OPTIONS:**

-  ``--output X``: saves the result, if any, in X instead of printing it
   on the output

Compares the given grf files and prints their difference on the standard
output. Returns 0 if they are identical modulo box and transition
reordering, 1 if there are differences, 2 in case of error.

Here are the diff indications that can be emitted:

-  ``P name``: a presentation property has changed. name=property name
   (SIZE, FONT, ...)

-  ``M a b``: box moved. a=box number in <grf1>, b=box number in <grf2>

-  ``C a b``: box content changed. a=box number in <grf1>, b=box number
   in <grf2>

-  ``A x``: box added. x=box number in <grf2>

-  ``R x``: box removed. x=box number in <grf1>

-  ``T a b x y``: transition added. a,b=src and dst box numbers in
   <grf1>. x,y=src and dst box numbers in <grf2>

-  ``X a b x y``: transition removed. a,b=src and dst box numbers in
   <grf1>. x,y=src and dst box numbers in <grf2>

Note that transition modifications related to boxes that have been added
or removed are not reported.

GrfDiff3
--------

GrfDiff3 <mine> <base> <other>

<mine>: my .grf file <other>: the other .grf file that may be
conflicting <base>: the common ancestor .grf file

**OPTIONS:**

-  ``--output`` ``X``: saves the result, if any, in X instead of
   printing it on the output

-  ``--conflicts`` ``X``: saves the description of the conflicts, if
   any, in X

-  ``--only-cosmetic``: reports a conflict for any change that is not
   purely cosmetic

Tries to merge <mine> and <other>. In case of success, the result is
printed on the standard output and 0 is returned. In case of unresolved
conflicts, 1 is returned and nothing is printed. 2 is returned in case
of error.

ImplodeTfst
-----------

``ImplodeTfst [OPTIONS] <tfst>``

This program implodes the specified text automaton by merging together
lexical entries which only differ in their inflectional features.

**OPTIONS:**

-  ``-o OUT``/``--output=OUT``: output file. By default, the input text
   automaton is modified.

Locate
------

[section-Locate] ``Locate [OPTIONS] <fst2>``

This program applies a grammar to a text and constructs an index of the
occurrences found.

**OPTIONS:**

-  ``-t TXT``/``--text=TXT``: complete path of the text file, without
   omitting the ``.snt`` extension;

-  ``-a ALPH``/``--alphabet=ALPH``: complete path of the alphabet file;

-  ``-m DICS``/``--morpho=DICS``: this optional parameter indicates
   which morphological-mode dictionaries are to be used, if needed by
   some ``.fst2`` dictionaries. ``DICS`` represents a list of ``.bin``
   files (with full paths) separated with semi-colons;

-  ``-s``/``--start_on_space``: this parameter indicates that the search
   will start at any position in the text, even before a space. This
   parameter should only be used to carry out morphological searches;

-  ``-x``/``--dont_start_on_space``: forbids the program to match
   expressions that start with a space (default);

-  ``-c``/``--char_by_char``: works in character by character
   tokenization mode. This is useful for languages like Thai;

-  ``-w``/``--word_by_word``: works in word by word tokenization mode
   (default);

-  ``-d DIR``/``--sntdir=DIR``: puts produced files in ``DIR`` instead
   of the text directory. Note that ``DIR`` must end with a file
   separator (``\`` or ``/``);

-  ``-K``/``--korean``: tells ``Locate`` that it works on Korean;

-  ``-u X``/``--arabic_rules=X``: Arabic typographic rule configuration
   file;

-  ``-g X``/``--negation_operator=X``: specifies the negation operator
   to be used in Locate patterns. The two legal values for ``X`` are
   ``minus`` and ``tilde`` (default). Using ``minus`` provides backward
   compatibility with previous versions of Unitex.

**Search limit options:**

-  ``-l``/``--all``: looks for all matches (default);

-  ``-n N``/``--number_of_matches=N``: stops after the first ``N``
   matches.

**Maximum iterations per token options:**

-  ``-o N``/``--stop_token_count=N``: stops after N iterations on a
   token;

-  ``-o N,M``/``--stop_token_count=N,M``: emits a warning after N
   iterations on a token and stops after M iterations.

**Matching mode options:**

-  ``-S``/``--shortest_matches``;

-  ``-L``/``--longest_matches`` (default);

-  ``-A``/``--all_matches``.

**Output options:**

-  ``-I``/``--ignore``: ignore transducer outputs (default);

-  ``-M``/``--merge``: merge transducer outputs with text inputs;

-  ``-R``/``--replace``: replace texts inputs with corresponding
   transducer outputs;

-  ``-p``/``--protect_dic_chars``: when ``-M`` or ``-R`` mode is used,
   ``-p`` protects some input characters with a backslash. This is
   useful when ``Locate`` is called by ``Dico`` in order to avoid
   producing bad lines like:

   ``3,14,.PI.NUM``

-  ``-v X=Y``/``--variable=X=Y``: sets an output variable named X with
   content Y. Note that Y must be ASCII.

**Ambiguous output options:**

-  ``-b``/``--ambiguous_outputs``: allows the production of several
   matches with same input but different outputs (default);

-  ``-z``/``--no_ambiguous_outputs``: forbids ambiguous outputs. In case
   of ambiguous outputs, one will be arbitrarily chosen and kept,
   depending on the internal state of the program.

**Variable error options**

These options have no effect if the output mode is set with
``--ignore``; otherwise, they rule the behavior of the ``Locate``
program when an output is found that contains a reference to a variable
that is not correctly defined.

-  ``-X``/``--exit_on_variable_error``: kills the program;

-  ``-Y``/``--ignore_variable_errors``: acts as if the variable has an
   empty content (default);

-  ``-Z``/``--backtrack_on_variable_errors``: stop exploring the current
   path of the grammar.

**Variable injection:**

-  ``-v X=Y``/``--variable=X=Y``: sets an output variable named X with
   content Y. Note that Y must be ASCII

This program saves the references to the found occurrences in a file
called ``concord.ind``. The number of occurrences, the number of units
belonging to those occurrences, as well as the percentage of recognized
units within the text are saved in a file called ``concord.n``. These
two files are stored in the directory of the text.

LocateTfst
----------

[section-LocateTfst] ``LocateTfst [OPTIONS] <fst2>``

Applies a grammar to a text automaton, and saves the matching sequence
index in a file named ``concord.ind``, just as ``Locate`` does.

**OPTIONS:**

-  ``-t TFST``/``--text=TFST``: complete path of the text automaton,
   without omitting the ``.tfst`` extension;

-  ``-a ALPH``/``--alphabet=ALPH``: complete path of the alphabet file;

-  ``-K``/``--korean``: tells ``LocateTfst`` that it works on Korean;

-  ``-g X``/``--negation_operator=X``: specifies the negation operator
   to be used in Locate patterns. The two legal values for ``X`` are
   ``minus`` and ``tilde`` (default). Using ``minus`` provides backward
   compatibility with previous versions of Unitex.

**Search limit options:**

-  ``-l``/``--all``: looks for all matches (default);

-  ``-n N``/``--number_of_matches=N``: stops after the first ``N``
   matches.

**Matching mode options:**

-  ``-S``/``--shortest_matches``;

-  ``-L``/``--longest_matches`` (default);

-  ``-A``/``--all_matches``.

**Output options:**

-  ``-I``/``--ignore``: ignore transducer outputs (default);

-  ``-M``/``--merge``: merge transducer outputs with text inputs;

-  ``-R``/``--replace``: replace texts inputs with corresponding
   transducer outputs.

**Ambiguous output options:**

-  ``-b``/``--ambiguous_outputs``: allows the production of several
   matches with same input but different outputs (default);

-  ``-z``/``--no_ambiguous_outputs``: forbids ambiguous outputs. In case
   of ambiguous outputs, one will be arbitrarily chosen and kept,
   depending on the internal state of the program.

**Variable error options**

These options have no effect if the output mode is set with
``--ignore``; otherwise, they rule the behavior of the ``Locate``
program when an output is found that contains a reference to a variable
that is not correctly defined.

-  ``-X``/``--exit_on_variable_error``: kills the program;

-  ``-Y``/``--ignore_variable_errors``: acts as if the variable has an
   empty content (default);

-  ``-Z``/``--backtrack_on_variable_errors``: stop exploring the current
   path of the grammar.

**Variable injection**

-  ``-v X=Y``/``--variable=X=Y``: sets an output variable named X with
   content Y. Note that Y must be ASCII.

**Tagging option**

-  ``--tagging``: indicates that the concordance must be a tagging one,
   containing additional information on the start and end states of each
   match.

This program saves the references to the found occurrences in a file
called ``concord.ind``. The number of occurrences and the number of
produced outputs are saved in a file called ``concord_tfst.n``. These
two files are stored in the directory of the text.

MultiFlex
---------

``MultiFlex [OPTIONS] <dela>``

This program carries out the automatic inflection of a DELA dictionary
containing simple (see section [section-DELAS-format]) or compound word
lemmas (see chapter [chap-multiflex]).

**OPTIONS:**

-  ``-o DELAF``/``--output=DELAF``: output DELAF file;

-  ``-a ALPH``/``--alphabet=ALPH``: alphabet file;

-  ``-d DIR``/``--directory=DIR``: the directory containing
   ``Morphology`` and ``Equivalences`` files and inflection graphs for
   single and compound words;

-  ``-K``/``--korean``: tells ``MultiFlex`` that it works on Korean;

-  ``-s``/``--only-simple-words``: the program will consider compound
   words as errors;

-  ``-c``/``--only-compound-words``: the program will consider simple
   words as errors;

-  ``-p DIR``/``--pkgdir=DIR``: specifies the graph repository.

-  ``-rXXX``/``--named_repositories=XXX``: declaration of named
   repositories. XXX is made of one or more X=Y sequences, separated by
   ; where X is the name of the repository denoted by the pathname Y.
   You can use this option several times.

Note that ``.fst2`` inflection transducers will automatically be built
from corresponding ``.grf`` files if absent or older than ``.grf``
files.

Normalize
---------

[section-Normalize] ``Normalize [OPTIONS] <text>``

This program carries out a normalization of text separators. The
separators are space, tab, and newline. Every sequence of separators
that contains at least one newline is replaced by a unique newline. All
other sequences of separators are replaced by a single space.

This program also checks the syntax of lexical tags found in the text.
All sequences in curly brackets should be either the sentence delimiter
``{S}``, the stop marker ``{STOP}``, or valid entries in the DELAF
format (``{aujourd'hui,.ADV}``).

Parameter ``<text>`` represents the complete path of the text file. The
program creates a modified version of the text that is saved in a file
with extension ``.snt``.

**OPTIONS:**

-  ``-n``/``--no_carriage_return``: every separator sequence will be
   turned into a single space;

-  ``--input_offsets=XXX``: base offset file to be used.

-  ``--output_offsets=XXX``: offset file to be produced.

-  ``-r XXX``/``--replacement_rules=XXX``: specifies the normalization
   rule file to be used. See section [section-normalization-file] for
   details about the format of this file. By default, the program only
   replaces ``{`` and ``}`` by ``[`` and ``]``.

-  ``--no_separator_normalization``: only applies replacement rules
   specified with -r

WARNING: if you specify a normalization rule file, its rules will be
applied prior to anything else. So, you have to be very careful if you
manipulate separators in such rules.

PolyLex
-------

``PolyLex [OPTIONS] <list>``

This program takes a file containing unknown words ``<list>`` and tries
to analyse each of the words as a compound obtained by concatenating
simple words. The words that have at least one analysis are removed from
the file of unknown words and the dictionary lines that correspond to
the analysis are appended to file ``OUT``.

**OPTIONS:**

-  ``-a ALPH``/``--alphabet=ALPH``: the alphabet file to use;

-  ``-d BIN``/``--dictionary=BIN``: .bin dictionary to use;

-  ``-o OUT``/``--output=OUT``: designates the file in which the
   produced dictionary lines are to be printed; if that file already
   exists, the produced lines are appended at the end of the file;

-  ``-i INFO``/``--info=INFO``: designates a text file in which the
   information about the analysis has been produced.

**Language options:**

-  ``-D``/``--dutch``

-  ``-G``/``--german``

-  ``-N``/``--norwegian``

-  ``-R``/``--russian``

NOTE: for Dutch or Norwegian words, the program tries to read a text
file containing a list of forbidden words. This file is supposed to be
named ``ForbiddenWords.txt`` (see section [section-forbidden-words]) and
stored in the same directory than ``BIN``.

RebuildTfst
-----------

``RebuildTfst <tfst>``

This program reconstructs text automaton ``<tfst>`` taking into account
the manual modifications. If the program finds a file ``sentenceN.grf``
in the same directory as ``<tfst>``, it replaces the automaton of
sentence ``N`` with the one represented by ``sentenceN.grf``. The input
text automaton is modified.

Reconstrucao
------------

``Reconstrucao [OPTIONS] <index>``

This program generates a normalization grammar designed to be applied
before the construction of an automaton for a Portuguese text. The
``<index>`` file represents a concordance which has to be produced by
applying in MERGE mode to the considered text a grammar that extracts
all forms to be normalized. This grammar is called ``V-Pro-Suf``, and is
stored in the ``/Portuguese/Graphs/Normalization`` directory.

**OPTIONS:**

-  ``-a ALPH``/``--alphabet=ALPH``: the alphabet file to use;

-  ``-r ROOT``/``--root=ROOT``: the inverse ``.bin`` dictionary to use
   to find forms in the future and conditional given their canonical
   forms. It has to be obtained by compressing the dictionary of verbs
   in the future and conditional with the parameter ``--flip`` (see
   section [section-compress]);

-  ``-d BIN``/``--dictionary=BIN``: the ``.bin`` dictionary to use;

-  ``-p PRO``/``--pronoun_rules=PRO``: the ``.fst2`` grammar describing
   pronoun rewriting rules;

-  ``-n PRO``/``--nasal_pronoun_rules=PRO``: the ``.fst2`` grammar
   describing nasal pronoun rewriting rules;

-  ``-o OUT``/``--output=OUT``: the name of the ``.grf`` graph to be
   generated.

Reg2Grf
-------

``Reg2Grf <txt>``

This program constructs a ``.grf`` file corresponding to the regular
expression written in file ``<txt>``. The parameter ``<txt>`` represents
the complete path to the file containing the regular expression. This
file needs to be a Unicode text file. The program takes into account all
characters up to the first newline. The result file is called
``regexp.grf`` and is saved in the same directory as ``<txt>``.

Seq2Grf
-------

[Seq2Grf] ``Seq2Grf [OPTIONS] <snt>``

This program constructs a ``.grf`` file corresponding to the sequences
contained in file ``<snt>``.

**OPTIONS:**

-  ``-a ALPH``/``--alphabet=ALPH``: the alphabet file to use;

-  ``-o XXX``/``--output=XXX``: output GRF file;

-  ``-s``/``--only-stop``: only consider STOP-separated sequences;

-  ``-b``/``--beautify``: apply the grf beautifying algorithm;

-  ``-n``/``--no_beautify``: do not apply the grf beautifying algorithm
   (default);

-  ``--case-sensitive``: all letter tokens are protected with
   double-quotes (default);

-  ``--case-insensitive``: letter tokens are not protected with
   double-quotes;

-  ``-w x``: number of wildcards;

-  ``-i x``: number of insertions;

-  ``-r x``: number of replations;

-  ``-d x``: number of deletions;

Constructs the sequences automaton : one single automaton that
recognizes all the sequences from the SNT. The sequences must be
delimited with the special tag {STOP}. The produced .grf file is stored
in the user’s Graphs directory The other files, named ``text.tfst``,
``text.tind`` are stored in the text directory.

SortTxt
-------

``SortTxt [OPTIONS] <txt>``

This program carries out a lexicographical sorting of the lines of file
``<txt>``. ``<txt>`` represents the complete path of the file to be
sorted.

**OPTIONS:**

-  ``-n``/``--no_duplicates``: remove duplicate lines (default);

-  ``-d``/``--duplicates``: remove duplicate lines;

-  ``-r``/``--reverse``: sort in descending order;

-  ``-o XXX``/``--sort_order=XXX``: sorts using the alphabet of the
   order defined by file ``XXX``. If this parameter is missing, the
   sorting is done according to the order of Unicode characters;

-  ``-l XXX``/``--line_info=XXX``: backup the number of lines of the
   result file in file ``XXX``;

-  ``-t``/``--thai``: option for sorting Thai text.

-  ``-f``/``--factorize_inflectional_codes``: makes two entries
   XXX,YYY.ZZZ:A and XXX,YYY.ZZZ:B become a single entry XXX,YYY.ZZZ:A:B

The input text file is modified. By default, the sorting is performed in
the order of Unicode characters, removing duplicate lines.

Stats
-----

``Stats [OPTIONS] <ind>``

This program computes some statistics from the ``<ind>`` concordance
index file.

**OPTIONS:**

-  ``-m MODE``/``--mode=MODE``: specifies the output to be produced:

   -  ``0`` = matches with left and right contexts + number of
      occurrences;

   -  ``1`` = collocates + number of occurrences;

   -  ``2`` = collocates + number of occurrences + z-score.

-  ``-a ALPH``/``--alphabet=ALPH``: alphabet file to use;

-  ``-o OUT``/``--output=OUT``: output file;

-  ``-l N``/``--left=N``: length of left contexts in tokens;

-  ``-r N``/``--right=N``: length of right contexts in tokens;

-  ``-c N``/``--case=N``: case policy: ``0`` = case insensitive, ``1`` =
   case sensitive (default).

Table2Grf
---------

``Table2Grf [OPTIONS] <table>``

This program automatically generates graphs from a lexicon-grammar
``<table>`` and a template graph.

**OPTIONS:**

-  ``-r GRF``/``--reference_graph=GRF``: name of the template graph;

-  ``-o OUT``/``--output=OUT``: name of the result main graph;

-  ``-s XXX``/``--subgraph_pattern=XXX``: if this optional parameter if
   specified, all the produced subgraphs will be named according to this
   pattern. In order to have unambiguous names, we recommend to include
   ``@%`` in the parameter (remind that ``@%`` will be replaced by the
   line number of the entry in the table). For instance, if you set the
   pattern parameter to ’\ ``subgraph-@%.grf``\ ’, subgraph names will
   be such as ’\ ``subgraph-0013.grf``\ ’. By default, subgraph names
   look like ’\ ``result_0013.grf``\ ’, where ’\ ``result.grf``\ ’
   designates the result main graph.

Tagger
------

``Tagger [OPTIONS] <tfst>`` [section-Tagger]

The input of this program is the text automaton in the specified
``.tfst``. The program applies the Viterbi-Path algorithm to it and
produces a linear automaton. The automaton is pruned in a probabilistic
way based on a second-order hidden Markov model. If the specified tagger
data file contains tuples of “cat” tags, the tagger prunes transitions
on the basis of grammatical, syntactic and semantic codes (for example,
``that.DET+Ddem`` versus ``that.PRO+Pdem``). Else if it contains tuples
of “morph” tags, so the tagger prunes transitions on grammatical,
semantic, syntactic and inflectional codes (``the.DET+Ddef:s`` versus
``the.DET+Ddef:p``). In that case, the automaton needs to be exploded
before applying the tagging process and a tagset file must be specified
by the ``-t`` option below.

**OPTIONS:**

-  ``-a ALPH``/``--alphabet=ALPH``: alphabet file.

-  ``-o OUT``/``--output=OUT``: output text automaton.

-  ``-t TAGSET``/``--tagset=TAGSET``: name of the tagset description
   file.

-  ``-d DATA``/``--data=DATA``: a .bin tagger data file that contains
   occurrence counts for unigrams, bigrams and trigrams in order to
   compute probabilities. This file is obtained with the
   ``TrainingTagger`` program (see section [section-training-dict]).

TagsetNormTfst
--------------

``TagsetNormTfst [OPTIONS] <tfst>``

This program normalizes the specified ``.tfst`` text automaton according
to a tagset description file, discarding undeclared dictionary codes and
incoherent lexical entries. Inflectional features are unfactorized so
that ``{rouge,.A:fs:ms}`` will be divided into the 2 tags
``{rouge,.A:fs}`` and ``{rouge,.A:ms}``.

**OPTIONS:**

-  ``-o OUT``/``--output=OUT``: output text automaton. By default, the
   input text automaton is modified;

-  ``-t TAGSET``/``--tagset=TAGSET``: name of the tagset description
   file.

TEI2Txt
-------

``TEI2Txt [OPTIONS] <xml>``

Produces a raw text file from the given ``<xml>`` TEI file.

**OPTIONS:**

-  ``-o TXT``/``--output=TXT``: name of the output text file. By
   default, the output file has the same name than the input one,
   replacing ``.xml`` by ``.txt``.

Tfst2Grf
--------

``Tfst2Grf [OPTIONS] <tfst>``

This program extracts a sentence automaton in ``.grf`` format from the
given text automaton.

**OPTIONS:**

-  ``-s N``/``--sentence=N``: the number of the sentence to be
   extracted;

-  ``-o XXX``/``--output=XXX``: pattern used to name output files
   ``XXX.grf``, ``XXX.txt`` and ``XXX.tok`` (default=``cursentence``);

-  ``-f FONT``/``--font=FONT``: sets the font to be used in the output
   ``.grf``

   (default=``Times new Roman``);

-  ``-z N``/``--fontsize=N``: sets the font size (default=10).

The program produces the following files and saves them in the directory
of the text:

-  ``cursentence.grf``: graph representing the automaton of the
   sentence;

-  ``cursentence.txt``: text file containing the sentence;

-  ``cursentence.tok``: text file containing the numbers of the tokens
   that compose the sentence.

Tfst2Unambig
------------

``Tfst2Unambig [OPTIONS] <tfst>``

This programs takes a ``.tfst`` text automaton and produces an
equivalent text file if the automaton is linear (i.e. with no
ambiguity). See section [section-linear-text], page .

**OPTIONS:**

-  ``-o TXT``/``--out=TXT``: the output text file.

Tokenize
--------

[section-Tokenize] ``Tokenize [OPTIONS] <txt>``

This program tokenizes a tet text into lexical units. ``<txt>`` the
complete path of the text file, without omitting the ``.snt`` extension.

**OPTIONS:**

-  ``-a ALPH``/``--alphabet=ALPH``: alphabet file;

-  ``-c``/``--char_by_char``: indicates whether the program is applied
   character by character, with the exceptions of the sentence delimiter
   ``{S}``, the stop marker ``{STOP}`` and lexical tags like
   ``{today,.ADV}`` which are considered to be single units;

-  ``-w``/``--word_by_word``: with this option, the program considers a
   unit to be either a sequence of letters (the letters are defined by
   file ``alphabet``), or a character which is not a letter, or the
   sentence separator ``{S}``, or a lexical label like
   ``{aujourd'hui,.ADV}``. This is the default mode.

-  ``-t TOKENS``/``--tokens=TOKENS``: specifies a ``tokens.txt`` file to
   load and modify, instead of creating a new one from scratch.

**Offsets options:**

-  ``input_offsets``: base offset file to be used;

-  ``output_offsets``: offset file to be produced;

The program codes each unit as a whole. The list of units is saved in a
text file called ``tokens.txt``. The sequence of codes representing the
units now allows the coding of the text. This sequence is saved in a
binary file named ``text.cod``. The program also produces the following
four files:

-  ``tok_by_freq.txt``: text file containing the units sorted by
   frequency;

-  ``tok_by_alph.txt``: text file containing the units sorted
   alphabetically;

-  ``stats.n``: text file containing information on the number of
   sentence separators, the number of units, the number of simple words
   and the number of numbers;

-  ``enter.pos``: binary file containing the list of newline positions
   in the text. The coded representation of the text does not contain
   newlines, but spaces. Since a newline counts as two characters and a
   space as a single one, it is necessary to know where newlines occur
   in the text when the positions of occurrences located by the
   ``Locate`` program are to be synchronized with the text file. File
   ``enter.pos`` is used for this by the ``Concord`` program. Thanks to
   this, when clicking on an occurrence in a concordance, it is
   correctly selected in the text. File ``enter.pos`` is a binary file
   containing the list of the positions of newlines in the text.

All produced files are saved in the text directory.

TrainingTagger
--------------

``TrainingTagger [OPTIONS] <txt>`` [section-TrainingTagger]

This program automatically generates two tagger data files from a tagged
corpus text file. They are used by the ``Tagger`` program in order to
compute probabilities and linearize the text automaton. The tagged
corpus file must follow the format described in section
[section-corpus-file]. Those files contain tuples (unigrams, bigrams and
trigrams), formed by tags and words. In the first data file, tags are
“cat” tags (i.e. grammatical, syntactic and semantic codes). In the
second data file, tags are “morph” tags (i.e. grammatical, syntactic,
semantic and inflectional codes).

**OPTIONS:**

-  ``-a/--all``: indicates whether the program should produce all data
   files (default);

-  ``-c/--cat``: indicates whether the program should produce only data
   file with “cat” tags;

-  ``-m/--morph``: indicates whether the program should produce only
   data file with “morph” tags;

-  ``-n/--no_binaries``: indicates whether the program should not
   compress data files into ``.bin`` files, in this case only ``.dic``
   data files are generated;

-  ``-b/--binaries``: indicates whether the program should compress data
   files into ``.bin`` files (default);

-  ``-o XXX/--output=XXX``: pattern used to name output tagger data
   files ``XXX_data_cat.bin`` and ``XXX_data_morph.bin``
   (default=filename of text corpus without extension);

-  ``-s/--semitic``: indicates that the semitic compression algorithm
   should be used.

Txt2Tfst
--------

``Txt2Tfst [OPTIONS] <txt>``

This program constructs an automaton of a text. ``<txt>`` represents the
complete path of a text file without omitting the ``.snt`` extension.

**OPTIONS:**

-  ``-a ALPH``/``--alphabet=ALPH``: alphabet file;

-  ``-c``/``--clean``: indicates whether the rule of conservation of the
   best paths (see section [section-keeping-best-paths]) should be
   applied;

-  ``-n XXX``/``--normalization_grammar=XXX``: name of a normalization
   grammar that is to be applied to the text automaton;

-  ``-t TAGSET``/``--tagset=TAGSET``: Elag tagset file to use to
   normalize dictionary entries;

-  ``-K``/``--korean``: tells ``Txt2Tfst`` that it works on Korean.

If the text is separated into sentences, the program constructs an
automaton for each sentence. If this is not the case, the program
arbitrarily cuts the text into sequences of 2000 tokens and produces an
automaton for each of these sequences.

The result is a file called ``text.tfst`` which is saved in the
directory of the text. Another file named ``text.tind`` is also
produced.

NOTE: The program will also try to use the ``tags.ind`` file, if any
(see section [section-tags-ind]).

Uncompress
----------

[section-Uncompress] ``Uncompress [OPTIONS] <bin>``

This program uncompresses a ``.bin`` dictionary into a text file
``.dic`` one.

**OPTIONS:**

-  ``-o OUT``/``--output=OUT``: optional output file name (default:
   ``file.bin`` > ``file.dic``).

Untokenize
----------

[section-Untokenize] ``Untokenize [OPTIONS] <txt>``

Untokenizes and rebuild the orgininal text. The token list is stored
into ``tokens.txt`` and the coded text is stored into ``text.cod``. The
file ``enter.pos`` contains the position in tokens of all the carriage
return sequences. These files are located in the XXX\_snt directory
where XXX is <txt> without its extension.

**OPTIONS:**

-  ``-d X``/``--sntdir=X``: uses directory X instead of the text
   directory; note that X must be (back)slash terminated

-  ``-n N``/``--number_token=N``: adds tokens number each N token;

-  ``-r N``/``--range=N``: emits only token from number N to end;

-  ``-r N,M``/``--range=N,M``: emits only token from number N to M.

UnitexTool
----------

[section-UnitexTool] ``UnitexTool <utilities>``

This program is a super-program that allows you to invoke all Unitex
external programs. With it, you can chain commands so that they will be
invoked within a same system process, in order to speed up processing.
This can done by invoking commands nested in round brackets as this:

::

    UnitexTool { SelectOutput [OPTIONS] } 
                 { cmd #1+args } 
                 { cmd #2+args }
                 etc.

For instance, if you want to join a locate operation and the
construction of the concordance, you can use the following command:

::

    UnitexTool { Locate "-tD:\My Unitex\English\Corpus\ivanhoe.snt" 
    "D:\My Unitex\English\regexp.fst2"
    "-aD:\My Unitex\English\Alphabet.txt" -L -I -n200 
    "--morpho=D:\Unitex2.0\English\Dela\dela-en-public.bin" -b -Y }
    { Concord "D:\My Unitex\English\Corpus\ivanhoe_snt\concord.ind" 
    "-fCourier new" -s12 -l40 -r55 --CL --html 
    "-aD:\My Unitex\English\Alphabet_sort.txt" }

**OPTIONS**:

-  ``-o [on/off]``/``--output=[on/off]``: enable (on) or disable (off)
   standard output

-  ``-e [on/off]``/``--error=[on/off]``: enable (on) or disable (off)
   error output

By example:

::

    UnitexTool { SelectOutput -o off -e off } { Normalize
    Unitex\English\Corpus\ivanhoe.txt }

UnitexToolLogger
----------------

[section-UnitexToolLogger] ``UnitexToolLogger <utilities>``

This program is a superset of UnitexTool. It can rerun a .ulp logfile.
It can also record a running session of an UnitexTool and create a .ulp
logfile. If UnitexToolLogger is used like UnitexTool (with just
parameters with command lines for Unitex external programs), and if a
file named unitex\_logging\_parameters\_count.txt (in the current
directory) contains a path, a .ulp logfile for the running session will
be created. The .ulp file is a compressed zipfile (compatible with
unzip), which can be useful for debugging.

``UnitexToolLogger RunLog [OPTIONS] <ulp>``

**OPTIONS after RunLog:**

-  ``-m``/``--quiet``: do not emit message when running;

-  ``-v``/``--verbose``: emit message when running;

-  ``-d DIR``/``--rundir=DIR``: path where log is executed;

-  ``-r newfile.ulp``/``--result=newfile.ulp``: name of result ulp
   created;

-  ``-c``/``--clean``: remove work file after execution;

-  ``-k``/``--keep``: keep work file after execution;

-  ``-s file.txt``/``--summary=file.txt``: summary file with log compare
   result to be created;

-  ``-e file.txt``/``--summary-error=file.txt``: summary file with error
   compare result to be created;

-  ``-b``/``--no-benchmark``: do not store time execution in result log;

-  ``-n``/``--cleanlog``: remove result ulp after execution;

-  ``-l``/``--keeplog``: keep result ulp after execution;

-  ``-o NameTool``/``--tool=NameTool``: run only log for NameTool;

-  ``-i N``/``--increment=N``: increment filename <ulp> by 0 to N;

-  ``-t N``/``--thread=N``: create N thread;

-  ``-a N``/``--random=N``: select N time a random log in the list (in
   each thread);

-  ``-f N``/``--break-after=N``: user cancel after N run (with one
   thread only);

-  ``-u PATH``/``--unfound-location=PATH``: take dictionnary and FST2
   from PATH if not found on the logfile;

Another usage of UnitexToolLogger is using the MzRepairUlp option to
repair a corrupted ulp file (often, a crashing log):

``UnitexToolLogger MzRepairUlp [OPTIONS] <ulpfile>``

**OPTIONS after MzRepairUlp:**

-  ``-t X``/``--temp=X``: uses X as filename for temporary file
   (<ulpfile>.build by default);

-  ``-o X``/``--output=X``: uses X as filename for fixed .ulp file
   (<ulpfile>.repair by default);

-  ``-m``/``--quiet``: do not emit message when running;

-  ``-v``/``--verbose``: emit message when running;

Another usage of UnitexToolLogger is using the CreateLog option (with
round bracket) to create logfile of running Unitex program, like:

``UnitexToolLogger { CreateLog [OPTIONS] } cmd args``

``UnitexToolLogger { CreateLog [OPTIONS] } { cmd #1+args } { cmd #2+args } etc.``

By example,

::

    UnitexToolLogger { CreateLog --log_file=my_run_normalize.ulp }
                 Normalize "C:\My Unitex\French\Corpus\80jours.txt"

::

    UnitexToolLogger { CreateLog --directory=c:\logs }
                      { Compress c:\dela\mydela.dic }
                      { CheckDic --delaf c:\dela\mydela.inf }

**OPTIONS after CreateLog:**

-  ``-g``/``--no_create_log``: do not create any log file. Incompatible
   with all others options;

-  ``-p XXX``/``--param_file=XXX``: load a parameters file like
   unitex\_logging\_parameters.txt. Incompatible with all others
   options;

-  ``-d XXX/--directory=XXX``: location directory where log file to
   create;

-  ``-l XXX/--log_file=XXX``: filename of log file to create;

-  ``-i``/``--store_input_file``: store input file in log (default);

-  ``-n``/``--no_store_input_file``: don’t store input file in log
   (prevent rerun the logfile);

-  ``-o``/``--store_output_file``: store output file in log;

-  ``-u``/``--no_store_output_file``: don’t store output file in log
   (default);

-  ``-s``/``--store_list_input_file``: store list of input file in log
   (default);

-  ``-t``/``--no_store_list_input_file``: don’t store list of input file
   in log;

-  ``-r``/``--store_list_output_file``: store list of output file in log
   (default);

-  ``-f``/``--no_store_list_output_file``: don’t store list of output
   file in log.

::

    UnitexToolLogger { SelectOutput [OPTIONS] } 
                 { cmd #1+args } 
                 { cmd #2+args }
                 etc.

**OPTIONS after SelectOutput**:

-  ``-o [on/off]``/``--output=[on/off]``: enable (on) or disable (off)
   standard output

-  ``-e [on/off]``/``--error=[on/off]``: enable (on) or disable (off)
   error output

By example:

::

    UnitexToolLogger { SelectOutput -o off -e off } { Normalize
    Unitex\English\Corpus\ivanhoe.txt }

Unxmlize
--------

[section-Unxmlize]

This program removes all xml tags from the given .xml or .html file to
produce a text file that can be processed by Unitex.
``Unxmlize [OPTIONS] <file>``

**OPTIONS:**

-  ``-o TXT``/``--output=TXT``: output file. By default, foo.xml =>
   foo.txt

-  ``--output_offsets=XXX``: specifies the offset file to be produced

-  ``--PRLG=XXX``: extracts to file XXX special information used in the
   PRLG project on ancient Greek (requires ``--output_offsets``)

-  ``-t``/``--html``: consider the file as html file (disregard
   extension)

-  ``-x``/``--xml``: consider the file as xml file (disregard extension)

-  ``-l``/``--tolerate``: try tolerate somes markup langage malformation

-  ``--comments=IGNORE``: every comment is removed (default)

-  ``--comments=SPACE``: every comment is replaced by a single space

-  ``--scripts=IGNORE``: every script block is removed

-  ``--scripts=SPACE``: every comment is replaced by a single space
   (default for .html)

Note: by default, script tags are handled as normal tags (default for
.xml).

-  ``--normal_tags=IGNORE``: every other tag is removed (default for
   .xml)

-  ``--normal_tags=SPACE``: every other tag is replaced by a single
   space(default for .html)

XMLizer
-------

[section-XMLizer] ``XMLizer [OPTIONS] <txt>``

This program takes the raw text file ``<txt>`` and produces a
corresponding basic TEI or XML file. The difference between TEI and XML
is that TEI files will contain a TEI header.

**OPTIONS:**

-  ``-x``/``--xml``: produces a XML file;

-  ``-t``/``--tei``: produces a TEI file (default);

-  ``-n XXX``/``--normalization=XXX``: specify the normalization rule
   file to be used (see section [section-normalization-file]);

-  ``-o OUT``/``--output=OUT``: optional output file name (default:
   ``file.txt`` > ``file.xml``);

-  ``-a ALPH``/``--alphabet=ALPH``: alphabet file;

-  ``-s SEG``/``--segmentation_grammar=SEG``: sentence delimitation
   grammar to be used. This grammar should be like the ``Sentence.grf``
   one used during the preprocessing of a corpus, but it can include the
   special tag ``{P}`` to indicate paragraph bounds.
