 

**Unitex**

**User Manual**

|image|

Université Paris-Est Marne-la-Vallée

http://www-igm.univ-mlv.fr/~unitex

``unitex-devel@univ-mlv.fr``

Sébastien Paumier

| This document was produced by revising and extending the English
  translation
| of version 1.2 by Wolfgang Flury, Franz Guenthner, Friederike Malchok,
  Clemens Marschner, Sebastian Nagel, Johannes Stiehler
| (CIS, Ludwig-Maximilians-Universität, Munich), October 2003
| http://www.cis.uni-muenchen.de/

Date of this version:

.. |image| image:: resources/img/logo-Unitex.png
   :width: 4.00000cm
