Dictionnaires
=============

Les dictionnaires DELA
----------------------

Les dictionnaires électroniques utilisés par Unitex utilisent le
formalisme DELA (Dictionnaires Electroniques du LADL). Ce formalisme
permet de décrire les entrées lexicales simples et composées d’une
langue en leur associant de façon optionnelle des informations
grammaticales, sémantiques et flexionnelles. On distingue deux sortes de
dictionnaires électroniques. Le type que l’on utilise le plus couramment
est le dictionnaire de formes fléchies, appelé DELAF (DELA de formes
Fléchies) ou encore DELACF (DELA de formes Composées Fléchies) lorsqu’il
s’agit d’un dictionnaire de mots composés. Le second type est le
dictionnaire de formes non fléchies appelé DELAS (DELA de formes
Simples) ou DELAC (DELA de formes Composées). Les programmes d’Unitex ne
font pas de distinction entre les dictionnaires de formes simples et
composées. Nous utiliserons donc les termes DELAF et DELAS pour désigner
les deux sortes de dictionnaires que leurs entrées soient simples,
composées ou mixtes.

Format des DELAF
~~~~~~~~~~~~~~~~

Syntaxe d’une entrée
^^^^^^^^^^^^^^^^^^^^

Une entrée d’un DELAF est une ligne de texte terminée par un retour à la
ligne qui respecte le schéma suivant :

::

    mercantiles,mercantile.A+z1:mp:fp/ceci est un exemple

Les différents éléments qui forment cette ligne sont les suivants:

-  ``mercantiles `` est la forme fléchie de l’entrée. Cette forme
   fléchie est obligatoire;

-  ``mercantile`` est la forme canonique (lemme) de l’entrée. Pour les
   noms et les adjectifs, il s’agit en général de la forme au masculin
   singulier; pour les verbes, la forme canonique est l’infinitif. Cette
   information peut être omise comme dans l’exemple suivant :

   ``boîte à merveilles,.N+z1:fs``

   Cela signifie alors que la forme canonique est identique à la forme
   fléchie. La forme canonique est séparée de la forme fléchie par une
   virgule;

-  ``A+z1`` est la séquence d’informations grammaticales et sémantiques.
   Dans notre exemple, ``A`` désigne un adjectif, et ``z1`` ndique qu’il
   s’agit d’un mot courant (voir tableau  [tab-semantic-codes]).

   Toute entrée doit comporter au moins un code grammatical ou
   sémantique, séparé de la forme canonique par un point. S’il y a
   plusieurs codes, ceux-ci doivent être séparés par le caractère ``+``.

-  ``:mp:fp`` est la séquence d’informations flexionnelles. Ces
   informations décrivent le genre, le nombre, les temps et modes de
   conjugaisons, les déclinaisons pour les langues à cas, etc. Ces
   informations sont facultatives. Un code flexionnel est composé d’un
   ou plusieurs caractères codant chacun une information. Les codes
   flexionnels doivent être séparés par le caractère :. Dans notre
   exemple, ``m`` signifie masculin, ``p`` pluriel et ``f`` féminin
   (voir tableau  [tab-inflectional-codes]). Le caractère ``:``
   s’interprète comme un OU logique. Ainsi, ``:mp:fp`` signifie
   “masculin pluriel”, ou “féminin pluriel”. Comme chaque caractère
   correspond à une information, il est inutile d’utiliser plusieurs
   fois un même caractère. Ainsi, coder le participe passé avec le
   code\ ``:PP`` serait strictement équivalent à utiliser ``:P`` seul;

-  ``/ceci est un exemple`` est un commentaire. Les commentaires sont
   facultatifs et doivent être introduits par le caractère ``/``. Les
   commentaires sont supprimés lorsque l’on comprime les dictionnaires.

REMARQUE IMPORTANTE : il est possible d’utiliser le point et la virgule
dans une entrée de dictionnaire. Pour cela, il faut les déspécialiser
avec le caractère ``\`` :

::

    3\,1415,PI.NOMBRE
    Organisation des Nations Unies,O\.N\.U\..SIGLE

ATTENTION : chaque caractère est pris en compte dans une ligne de
dictionnaire. Par exemple, si vous introduisez des espaces, ceux-ci
seront considérés comme faisant partie intégrante des informations. Dans
la ligne suivante :

::

    gît,gésir.V+z1:P3s /voir ci-gît

l’espace qui précède le caractère ``/`` sera considéré comme faisant
partie d’un code flexionnel à 4 caractères composés de ``P``, ``3``,
``s`` et d’un espace.

Il est possible d’insérer des lignes de commentaires dans un
dictionnaire DELAF ou DELAS, en faisant débuter la ligne par le
caractère :math:`/`. Exemple

::

    / L’entrée nominale pour ’par’ est un terme de golf
    par,.N+z3:ms

Mots composés avec espace ou tiret
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Certains mots composés comme *grand-mère* peuvent s’écrire avec des
espaces ou avec des tirets. Pour éviter de devoir dédoubler toutes les
entrées, il est possible d’utiliser le caractère ``=`` . Lors de la
compression du dictionnaire, le programme ``Compress`` vérifie pour
chaque ligne si la forme fléchie ou la forme canonique contient le
caractère ``=``. Si c’est le cas, le programme remplace l’entrée par
deux entrées : une où le caractère = est remplacé par un espace, et une
où il est remplacé par un tiret. Ainsi, l’entrée suivante :

``grand=mères,grand=mère.N:fp``

est remplacée par les deux lignes suivantes:

``grand mères,grand mère.N:fp``

``grand-mères,grand-mère.N:fp``

NOTE : si vous souhaitez écrire une entrée contenant le caractère ``=``,
déspécialisez-le avec le caractère ``\`` comme dans l’exemple suivant :

| ``E\=mc2,.FORMULE``
| Cette opération de remplacement a lieu lors de la compression du
  dictionnaire. Une fois le dictionnaire comprimé, les signes ``=``
  déspécialisés sont remplacés par de simples ``=``. Ainsi, si l’on
  comprime un dictionnaire contenant les lignes suivantes :

::

    E=mc2,.FORMULE
    grand=mère,.N:fs

| et que l’on applique ce dictionnaire au texte :
| ``Ma grand-mère m’a expliqué la formule E=mc2.``

on obtiendra les lignes suivantes dans le dictionnaire de mots composés
du texte:

::

    E=mc2,.FORMULE
    grand-mère,.N:fs

Factorisation d’entrées
^^^^^^^^^^^^^^^^^^^^^^^

Plusieurs entrées ayant les mêmes formes fléchie et canonique peuvent
être regroupées en une seule à condition qu’elle aient les mêmes codes
grammaticaux et sémantiques. Cela permet entre autres de regrouper des
conjugaisons identiques pour un même verbe :

::

    glace,glacer.V+z1:P1s:P3s:S1s:S3s:Y2s

Si les informations grammaticales et sémantiques diffèrent, il faut
créer des entrées dis- tinctes :

::

    glace,.N+z1:fs
    glace,glacer.V+z1:P1s:P3s:S1s:S3s:Y2s

Certaines entrées ayant les mêmes codes grammaticaux et sémantiques
peuvent avoir des sens différents, comme c’est le cas pour le mot
*poêle* qui désigne un appareil de chauffage ou un voile au masculin et
un instrument de cuisine au féminin. On peut donc distinguer les entrées
dans ce cas :

``poêle,.N+z1:fs/ poêle à frire``

``poêle,.N+z1:ms/ voile, linceul; appareil de chauffage``

NOTE : dans la pratique, cette distinction n’a pas d’autre conséquence
qu’une augmentation du nombre d’entrées du dictionnaire. Les différents
programmes qui composent Unitex donneront exactement les mêmes résultats
si l’on fusionne ces entrées en :

``poêle,.N+z1:fs:ms``

L’intérêt de cette distinction est donc laissé à l’appréciation des
personnes qui construisent des dictionnaires.

Format des DELAS
~~~~~~~~~~~~~~~~

Le format des DELAS est très similaire à celui des DELAF. La différence
est qu’on ne mentionne qu’une forme canonique suivie de codes
grammaticaux et/ou sémantiques. La forme canonique est séparée des
différents codes par une virgule. Voici un exemple d’entrée :

::

    cheval,N4+Anl

Le premier code grammatical ou sémantique sera interprété par le
programme de flexion comme le nom de la grammaire à utiliser pour
fléchir l’entrée. L’entrée de l’exemple cidessus indique que le mot
*cheval* doit être fléchi avec une grammaire nommée ``N4``. Il est
possible d’ajouter des codes flexionnels aux entrées, mais la nature de
l’opération de flexion limite l’intérêt de cette possibilité. Pour plus
de détails, voir plus loin dans ce chapitre la section
 [section-automatic-inflection].

Contenu des dictionnaires
~~~~~~~~~~~~~~~~~~~~~~~~~

Les dictionnaires fournis avec Unitex contiennent des descriptions des
mots simples et composés. Ces descriptions indiquent la catégorie
grammaticale de chaque entrée, ses éventuels codes de flexion, ainsi que
des informations sémantiques diverses. Les tableaux suivants donnent un
aperçu des différents codes utilisés dans les dictionnaires fournis avec
Unitex. Ces codes ont la même signification pour presque toutes les
langues, même si certains d’entre eux sont propres à certaines langues
(*i.e.* marque du neutre, etc.).

+-------------+--------------------------------+------------------------------------------+
| **Code**    | **Signification**              | **Exemples**                             |
+=============+================================+==========================================+
| ``A``       | adjectif                       | fabuleux, broken-down                    |
+-------------+--------------------------------+------------------------------------------+
| ``ADV``     | adverbe                        | réellement, à la longue                  |
+-------------+--------------------------------+------------------------------------------+
| ``CONJC``   | conjonction de coordination    | mais                                     |
+-------------+--------------------------------+------------------------------------------+
| ``CONJS``   | conjonction de subordination   | puisque, à moins que                     |
+-------------+--------------------------------+------------------------------------------+
| ``DET``     | déterminant                    | ses, trente-six                          |
+-------------+--------------------------------+------------------------------------------+
| ``INTJ``    | interjection                   | adieu, mille millions de mille sabords   |
+-------------+--------------------------------+------------------------------------------+
| ``N``       | nom                            | prairie, vie sociale                     |
+-------------+--------------------------------+------------------------------------------+
| ``PREP``    | préposition                    | sans, à la lumière de                    |
+-------------+--------------------------------+------------------------------------------+
| ``PRO``     | pronom                         | tu, elle-même                            |
+-------------+--------------------------------+------------------------------------------+
| ``V``       | verbe                          | continuer, copier-coller                 |
+-------------+--------------------------------+------------------------------------------+

Table: Codes grammaticaux usuels[tab-grammatical-codes]

+----------------+-------------------------------------------+--------------------+
| **Code**       | **Signification**                         | **Exemple**        |
+================+===========================================+====================+
| ``z1``         | langage courant                           | blague             |
+----------------+-------------------------------------------+--------------------+
| ``z2``         | langage spécialisé                        | sépulcre           |
+----------------+-------------------------------------------+--------------------+
| ``z3``         | langage très spécialisé                   | houer              |
+----------------+-------------------------------------------+--------------------+
| ``Abst``       | abstrait                                  | bon goût           |
+----------------+-------------------------------------------+--------------------+
| ``Anl``        | animal                                    | cheval de race     |
+----------------+-------------------------------------------+--------------------+
| ``AnlColl``    | animal collectif                          | troupeau           |
+----------------+-------------------------------------------+--------------------+
| ``Conc``       | concret                                   | abbaye             |
+----------------+-------------------------------------------+--------------------+
| ``ConcColl``   | concret collectif                         | décombres          |
+----------------+-------------------------------------------+--------------------+
| ``Hum``        | humain                                    | diplomate          |
+----------------+-------------------------------------------+--------------------+
| ``HumColl``    | humain collectif                          | vieille garde      |
+----------------+-------------------------------------------+--------------------+
| ``t``          | verbe transitif                           | foudroyer          |
+----------------+-------------------------------------------+--------------------+
| ``i``          | verbe intransitif                         | fraterniser        |
+----------------+-------------------------------------------+--------------------+
| ``en``         | particule pré-verbale (PPV) obligatoire   | en imposer         |
+----------------+-------------------------------------------+--------------------+
| ``se``         | verbe pronominal                          | se marier          |
+----------------+-------------------------------------------+--------------------+
| ``ne``         | verbe à négation obligatoire              | ne pas cesser de   |
+----------------+-------------------------------------------+--------------------+

Table: Quelques codes sémantiques[tab-semantic-codes]

NOTE : les descriptions des temps du tableau  [tab-inflectional-codes]
correspondent au français. Néanmoins, la plupart de ces définitions se
retrouvent dans plusieurs langues (infinitif, présent, participe passé,
etc.).

Malgré une base commune à la plupart des langues, les dictionnaires
contiennent des particularités de codage propres à chaque langue. Ainsi,
les codes de flexion variant beaucoup d’une langue à une autre, n’ont
pas été décrits ici. Pour une description exhaustive de tous les codes
utilisés dans un dictionnaire, nous vous recommandons de vous adresser
directement à l’auteur du dictionnaire.

+-----------------------+----------------------------+
| **Code**              | **Signification**          |
+=======================+============================+
| ``m``                 | masculin                   |
+-----------------------+----------------------------+
| ``f``                 | féminin                    |
+-----------------------+----------------------------+
| ``n``                 | neutre                     |
+-----------------------+----------------------------+
| ``s``                 | singulier                  |
+-----------------------+----------------------------+
| ``p``                 | pluriel                    |
+-----------------------+----------------------------+
| ``1``, ``2``, ``3``   | 1st, 2nd, 3rd personne     |
+-----------------------+----------------------------+
| ``P``                 | présent de l’indicatif     |
+-----------------------+----------------------------+
| ``I``                 | imparfait de l’indicatif   |
+-----------------------+----------------------------+
| ``S``                 | présent du subjonctif      |
+-----------------------+----------------------------+
| ``T``                 | imparfait du subjonctif    |
+-----------------------+----------------------------+
| ``Y``                 | présent de l’impératif     |
+-----------------------+----------------------------+
| ``C``                 | présent du conditionnel    |
+-----------------------+----------------------------+
| ``J``                 | passé simple               |
+-----------------------+----------------------------+
| ``W``                 | infinitif                  |
+-----------------------+----------------------------+
| ``G``                 | participe présent          |
+-----------------------+----------------------------+
| ``K``                 | participe passé            |
+-----------------------+----------------------------+
| ``F``                 | futur                      |
+-----------------------+----------------------------+

Table: Codes flexionnels usuels[tab-inflectional-codes]

Les codes présentés ne sont absolument pas limitatifs. Chaque
utilisateur peut introduire ses propres codes, et créer ses propres
dictionnaires. Par exemple, on pourrait dans un but pédagogique
introduire dans les dictionnaires anglais des marques indiquant les
faux-amis français :

::

    bless,.V+faux-ami/bénir
    cask,.N+faux-ami/tonneau
    journey,.N+faux-ami/voyage

Il est également possible d’utiliser les dictionnaires pour stocker des
informations parti- culières. Ainsi, on pourrait utiliser la forme
fléchie d’une entrée pour décrire un sigle et la forme canonique pour en
donner la forme complète :

::

    ADN,Acide DésoxyriboNucléique.SIGLE
    LADL,Laboratoire d’Automatique Documentaire et Linguistique.SIGLE
    SAV,Service Après-Vente.SIGLE

Recherche d’un mot dans un dictionnaire
---------------------------------------

[section-dictionary-lookup] Vous pouvez rechercher un mot dans plusieurs
dictionnaires de deux manières :

.. figure:: resources/img/fig3-1.png
   :alt: Menu “DELA”
   :width: 13.00000cm

   Menu “DELA”

Si vous avez ouvert un dictionnaire, la fenêtrre affichée contient un
champ qui vous permet d’effectuer une recherche. Si le mot apparaît dans
le dictionnaire, le bouton “Find” surligne la première entrée
correspondante. Si plusieurs entrées correspondent, vous pouvez les
parcourir en cliquant sur les deux boutons en forme de flèche.

.. figure:: resources/img/fig3-2.png
   :alt: Recherche d’un mot dans un dictionnaire
   :width: 7.00000cm

   Recherche d’un mot dans un dictionnaire

Vous pouvez aussi rechercher un mots dans plusieurs dictionnaires en
cliquant sur le bouton “Lookup” du menu “DELA”. Vous pouvez ensuite
sélectionner les dictionnaires dans lesquels rechercher le mot que vous
avez entré.

.. figure:: resources/img/fig3-3.png
   :alt: Recherche d’un mot dans plusieurs dictionnaires
   :width: 7.00000cm

   Recherche d’un mot dans plusieurs dictionnaires

Vérification du format du dictionnaire
--------------------------------------

Lorsque les dictionnaires sont de taille importante, il devient
fastidieux de les vérifier à la main. Unitex contient le programme
``CheckDic`` qui vérifie automatiquement les dictionnaires DELAF et
DELAS.

Ce programme effectue une vérification de la syntaxe des entrées. Pour
chaque entrée mal formée, le programme affiche le numéro de ligne, le
contenu de cette ligne et la nature de l’erreur. Les résultats de
l’analyse sont sauvés dans un fichier nommé ``CHECK_DIC.TXT`` qui est
affiché une fois la vérification terminée. En plus des éventuels
messages d’erreurs, ce fichier contient la liste de tous les caractères
utilisés dans les formes fléchies et canoniques, la liste des codes
grammaticaux et sémantiques,ainsi que la liste des codes flexionnels
utilisés. La liste des caractères permet de vérifier que les caractères
présents dans le dictionnaire sont cohérents avec ceux présents dans le
fichier alphabet de la langue. Chaque caractère est suivi par sa valeur
en notation hexadécimale. Les listes de codes peuvent être utilisées
pour vérifier qu’il n’y a pas de faute de frappe dans les codes du
dictionnaire.

Le programme ``CheckDic`` fonctionne avec des dictionnaires non
comprimés, c’est-à-dire sous forme de fichiers texte. La convention
généralement appliquée est de donner l’extension ``.dic`` . Pour
vérifier le format d’un dictionnaire, il faut tout d’abord l’ouvrir en
cliquant sur “Open...” dans le menu “DELA”.

.. figure:: resources/img/fig3-4.png
   :alt: Exemple de dictionnaire[fig-dictionary-example]
   :width: 10.00000cm

   Exemple de dictionnaire[fig-dictionary-example]

Chargeons le dictionnaire de la figure [fig-dictionary-example]. Pour
lancer la vérification automatique, cliquez sur “Check Format...” dans
le menu “DELA”. la fenêtre de la figure  [fig-dictionary-checking]
apparaît alors. Cette fenêtre vous permet de choisir le type du
dictionnaire que vous voulez vérifier. Les résultats de la vérification
du dictionnaire de la figure [fig-dictionary-example], sont présentés
sur la figure [fig-dictionary-checking-results].

La première erreur est due au fait que le programme n’ait pas trouvé de
point. Le seconde, au fait qu’il n’ait pas trouvé de virgule marquant la
fin de la forme fléchie. La troisième erreur indique que le programme
n’a trouvé aucun code grammatical ou sémantique.

.. figure:: resources/img/fig3-5.png
   :alt: Vérification automatique d’un
   dictionnaire[fig-dictionary-checking]
   :width: 7.00000cm

   Vérification automatique d’un dictionnaire[fig-dictionary-checking]

.. figure:: resources/img/fig3-6.png
   :alt: Résultats d’une vérification
   automatique[fig-dictionary-checking-results]
   :height: 19.40000cm

   Résultats d’une vérification
   automatique[fig-dictionary-checking-results]

Tri
---

Unitex manipule les dictionnaires sans se soucier de l’ordre des
entrées. Toutefois, pour des raisons de présentation, il est souvent
préférable de trier les dictionnaires. L’opération de tri varie selon
plusieurs critères, à commencer par la langue du texte à trier. Ainsi,
le tri d’un dictionnaire thaï s’effectue selon un ordre différent de
l’ordre alphabétique, si bien qu’Unitex utilise un mode de tri développé
spécialement pour le thaï (voir chapitre [chap-external-programs]).

Pour les langues européennes, le tri s’effectue généralement selon
l’ordre lexicographique, avec toutefois quelques variantes. En effet,
certaines langues comme le français considèrent certains caractères
comme équivalents. Par exemple, la différence entre les caractères ``e``
et ``é`` est ignorée lorsque l’on veut comparer les mots ``manger`` et
``mangés``, car les contextes ``r`` et ``s`` permettent de décider de
l’ordre. La distinction n’est faite que lorsque les contextes sont
identiques, ce qui est le cas si l’on compare ``pêche`` et ``pèche``.

Afin de prendre en compte ce phénomène, le programme de tri ``SortTxt``
utilise un fichier qui définit des équivalences de caractères. Ce
fichier s’appelle ``Alphabet_sort.txt`` et se trouve dans le répertoire
de la langue courante de l’utilisateur. Voici les premières lignes du
fichier utilisé par défaut pour le français :

``AÀÂÄaàâä``

``Bb``

``CÇcç``

``Dd``

``EÉÈÊËeéèêë``

Les caractères présents sur une même ligne sont considérés comme
équivalents quand le contexte le permet. Lorsqu’il faut comparer deux
caractères équivalents, on les compare selon l’ordre dans lequel ils
apparaissent de gauche à droite sur la ligne. On peut voir sur l’extrait
ci-dessus qu’on ne fait pas de différence entre minuscules et
majuscules, et qu’on ignore les accents ainsi que la cédille.

Pour trier un dictionnaire, ouvrez-le, puis cliquez sur “Sort
Dictionary” dans le menu “DELA”. Par défaut, le programme cherche
toujours à utiliser le fichier ``Alphabet_sort.txt``. Si ce fichier est
absent, le tri se fait selon l’indice des caractères dans le codage
Unicode. En modifiant ce fichier, vous pouvez définir vos propres
préférences de tri.

Remarque : après l’application des dictionnaires sur un texte, les
fichiers ``dlf``, ``dlc`` et ``err`` sont automatiquement triés avec ce
programme.

Flexion automatique
-------------------

Flexion des mots simples
~~~~~~~~~~~~~~~~~~~~~~~~

Comme décrit dans la section [section-DELAS-format], une ligne de DELAS
se compose généralement d’une forme canonique et d’une séquence de codes
grammaticaux ou sémantiques :

::

    aviatrix,N4+Hum
    matrix,N4+Math
    radix,N4

Le premier code rencontré est interprété comme le nom de la grammaire à
utiliser pour fléchir la forme canonique. Il y a deux formes possibles :

-  ``N4``: nom de la grammaire=\ ``N4.fst2``, codes grammaticaux=\ ``N``
   (le plus long préfixe uniquement composé de lettres)

-  ``N(NC_XXX)``: nom de la grammaire=\ ``NC_XXX.fst2``, codes
   grammaticaux=\ ``N``

Ces grammaires de flexion seront automatiquement compilées si besoin
est. Dans l’exemple ci-dessus, toutes les entrées seront fléchies avec
une grammaire nommée ``N4``.

Pour lancer la flexion, cliquez sur “Inflect...” dans le menu “DELA”. La
fenêtre de la figure [fig-inflection-configuration] permet d’indiquer au
programme de flexion le répertoire dans lequel se trouvent les
grammaires de flexion. Par défaut, le sous-répertoire ``Inflection`` du
répertoire de la langue courante est utilisé. On peut aussi spécifier
quels types de mots le dictionnaire est supposé contenir. Si une entrée
non conforme est rencontrée, un message d’erreur sera affiché.

.. figure:: resources/img/fig3-7.png
   :alt: Configuration de la flexion
   automatique[fig-inflection-configuration]
   :width: 8.00000cm

   Configuration de la flexion automatique[fig-inflection-configuration]

.. figure:: resources/img/fig3-8.png
   :alt: Grammaire de flexion ``N4``\ [fig-example-inflectional-grammar]
   :width: 4.50000cm

   Grammaire de flexion ``N4``\ [fig-example-inflectional-grammar]

La figure [fig-example-inflectional-grammar] présente un exemple de
grammaire de flexion. Les chemins décrivent les suffixes à ajouter ou à
retrancher pour obtenir la forme fléchie à partir de la forme canonique,
et les sorties (texte en gras sous les boîtes) donnent les codes
flexionnels à ajouter à l’entrée du dictionnaire.

Dans notre exemple, deux chemins sont possibles. Le premier ne modifie
pas la forme canonique et ajoute le code flexionnel ``:s``. Le second
retranche une lettre grâce à l’opérateur ``L``, ajoute ensuite le
suffixe ``ces`` et ajoute le code flexionnel ``:mp``.

Voici les opérateurs utilisables:

-  ``L`` (left) enlève une lettre à l’entrée;

-  ``R`` (right) rétablit une lettre de l’entrée. En français, beaucoup
   de verbes du premier groupe se conjuguent au présent à la troisième
   personne du singulier en retirant le ``r`` de l’infinitif et en
   changeant la 4\ :math:`\ieme` lettre en partant de la fin en ``è``:
   ``peler`` :math:`\rightarrow` ``pèle``, ``acheter``
   :math:`\rightarrow` ``achète``, ``gérer`` :math:`\rightarrow`
   ``gère``, etc. Plutôt que d’écrire un suffixe de flexion pour chaque
   verbe (``LLLLèle``, ``LLLLète`` and ``LLLLère``), on peut utiliser
   l’opérateur ``R`` pour n’en écrire qu’un seul : ``LLLLèRR``.

-  ``C`` (copy) duplique une lettre de l’entrée, en décalant tout ce qui
   se trouve à sa droite.

   Supposons par exemple que l’on souhaite générer automatiquement des
   adjectifs en ``able`` à partir de noms. Dans des cas comme
   ``regrettable`` ou ``réquisitionnable``, on observe un doublement de
   la consonne finale du nom. Pour éviter d’écrire un graphe de flexion
   pour chaque consonne finale possible, on peut utiliser l’opérateur
   ``C`` afin de dupliquer la consonne finale, quelle qu’elle soit;

-  ``D`` (delete) supprime une lettre de l’entrée, en décalant tout ce
   qui se trouve à sa droite. Si l’on souhaite par exemple fléchir le
   mot roumain ``european`` en ``europeni``, on utilisera la séquence
   ``LDRi``. Le ``L`` positionnera le curseur sur la lettre ``a``, ``D``
   va supprimer le ``a``, en décalant le ``n`` sur la gauche, puis
   ``Ri`` va rétablir le ``n`` et ajouter un ``i``.

-  ``U`` (unaccent) enlève l’accent du caractère courant s’il en
   comporte un. Par exemple la séquence ``LLUx`` appliquée au mot
   ``mangés`` produit la forme fléchie ``mangex``, puisque ``U`` à
   transformé le ``é`` en ``e``.

-  ``P`` (uppercase) met en majuscule la première lettre de la pile. Par
   exemple, la séquence ``Px`` transforme ``foo`` en ``Foox``.

-  ``W`` (lowercase) met en minuscule la première lettre de la pile.

-  ``<R=?>`` remplace la première lettre de la pile par la lettre ``?``.

-  ``<I=?>`` insère la lettre ``?`` avant la première lettre de la pile.

-  ``<X=n>`` supprime les :math:`n` premières lettres de la pile.

Il y a également deux opérateurs spéciaux pour le Coréen:

-  ``J`` supprime une lettre Jamo. Si le caractère est un Hangul, ce
   caractère est d’abord remplacé par sa séquence équivalente en
   alphabet Jamo, ensuite, la dernière lettre Jamo est supprimée. Si le
   caractère n’est ni un Jamo, ni un Hangul, une erreur est produite.

-  ``.`` (latin dot) insère une limite de syllabe. Ceci a un effet de
   ford, si le haut de la pile contient des lettres Jamo, elles sont
   recombinées en Hangul.

Voici un exemple qui décrit la flexion de ``choose`` en ``chosen`` grâce
à la séquence d’opérateurs ``LLDRRn`` :

-  Étape 0: initialisation de la pile avec la forme canonique; on place
   le curseur après la dernière lettre:

   +---------+---------+---------+---------+---------+---------+---------+----+
   | ``c``   | ``h``   | ``o``   | ``o``   | ``s``   | ``e``   | `` ``   |    |
   +---------+---------+---------+---------+---------+---------+---------+----+

-  Étape 1: on décale le curseur vers la gauche:

   ``LLDRRn``

   +---------+---------+---------+---------+---------+---------+---------+----+
   | ``c``   | ``h``   | ``o``   | ``o``   | ``s``   | ``e``   | `` ``   |    |
   +---------+---------+---------+---------+---------+---------+---------+----+

-  Étape 2: on décale une seconde fois le curseur vers la gauche:

   ``LLDRRn``

   +---------+---------+---------+---------+---------+---------+---------+----+
   | ``c``   | ``h``   | ``o``   | ``o``   | ``s``   | ``e``   | `` ``   |    |
   +---------+---------+---------+---------+---------+---------+---------+----+

-  Étape 3: on décale tout ce qui est à droite du curseur vers la gauche
   :

   ``LLDRRn``

   +---------+---------+---------+---------+---------+---------+---------+----+
   | ``c``   | ``h``   | ``o``   | ``s``   | ``e``   | `` ``   | `` ``   |    |
   +---------+---------+---------+---------+---------+---------+---------+----+

-  Step 4: on décale le curseur vers la droite:

   ``LLDRRn``

   +---------+---------+---------+---------+---------+---------+---------+----+
   | ``c``   | ``h``   | ``o``   | ``s``   | ``e``   | `` ``   | `` ``   |    |
   +---------+---------+---------+---------+---------+---------+---------+----+

-  Step 5: on décale encore le curseur vers la droite:

   ``LLDRRn``

   +---------+---------+---------+---------+---------+---------+---------+----+
   | ``c``   | ``h``   | ``o``   | ``s``   | ``e``   | `` ``   | `` ``   |    |
   +---------+---------+---------+---------+---------+---------+---------+----+

-  Step 6: on écrit un ``n``

   ``LLDRRn``

   +---------+---------+---------+---------+---------+---------+---------+----+
   | ``c``   | ``h``   | ``o``   | ``s``   | ``e``   | ``n``   | `` ``   |    |
   +---------+---------+---------+---------+---------+---------+---------+----+

Une fois la séquence d’opérateurs épuisée, on prend le contenu de la
pile jusqu’avant le curseur pour former la forme fléchie (ici
``chosen``).

Le programme de flexion ``Inflect`` explore tous les chemins de la
grammaire de flexion en engendrant toutes les formes fléchies possibles.
Afin d’éviter de devoir remplacer les noms des grammaires de flexion par
de vrais codes grammaticaux dans le dictionnaire obtenu, le programme
remplace ces noms par leurs plus longs préfixes composés de lettres.
Ainsi, ``N4`` est remplacé par ``N``. En choisissant judicieusement les
noms des grammaires de flexion, on peut donc engendrer directement un
dictionnaire prêt à l’emploi.

La figure [fig-inflection-result] montre le dictionnaire obtenu après
flexion du DELAS de notre exemple.

.. figure:: resources/img/fig3-9.png
   :alt: Résultat de la flexion automatique[fig-inflection-result]
   :width: 9.50000cm

   Résultat de la flexion automatique[fig-inflection-result]

Opérateurs de flexion avancés
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Dans certaines langues, le processus de flexion entraine une
modification de la racine du mot. Plusieurs opérateurs ont été
développés pour faciliter ce type de traitement. Ils permettent de
rechercher et d’enlever un suffixe du mot ``W`` à fléchir. Cette
opération peut être accompagnée de la mémorisation dans une variable ($
ou £) d’un facteur de ce suffixe. Ces opérateurs peuvent prendre les
formes suivantes :

-  ``<X$Y>`` : On recherche à la fin du mot ``W`` le suffixe ``Y``.
   Puis, on recherche à partir de la position atteinte la **plus
   proche** occurrence de ``X`` qui précède strictement celle de ``Y`` .
   La variable $ contient alors le **plus court facteur**
   (**$**\ hortest) de ``W`` strictement compris entre ``X`` et ``Y``
   (``W = U.X.$.Y``)  [1]_. L’opérateur ``<X$Y>`` retire ``X.$.Y`` de
   ``W`` et donne une valeur à $. Une fois qu’il a été appliqué, la
   séquence qui reste dans la pile est ``U``, et la variable $ peut être
   utilisée dans le reste du chemin.

-  ``<X£Y>`` : On recherche à la fin du mot ``W`` le suffixe ``Y``.
   Puis, on recherche à partir de la position atteinte l’occurrence de
   ``X`` la **plus à gauche** qui précède strictement celle de ``Y``. La
   variable £ contient alors le **plus long facteur** (**£**\ ongest) de
   ``W`` strictement compris entre ``X`` et ``Y`` (``W = U.X.£.Y``).

-  ``<X>`` : Si aucune variable n’est présente, on recherche ``X`` comme
   suffixe de ``W`` (``W =U.X``).

-  ``<$Y>``: Si le facteur ``X`` est absent, le **plus court facteur
   ``$``** est la première lettre qui précède strictement ``Y`` .

-  ``<£Y>`` : Si le facteur ``X`` est absent, le **plus long facteur
   ``£``** est le préfixe de ``W`` tel que ``W = £.Y``.

Pour illustrer l’utilisation des ces opérateurs, considérons le verbe
*reprendre* :

+-------------+-------------+---------------------------+-----------------------+
| Verbe       | Opérateur   | Variable                  | Résultat              |
+=============+=============+===========================+=======================+
| reprendre   | <re>        |                           | reprend               |
+-------------+-------------+---------------------------+-----------------------+
| reprendre   | <$>         | $ = e                     | reprendr              |
+-------------+-------------+---------------------------+-----------------------+
| reprendre   | <£>         | £= reprendre              | :math:`\varepsilon`   |
+-------------+-------------+---------------------------+-----------------------+
| reprendre   | <re$re>     | $ = nd                    | rep                   |
+-------------+-------------+---------------------------+-----------------------+
| reprendre   | <re£re>     | £ = prend                 |                       |
+-------------+-------------+---------------------------+-----------------------+
| reprendre   | <$re>       | $ = d                     | repren                |
+-------------+-------------+---------------------------+-----------------------+
| reprendre   | <re$>       | $ = :math:`\varepsilon`   | reprendre             |
+-------------+-------------+---------------------------+-----------------------+
| reprendre   | <£re>       | £ = reprend               | :math:`\varepsilon`   |
+-------------+-------------+---------------------------+-----------------------+
| reprendre   | <re£>       | £ = prendre               | re                    |
+-------------+-------------+---------------------------+-----------------------+

Le programme MultiFlex permet d’utiliser dix variables de type $ dont
les noms sont $, $1..., $9 et dix variables de type £ dont les noms sont
£, £1..., £9. De plus, plusieurs variables de types différents peuvent
être utilisées au sein d’une même opération. Ainsi l’opérateur
<£3re$7re> appliqué au verbe *reprendre* donne £3 = rep et $7 = ``nd``.

Si l’on considère les verbes ``accélérer``, ``sécher``, la deuxième
personne du présent de l’indicatif peut être générée par l’opération
<é$er>è$es :

+-----------------+----------+-----------------------+---------+----------+-----+--------+-----------------------+-----------------+
| ``accélérer``   | <é$er>   | :math:`\rightarrow`   | accél   | $ = r    | +   | è$es   | :math:`\rightarrow`   | ``accélères``   |
+-----------------+----------+-----------------------+---------+----------+-----+--------+-----------------------+-----------------+
| ``sécher``      | <é$er>   | :math:`\rightarrow`   | s       | $ = ch   | +   | è$es   | :math:`\rightarrow`   | ``sèches``      |
+-----------------+----------+-----------------------+---------+----------+-----+--------+-----------------------+-----------------+

On remarque que le facteur ``$`` conservé dans la forme fléchie est de
longueur variable (``r``, ``ch``). La flexion de ``accélérer`` et
``sécher`` ne peut se faire que par des opérateurs de pile classiques à
l’aide d’une opération commune. Deux opérations différentes
(``-4RèCes``, ``-5RèCes``) sont nécessaires. Le graphe de la
figure [fig-inflection-secher] permet de fléchir des verbes comme
``accélérer`` et ``sécher`` au présent.

.. figure:: resources/img/fig3-Advanced_operators_with_Variables-V_secher.png
   :alt: Graphe de flexion pour des verbes comme *accélérer*, *sécher*
   [fig-inflection-secher]
   :width: 7.00000cm

   Graphe de flexion pour des verbes comme *accélérer*, *sécher*
   [fig-inflection-secher]

Voici les flexions obtenues pour les verbes ``accélérer`` et ``sécher``:

|image|

Le redoublement de certaines lettres lors de la flexion peut s’effectuer
avec l’opérateur $. Par exemple l’adject *tranquil* en anglais possède
deux formes au comparatif et deux au superlatf. Le graphe de la figure
 [fig-inflection-tranquil] permet de les produire.

.. figure:: resources/img/fig3-Advanced_operators_with_Variables-A_tranquil.png
   :alt: Graphe de flexion pour des adjectifs anglais comme *tranquil*
   [fig-inflection-tranquil]
   :width: 5.50000cm

   Graphe de flexion pour des adjectifs anglais comme *tranquil*
   [fig-inflection-tranquil]

Voici les flexions obtenues pour l’adjectif anglais ``tranquil``:

|image|

Dans certaines langues, certaines formes fléchies comporte un préfixe
qui s’ajoute devant la racine. C’est le cas lors de la formation du
participe passé en allemand. L’utilisation conjointe des opérateurs
``£`` et ``$`` permet de fléchir le verbe allemand ``sprechen`` (parler)
au présent et participe passé comme le montre le graphe de la
figure [fig-inflection-sprechen].

.. figure:: resources/img/fig3-Advanced_operators_with_Variables-V_sprechen.png
   :alt: Graphe de flexion pour des verbes comme *sprechen*
   [fig-inflection-sprechen]
   :width: 5.00000cm

   Graphe de flexion pour des verbes comme *sprechen*
   [fig-inflection-sprechen]

Voici les flexions obtenues pour le verbe allemand ``sprechen``:

|image|

Si l’on veut fléchir le verbe à particule aussprechen on peut utiliser
deux variables de type $. Le figure  [fig-inflection-aussprechen] montre
un graphe qui comport les variables ``$1`` et ``$2``.

.. figure:: resources/img/fig3-Advanced_operators_with_Variables-V_aussprechen.png
   :alt: Graphe de flexion pour des verbes comme *aussprechen*
   [fig-inflection-aussprechen]
   :width: 10.50000cm

   Graphe de flexion pour des verbes comme *aussprechen*
   [fig-inflection-aussprechen]

Voici les flexions obtenues pour le verbe allemand ``aussprechen``:

|image|

**Codes sémantiques** Dans certaines langues, il existe des
caractéristiques flexionnelles qui correspondent en fait à des
caractéristiques sémantiques comme par exemple les marqueurs de la forme
passive. Ces codes peuvent ne pas apparaître comme des codes
flexionnels, mais plutôt comme des codes sémantiques. Pour produire des
codes sémantiques, il faut insérer un signe plus au début de la sortie
d’une boîte. Cette boîte doit seulement contenir le code sémantique
précédé d’un plus, comme le montre la figure [fig-inflection-sem].

.. figure:: resources/img/fig3-9sem.png
   :alt: Une grammaire de flexion avec un code
   sémantique[fig-inflection-sem]
   :width: 6.00000cm

   Une grammaire de flexion avec un code sémantique[fig-inflection-sem]

Flexion des mots composés
~~~~~~~~~~~~~~~~~~~~~~~~~

Voir chapitre [chap-multiflex].

Flexion des langues sémitiques
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Les langues sémitiques comme l’arabe ou l’hébreu se fléchissent d’une
manière qui n’est pas facilement représentable avec les opérateurs de
flexion décrits ci-dessus. Leur morphologie obéit à une logique
différente : les mots se fléchissent selon un *squelette consonantique*.
Le processus de flexion combine ce squelette avec des voyelles. Des
opérateurs spécifiques ont été implémentés pour les langues sémitiques,
et certains pourraient être utiles aussi pour des langues en dehors de
la famille sémitique, comme le tagalog.

Tout d’abord, voyons un cas où on ne code que les consonnes dans le
champ lemme de l’entrée DELAS :

``ktb,$V31-123``

Le signe ``$`` avant le code grammatical indique que la grammaire de
flexion est en mode sémitique, et la forme ``ktb`` qui figure dans le
champ lemme est le squelette consonantique. La figure [semitic-grammar]
montre une grammaire jouet ``V31-123.grf`` qui illustre le
fonctionnement du mode sémitique. Les grammaires de flexion utilisent la
translittération Buckwalter++ de l’écriture arabe
(cf. section [transliteration-Arabic]).

.. figure:: resources/img/fig3-15.png
   :alt: Une grammaire de flexion jouet en mode
   sémitique[semitic-grammar]
   :width: 10.00000cm

   Une grammaire de flexion jouet en mode sémitique[semitic-grammar]

Le mode sémitique obéit aux règles suivantes:

#. Tous les opérateurs de flexion standard peuvent être utilisés (``L``,
   ``R``, etc.).

#. Un chiffre représente une lettre du champ lemme (``1`` pour la
   première, ``2`` pour la seconde, etc). Dans notre exemple, ``1``,
   ``2`` et ``3`` représentent respectivement ``k``, ``t`` et ``b``. Si
   on veut désigner une lettre après la neuvième, on doit protéger son
   numéro avec des chevrons : ``<10>``.

| Le DELAF produit par cette grammaire est:
| ``yakotubu,ktb.V:aI3ms``

| Si on ne code que les consonnes dans le champ lemme et que deux
  entrées ont les mêmes consonnes mais diffèrent par leurs voyelles, on
  doit coder les voyelles dans les grammaires de flexion :
| ``Hsb,$V3au // compter, Hasaba, yaHosubu``

``Hsb,$V3ii // penser, Hasiba, yaHosibu``

.. figure:: resources/img/fig3-LEMMA-operator.png
   :alt: Une grammaire de flexion en mode sémitique avec l’opérateur
   <LEMMA>[LEMMA-operator]
   :width: 10.00000cm

   Une grammaire de flexion en mode sémitique avec l’opérateur
   <LEMMA>[LEMMA-operator]

Pour copier tout le champ lemme, on peut utiliser l’opérateur <LEMMA>.
Une boite contenant cet opérateur récupère tout le champ lemme mais ne
dépend pas du nombre de lettres. Cet opérateur est utile pour les noms
et adjectifs arabes pour lesquels les formes du masculin sont obtenues
en insérant des voyelles dans le squelette consonantique, alors que
celles du féminin le sont en ajoutant des suffixes
(figure [LEMMA-operator]). Dans cet exemple, on a codé à la fois les
consonnes et les voyelles dans le champ lemme.

L’opérateur <n.LEMMA> copie le lemme depuis la :math:`n`\ ième position
jusqu’à la fin. Par exemple, dans certains noms arabes, la voyelle brève
de la première syllabe alterne : ``a/u``, ``a/i`` ou ``u/i``, comme dans
``nufaAyap``/``nifaAyap`` ”ordures”. La grammaire de flexion de la
fig. [n.LEMMA-operator] produit à la fois les variantes en ``u`` et en
``i`` comme formes fléchies de ``nufaAyap``.

.. figure:: resources/img/N0_i_0ap-f-At.png
   :alt: Une grammaire de flexion en mode sémitique avec l’opérateur
   <n.LEMMA>[n.LEMMA-operator]
   :width: 14.00000cm

   Une grammaire de flexion en mode sémitique avec l’opérateur
   <n.LEMMA>[n.LEMMA-operator]

En tagalog, une langue austronésienne parlée aux Philippines et qui
utilise communément des infixes et des redoublements pour la flexion,
<LEMMA> et <n.LEMMA> peuvent être utiles pour produire des temps
verbaux. La grammaire de flexion jouet de la fig. [tagalog] produit le
parfait ``kumain``, le futur ``kakain`` et l’imparfait ``kumakain`` du
verbe ``kain`` ”manger”.

.. figure:: resources/img/V1um.png
   :alt: Une grammaire de flexion jouet pour le tagalog en mode
   sémitique[tagalog]
   :width: 12.00000cm

   Une grammaire de flexion jouet pour le tagalog en mode
   sémitique[tagalog]

Translittération des dictionnaires d’arabe
------------------------------------------

Quand les linguistes arabes analysent des dictionnaires pour y détecter
des erreurs, la lecture dans l’écriture arabe est simple et efficace.
Cependant, quand ils créent des grammaires de flexion
(section [section-automatic-inflection]), des éléments de mots arabes
apparaissent dans la même boite que des informations morpho-syntaxiques
codées dans l’alphabet latin, et dans ce contexte, les allers-retours
entre l’écriture arabe, qui se lit de droite à gauche, et l’alphabet
latin, qui se lit de gauche à droite, ne sont pas pratiques. Avec
Unitex, on peut coder des grammaires de flexion entièrement dans
l’alphabet latin, en utilisant la translittération Buckwalter++, une
correspondance biunivoque entre un codage Unicode de l’écriture arabe et
des lettres de l’alphabet latin (cf. :raw-latex:`\cite{neme2011}`,
section 3.2, pp. 4–6). La translittération Buckwalter++ est définie par
la table des figures [buckwalter1] et [buckwalter2]. Unitex offre une
fonctionnalité de translittération de dictionnaires DELAS et DELAF de
l’arabe vers le code Buckwalter++ et inversement
(fig. [Arabic-transliteration]). Cette fonctionnalité est accessible par
le menu DELA.

.. figure:: resources/img/buckwalter1-fr.pdf
   :alt: Table de translittération Buckwalter++, première
   moitié[buckwalter1]
   :height: 23.50000cm

   Table de translittération Buckwalter++, première moitié[buckwalter1]

.. figure:: resources/img/buckwalter2-fr.pdf
   :alt: Table de translittération Buckwalter++, deuxième
   moitié[buckwalter2]
   :height: 23.50000cm

   Table de translittération Buckwalter++, deuxième moitié[buckwalter2]

.. figure:: resources/img/Arabic-transliteration.pdf
   :alt: Translittération d’un dictionnaire DELAF depuis le code
   Buckwalter++ (à gauche) vers l’écriture arabe (à
   droite)[Arabic-transliteration]
   :width: 15.00000cm

   Translittération d’un dictionnaire DELAF depuis le code Buckwalter++
   (à gauche) vers l’écriture arabe (à droite)[Arabic-transliteration]

Compression
-----------

Unitex applique aux textes des dictionnaires comprimés. La compression
permet de réduire la taille des dictionnaires et d’en accélérer la
consultation. Cette opération s’effectue avec le programme ``Compress``.
Celui-ci prend en entrée un dictionnaire sous forme de fichier texte
(par exemple ``mon_dico.dic``) et produit deux fichiers:

-  ``mon_dico.bin`` contient l’automate minimal des formes fléchies du
   dictionnaire;

-  ``mon_dico.inf`` contient des codes qui permettent de reconstruire le
   dictionnaire d’origine à partir des formes fléchies contenues dans
   ``mon_dico.bin``.

L’automate minimal contenu dans ``mon_dico.bin`` est une représentation
des formes fléchies où tous les préfixes et suffixes communs sont
factorisés. Par exemple, l’automate minimal des mots ``me``, ``te``,
``se``, ``ma``, ``ta`` et ``sa`` peut être représenté par le graphe de
la figure [fig-example-minimal-automaton].

.. figure:: resources/img/fig3-10.png
   :alt: Représentation d’un exemple d’automate
   minimal[fig-example-minimal-automaton]
   :width: 5.00000cm

   Représentation d’un exemple d’automate
   minimal[fig-example-minimal-automaton]

Pour comprimer un dictionnaire, ouvrez-le puis cliquez sur “Compress
into FST” dans le menu “DELA”. La compression est indépendante de la
langue et du contenu du dictionnaire. Les messages produits par le
programme sont affichés dans une fenêtre qui ne se ferme pas
automatiquement. Vous pouvez ainsi voir la taille du fichier ``.bin``,
obtenu, le nombre de lignes lues ainsi que le nombre de codes
flexionnels produits. La figure  [fig-compression-result] montre le
résultat de la compression d’un dictionnaire de mots simples.

.. figure:: resources/img/fig3-11.png
   :alt: Résultat d’une compression[fig-compression-result]
   :width: 14.00000cm

   Résultat d’une compression[fig-compression-result]

À titre indicatif, les taux de compression généralement observés sont
d’environ 95% pour les dictionnaires de mots simples et 50% pour ceux de
mots composés.

Quand le mode sémitique ([subsection-semitic-inflection]) a beaucoup été
utilisé lors de la flexion d’un dictionnaire, une variante spécifique de
l’algorithme de compression peut réduire la taille des fichiers ``.bin``
et ``.inf``. Pour l’invoquer, soit on déclare la langue comme étant
sémitique dans les préférences globales, en cochant l’option ”Semitic
language” dans ”Preferences > Language and Presentation”, soit on lance
le programme Compress en ligne de commande avec l’option ``--semitic``.

Application de dictionnaires
----------------------------

Unitex peut manipuler soit des dictionnaires compressés (``.bin``) soit
des graphes-dictionnaires (``.fst2``). Ces dictionnaires peuvent être
appliqués soit lors du prétraitement, soit explicitement en cliquant sur
“Apply Lexical Resources...” dans le menu “Text”. Nous allons maintenant
détailler les règles de l’application des dictionnaires. Le cas des
graphes-dictionnaires sera abordé dans la section
 [section-dictionary-graphs].

Priorités
~~~~~~~~~

La règle de priorité est la suivante : si un mot du texte a été trouvé
dans un dictionnaire, ce mot ne sera plus pris en compte lors de
l’application de dictionnaires ayant une priorité inférieure.

Cela permet d’éliminer certaines ambiguïtés lors de l’application des
dictionnaires. Par exemple, le mot *par* a une interprétation nominale
dans le domaine du golf. Si l’on ne veut pas envisager cet emploi, il
suffit de créer un dictionnnaire filtre ne contenant que l’entrée
``par,.PREP`` et de le sauver en lui donnant la priorité la plus haute.
De cette manière, même si le dictionnaire des mots simples contient
l’autre entrée, celle-ci sera ignorée grâce au jeu des priorités.

Il y a trois niveaux de priorités. Les dictionnaires dont les noms sans
extension se terminent par ``-`` ont la priorité la plus grande ; ceux
dont le nom se termine par ``+`` ont la priorité la plus faible ; les
autres dictionnaires sont appliqués avec une priorité moyenne. L’ordre
d’application de plusieurs dictionnaires ayant la même priorité est sans
importance. En ligne de commande, l’instruction :

``Dico ex.snt alph.txt ctr+.bin cities-.bin rivers.bin regions-.bin``

appliquerait donc les dictionnaires dans l’ordre suivant (``ex.snt`` est
le texte auquel sont appliqués les dictionnaires, ``alph.txt`` est le
fichier alphabet utilisé):

#. ``cities-.bin``

#. ``regions-.bin``

#. ``rivers.bin``

#. ``ctr+.bin``

Règles d’application des dictionnaires
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Outre la règle de priorités, l’application des dictionnaires s’effectue
en respectant les majuscules et les espaces. La règle du respect des
majucules est la suivante :

-  s’il y a une majuscule dans le dictionnaire, alors il doit y avoir
   une majuscule dans le texte ;

-  s’il y a une minuscule dans le dictionnaire, il peut y avoir soit une
   minuscule soit une majuscule dans le texte.

Ainsi, l’entrée ``pierre,.N:fs`` reconnaîtra les mots ``pierre``,
``Pierre`` et ``PIERRE``, alors que

``Pierre,.N+Prénom`` ne reconnaîtra que ``Pierre`` et ``PIERRE``. Les
lettres minuscules et majuscules sont définies par le fichier alphabet
passé en paramètre au programme ``Dico`` .

Le respect des espacements est une règle très simple : pour qu’une
séquence du texte soit reconnue par une entrée de dictionnaire, elle
doit avoir exactement les mêmes espaces. Par exemple, si le dictionnaire
contient ``aujourd'hui,.ADV``, la séquence ``Aujourd' hui`` ne sera pas
reconnue à cause de l’espace qui suit l’apostrophe.

Graphes-dictionnaires
~~~~~~~~~~~~~~~~~~~~~

Le programme ``Dico`` est également capable d’appliquer des
graphes-dictionnaires. Il s’agit de graphes qui respectent, par
défaut [2]_, la règle suivante : si on les applique avec le programme
``Locate`` en mode MERGE, ils doivent produire des séquences
correspondant à des lignes de DELAF. Quand on les applique à un texte,
ils attachent les étiquettes lexicales DELAF à ces séquences.

.. figure:: resources/img/fig3-12.png
   :alt: Graphe-dictionnaire des éléments chimiques[elements]
   :height: 24.00000cm

   Graphe-dictionnaire des éléments chimiques[elements]

La figure [elements] montre un graphe reconnaissant les symboles
chimiques. On peut voir sur cette figure un premier avantage par rapport
aux dictionnaires compressés : l’utilisation des guillemets permet de
forcer le respect de la casse. Ainsi, ce graphe reconnaîtra bien ``Fe``
mais pas ``FE``, alors qu’il est impossible de spécifier une telle
interdiction dans un DELAF usuel.

Le second avantage des graphes-dictionnaires est qu’ils peuvent
exploiter les résultats fournis par les dictionnaires appliqués
précédemment. Ainsi, on peut appliquer le dictionnaire général, puis
étiqueter comme noms propres les mots inconnus commençant par une
majuscule à l’aide du graphe ``NPr+`` de la figure [graph-NPr]. Le ``+``
dans le nom du graphe lui donne une priorité basse afin qu’il soit
appliqué après le dictionnaire général. Pour fonctionner, ce graphe se
base sur les mots qui sont toujours inconnus après le passage du
dictionnaire général. Les crochets correspondent à une définition de
contexte (voir la section [section-contexts]).

.. figure:: resources/img/fig3-13.png
   :alt: Graphe-dictionnaire étiquetant comme noms propres les mots
   inconnus commençant par une majuscule [graph-NPr]
   :width: 10.50000cm

   Graphe-dictionnaire étiquetant comme noms propres les mots inconnus
   commençant par une majuscule [graph-NPr]

Comme les graphes-dictionnaires sont appliqués par le moteur du
programme ``Locate``, ils peuvent utiliser tout ce que le programme
``Locate`` autorise. En particulier, il est possible d’utiliser les
filtres morphologiques (section [section-filters]) et le mode
morphologique (section [section-morphological-mode]). Ainsi, le graphe
de la figure [graph-CR] utilise ces filtres pour reconnaître les nombres
en chiffres romains. Notons qu’il utilise également des contextes afin
d’éviter, par exemple, que ``C`` ne soit pris comme chiffre romain quand
il est suivi par une apostrophe.

.. figure:: resources/img/fig3-14.png
   :alt: Graphe-dictionnaire reconnaissant les nombres en chiffres
   romains[graph-CR]
   :height: 24.00000cm

   Graphe-dictionnaire reconnaissant les nombres en chiffres
   romains[graph-CR]

Par défaut, les graphes-dictionnaires sont appliqués en mode MERGE. Il
est possible de les appliquer en mode REPLACE, en ajoutant à leur le nom
le suffixe ``-r``. Celui-ci se combine avec les priorités ``+`` et
``-``:

``bagpipe-r.fst2  McAdam-r-.fst2  phtirius-r+.fst2``

Exporter les entrées produites comme dictionnaire du mode morphologique
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Les entrées produites par un graphe-dictionnaire sont consultées par le
programme ``Locate`` quand il rencontre des masques lexicaux qui
nécessitent la consultation d’un dictionnaire.

Cependant, cette fonctionnalité est restreinte quand le masque lexical
est en mode morphologique (cf. section [section-morphological-mode]). On
ne peut pas déclarer un graphe-dictionnaire comme dictionnaire du mode
morphologique de la manière habituelle (cf. section [dic-mode-morpho]),
car ce n’est pas un fichier ``.bin``. Quand on est en mode
morphologique, les masques lexicaux qui nécessitent la consultation d’un
dictionnaire ne déclenchent pas la consultation de
graphes-dictionnaires. En compensation, on dispose de plusieurs
solutions.

-  On peut envisager d’invoquer le graphe-dictionnaire depuis la partie
   du graphe qui est en mode morphologique.

-  Unitex produit de façon interne un dictionnaire des formes reconnues
   dans le texte par un graphe-dictionnaire. Si le nom du
   graphe-dictionnaire contient l’option ``b`` (voir ci-dessous
   Conventions de nommage), ce dictionnaire produit automatiquement est
   inclus implicitement parmi les dictionnaires du mode morphologique,
   de telle sorte qu’il est consulté quand le programme ``Locate``
   rencontre des masques lexicaux en mode morphologique. Mais cette
   solution ne fonctionne que pour les formes reconnues par le
   graphe-dictionnaire pendant l’application initiale des dictionnaires
   (cf. section [section-applying-dictionaries]), et non pour celles qui
   n’apparaissent dans le texte que comme parties de tokens.

Si on ajoute ``z`` à la place de ``b``, le dictionnaire produit de façon
interne pour le texte est immédiatement compressé, et il peut être
consulté quand d’autres graphes-dictionnaires sont appliqués par la
suite.

Conventions de nommage
^^^^^^^^^^^^^^^^^^^^^^

| Le processus de nommage d’un graphe-dictionnaire s’établit comme suit
  :
| ``nom(-XYZ)([-+]).fst2``
| où:

-  ``X`` prend l’une des valeurs ``[rRmM]``: ``r`` signifie mode
   REPLACE; ``M`` signifie mode MERGE (mode par défaut);

-  ``Y`` prend l’une des valeurs ``[bBzZ]``: option qui régit la
   construction d’un dictionnaire du mode morphologique (voir
   ci-dessus);

-  ``Z`` prend l’une des valeurs ``[aAlLsS]``: ``a`` signifie que le
   graphe est appliqué en mode “All matches”; ``l`` signifie mode
   “Longest matches” (mode par défault); ``s`` signifie “Shortest
   matches”.

Graphe-dictionnaire morphologique
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Dans un graphe-dictionnaire, chaque chemin doit, par défaut, produire
une entrée lexicale à inclure dans le dictionnaire du texte. Dans un
graphe-dictionnaire morphologique, chaque chemin doit produire une
séquence d’une ou plusieurs étiquettes délimitées par des accolades et
conformes à la syntaxe des lignes du DELAF
(section [section-DELAF-entry-syntax]). Les sorties de tels graphes
seront utilisées comme entrées pour construire l’automate du texte. Nous
les appelons “graphes-dictionnaires morphologiques” parce que leur
principale utilité est de fournir de nouvelles analyses morphologiques
dans l’automate du texte, grâce au mode morphologique (voir
[section-morphological-mode]). Cette fonctionnalité est utile pour des
langues agglutinantes comme le coréen. Pour pouvoir utiliser un graphe
comme graphe-dictionnaire morphologique, on le déclare par une barre
oblique (slash, /) comme premier caractère de sa sortie, comme dans la
figure [morphoA].

.. figure:: resources/img/fig3-14a.png
   :alt: Exemple de graphe-dictionnaire morphologique[morphoA]
   :width: 14.00000cm

   Exemple de graphe-dictionnaire morphologique[morphoA]

La règle est simple: toute sortie du graphe-dictionnaire commençant par
une barre oblique (slash, /) est ajoutée au fichier ``tags.ind``, situé
dans le répertoire du texte. Ce fichier est utilisé par le programme
``Txt2Fst2`` afin d’ajouter des interprétations à l’automate du texte.
La grammaire de la figure [morphoA] reconnaît des mots formés par le
préfixe ``un`` suivi d’un adjectif. Si on l’applique comme
graphe-dictionnaire, on obtient de nouveaux chemins dans l’automate du
texte comme le montre la figure [morphoB]. Remarquons que lorsque deux
tags correspondent à des analyses dans la même unité lexicale, le lien
entre eux est affiché par une ligne discontinue.

.. figure:: resources/img/fig3-14b.png
   :alt: Chemin ajouté par un graphe-dictionnaire morphologique[morphoB]
   :width: 15.00000cm

   Chemin ajouté par un graphe-dictionnaire morphologique[morphoB]

Bibliographie
-------------

Le tableau  [ref-dicos] donne quelques références relatives aux
dictionnaires électroniques de mots simples et composés. Pour plus de
détails, consultez la page de références sur le site web d’Unitex:
http://www-igm.univ-mlv.fr/~unitex

+----------------+------------------------------------------------------------------------------------------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------+
| **Langue**     | **Mots simples**                                                                                                                         | **Mots composés**                                                                                                                        |
+================+==========================================================================================================================================+==========================================================================================================================================+
| English        | :raw-latex:`\cite{klarsfeld}`, :raw-latex:`\cite{monceaux-1995}`                                                                         | :raw-latex:`\cite{delac-anglais}`, :raw-latex:`\cite{these-Savary}`                                                                      |
+----------------+------------------------------------------------------------------------------------------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------+
| French         | :raw-latex:`\cite{formes-ambigues}`, :raw-latex:`\cite{dicos-francais}`, :raw-latex:`\cite{jacques-1995}`                                | :raw-latex:`\cite{dicos-francais}`, :raw-latex:`\cite{Gross96}`, :raw-latex:`\cite{max-1993}`, :raw-latex:`\cite{syntaxe-de-ladverbe}`   |
+----------------+------------------------------------------------------------------------------------------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------+
| Modern Greek   | :raw-latex:`\cite{modern-greek}`, :raw-latex:`\cite{matthieu-anastasia}`, :raw-latex:`\cite{these-tita}`                                 | :raw-latex:`\cite{tita-2002}`, :raw-latex:`\cite{anastasia-2002}`                                                                        |
+----------------+------------------------------------------------------------------------------------------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------+
| Italian        | :raw-latex:`\cite{delaf-italien}`, :raw-latex:`\cite{delaf-italien-book}`                                                                | :raw-latex:`\cite{composes-italien}`                                                                                                     |
+----------------+------------------------------------------------------------------------------------------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------+
| Spanish        | :raw-latex:`\cite{blanco-2000}`                                                                                                          | :raw-latex:`\cite{blanco-1997}`                                                                                                          |
+----------------+------------------------------------------------------------------------------------------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------+
| Portuguese     | :raw-latex:`\cite{eleuterio1995}`, :raw-latex:`\cite{ranchhod1996b}`, :raw-latex:`\cite{ranchhodd1998}`, :raw-latex:`\cite{muniz2005}`   | :raw-latex:`\cite{ranchhod1991}`, :raw-latex:`\cite{ranchhodd1998}`                                                                      |
+----------------+------------------------------------------------------------------------------------------------------------------------------------------+------------------------------------------------------------------------------------------------------------------------------------------+

Table: Quelques références bibliographiques sur les dictionnaires
électroniques[ref-dicos]

.. [1]
   Le point représente ici l’opération de concaténation.

.. [2]
   Les graphes-dictionnaires morphologiques sont une exception
   (section [section-morphological-dictionary-graphs]) .

.. |image| image:: resources/img/fig3-flexion_secher.png
   :width: 5.00000cm
.. |image| image:: resources/img/fig3-flexion_tranquil.png
   :width: 5.00000cm
.. |image| image:: resources/img/fig3-flexion_sprechen.png
   :width: 5.00000cm
.. |image| image:: resources/img/fig3-flexion_aussprechen2.png
   :width: 5.00000cm
